
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>

@section('package')

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_CHOOSE_TYPE." "; /*-~- Package Name -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sbrow_chk["sbname"]; ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_ADVERTISE.""; /*-~- Package Type -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo  $dis?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00004_CHOOSE_TYPE.""; /*-~- Price -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sb_fee_currency.sbcurrency_format($sbrow_chk["price"]); ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
 <?php 
				$month="";
				if($sbrow_chk["sbtype"]==1)	
				echo /*2s*/ "".SOFTBIZ_LC00003_CHOOSE_TYPE."" /*-~-* / "Impressions" / *-~-*/ /*2e*/ ;
				elseif($sbrow_chk["sbtype"]==2)
				echo /*2s*/ "".SOFTBIZ_LC00009_CHOOSE_TYPE."" /*-~-* / "Clicks" / *-~-*/ /*2e*/ ;
				else
				{
				echo /*2s*/ "".SOFTBIZ_LC00012_CHOOSE_TYPE."" /*-~-* / "Duration" / *-~-*/ /*2e*/ ;
				$month=($sbrow_chk['credits']==1)?/*2s*/ " ".SOFTBIZ_LC00003_MYACCOUNT."" /*-~-* / "Month" / *-~-*/ /*2e*/ :/*2s*/ " ".SOFTBIZ_LC00016_CHOOSE_TYPE."" /*-~-* / "Months" / *-~-*/ /*2e*/ ;
				} ?>
</div>
<div class="col-md-6">
 <?php echo $sbrow_chk['credits'].$month;?>
</div>
</div>


@endsection
@include('includes.panel-one', ['title' =>$form_title,'data'=>'package'])



       
      
@section('pack-form')



<br><br>
 <div class="row">                     
 <div class="col-md-12">
 <div align="center"><font size="2" face="Arial, Helvetica, sans-serif"><span id='sbpreview'></span></font></div></div>


</div>

<br><br>

 <form class="form-horizontal"  name=form123 onsubmit=return(formValidate(this)); 
                  method=post action="confirm_textad.php">


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00010_EDIT_TEXTAD.""; /*-~- Title -~-*/ /*1e*/ ?><br>
<a href="textadhelp.php" target="_blank"><?php /*1s*/ echo "".SOFTBIZ_LC00011_EDIT_TEXTAD.""; /*-~- Editorial guidelines -~-*/ /*1e*/ ?></a>
  </label>
  <div class="col-md-7">
<input name="title" type="text" id="title"  onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)"  class="form-control"  value="<?php echo sbhtmlentities(stripslashes($config["sbtitle"]),ENT_QUOTES) ;?>">
<small class="text-muted"><?php /*1s*/ echo "".SOFTBIZ_LC00012_EDIT_TEXTAD.""; /*-~- Title should not be more than 25 characters. -~-*/ /*1e*/ ?></small>
  </div>
</fieldset>

  
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00013_EDIT_TEXTAD.""; /*-~- Description 1 -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="description1" type="text" id="description1" onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)" value="<?php echo sbhtmlentities(stripslashes($config["sbdescription"]),ENT_QUOTES) ;?>"  class="form-control" > 


<small class="text-muted"><?php /*1s*/ echo "".SOFTBIZ_LC00014_EDIT_TEXTAD.""; /*-~- Description should not be more than 35 characters. -~-*/ /*1e*/ ?></small>
  </div>
</fieldset>

  
  
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00015_EDIT_TEXTAD." "; /*-~- Description 2 -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="description2" type="text" id="description2" onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)" value="<?php echo sbhtmlentities(stripslashes($config["sbdescriptiontwo"]),ENT_QUOTES) ;?>"  class="form-control" >
<small class="text-muted">
<?php /*1s*/ echo "".SOFTBIZ_LC00014_EDIT_TEXTAD.""; /*-~- Description should not be more than 35 characters. -~-*/ /*1e*/ ?>
</small>
  </div>
</fieldset>

  
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00016_EDIT_TEXTAD.""; /*-~- Display Url -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="display_url" type="text" id="display_url" onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)" value="<?php echo  sbhtmlentities(stripslashes($config['textad_displayurl']),ENT_QUOTES) ;?>"  class="form-control" >

<small class="text-muted">
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00017_EDIT_TEXTAD.""; /*-~- Display url should not be more than 35 characters. -~-*/ /*1e*/ ?>
</small>
  </div>
</fieldset>

  
  <fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00007_ADVERTISE." "; /*-~- Destination URL -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<INPUT name=url  value="http://"  class="form-control"  onClick="change_prv(this.form)" onKeyUp="change_prv(this.form)">
                        
                        
         <small class="text-muted">               <?php /*1s*/ echo "                          ".SOFTBIZ_LC00007_ADVERTISE_TEXT.""; /*-~- Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com -~-*/ /*1e*/ ?>
         </small>
  </div>
</fieldset>

      <fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">
  <input name="sbplan" type="hidden" id="sbplan" value="<?php echo $sbplan; ?>">
  
<input class="btn btn-primary"  type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00014_CHOOSE_TYPE.""; /*-~- Continue -~-*/ /*1e*/ ?>" name=submit> 
  </div>
</fieldset>

</form>

@endsection
@include('includes.panel-two', ['title' =>$form_title2,'data'=>'pack-form'])



               