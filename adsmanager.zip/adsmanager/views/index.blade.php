<?php
foreach($vars as $k=>$v)  { $$k=$v;}

?>

                 <div class="row">
                <div class="col-md-5 col-md-offset-1">
 
 
 @section('add-member')

 <form class="form-horizontal"  name="register" id="register" onsubmit="return(formValidate(this));" method="POST" action="insertmember.php">


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00009_SITEHOME.""; /*-~- Your Name -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input name=uname  class="form-control"   value="<?php echo sbhtmlentities(stripslashes($uname),ENT_QUOTES);?>" >
  </div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00010_SITEHOME.""; /*-~- Your Address -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input name="add"  value="<?php echo sbhtmlentities(stripslashes($add),ENT_QUOTES);?>" class="form-control">
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00011_SITEHOME.""; /*-~- City -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input name="city"  value="<?php echo sbhtmlentities(stripslashes($city),ENT_QUOTES);?>" class="form-control">
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00012_SITEHOME.""; /*-~- State -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input name="state" value="<?php echo sbhtmlentities(stripslashes($state),ENT_QUOTES);?>" class="form-control">
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00013_SITEHOME.""; /*-~- Country -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <SELECT name=country  class="select-two" >
                        <OPTION value=0
                          <?php if($country==0) {echo " selected ";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00014_SITEHOME." "; /*-~- Select a Country -~-*/ /*1e*/ ?></option>
                        <?php 
						            
			             	
						  $country1=mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_country order by country");
						              
						  while($rst= mysqli_fetch_array($country1))
						  {
						  ?>
                        <OPTION value=<?php echo $rst["id"];?> <?php if($rst["id"]==$country) {echo " selected ";}?>><?php echo $rst["country"];?></OPTION>
                        <?php
} // wend
							   ?>
                      </SELECT>
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00015_SITEHOME." "; /*-~- Website URL -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input name="url"  class="form-control"   value="<?php echo sbhtmlentities(stripslashes($url),ENT_QUOTES);?>" size=25 
                        maxlength=120>
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00016_SITEHOME." "; /*-~- Your Email -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <INPUT  class="form-control"  name=email value="<?php echo sbhtmlentities(stripslashes($email),ENT_QUOTES);?>" >
  </div>
</fieldset>



<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00017_SITEHOME.""; /*-~- Password -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input   class="form-control"   maxlength=120 size=25 name=pwd type="password">
  <small class="text-muted">
  <?php printf(/*2s*/ "".SOFTBIZ_LC00009_CHANGEPASSWORD." " /*-~-* / "must be atleast %s" / *-~-*/ /*2e*/ ,$pwd_len); echo ($pwd_len==1)? /*2s*/ "".SOFTBIZ_LC00010_CHANGEPASSWORD."" /*-~-* / "character" / *-~-*/ /*2e*/  :/*2s*/ "".SOFTBIZ_LC00011_CHANGEPASSWORD."" /*-~-* / "characters" / *-~-*/ /*2e*/ ?>
  </small></div>
  
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00018_SITEHOME.""; /*-~- Confirm Password -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input  class="form-control"  name=pwd2 type="password" id="pwd2"  >
  <small class="text-muted">
  <?php printf(/*2s*/ "".SOFTBIZ_LC00009_CHANGEPASSWORD." " /*-~-* / "must be atleast %s" / *-~-*/ /*2e*/ ,$pwd_len); echo ($pwd_len==1)? /*2s*/ "".SOFTBIZ_LC00010_CHANGEPASSWORD."" /*-~-* / "character" / *-~-*/ /*2e*/  :/*2s*/ "".SOFTBIZ_LC00011_CHANGEPASSWORD."" /*-~-* / "characters" / *-~-*/ /*2e*/ ?>
  </small></div>
  
  
</fieldset>

<?php if($sb_captcha_signup==1)
		  {?>
<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00005_LOSTPASSWORD.""; /*-~- Validation Code -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <?php 
			            
					  gen_image(); 
			             	
					           
					  ?>
  </div>
</fieldset>

<?php }?>
<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 
  </label>
  <div class="col-md-7">
  <INPUT class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00019_SITEHOME.""; /*-~- Submit -~-*/ /*1e*/ ?>" name=submit>
  </div>
</fieldset>


</form>  
    @endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'add-member'])

        
            </div>
            
            <div class="col-md-5">
 @section('login-member')

 <form class="form-horizontal"  action="login.php"  method=post name=signin id="signin"  onSubmit="return  validate_login(this);">
  <fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00016_SITEHOME." "; /*-~- Your Email -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <INPUT name=email class="form-control" value="<?php echo $auto_user; ?>">
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00017_SITEHOME.""; /*-~- Password -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <input name=pwd type="password"  class="form-control" value="<?php echo $auto_userpwd; ?>">
  </div>
</fieldset>

<?php if($sb_captcha_login==1)
		  {?>

<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00005_LOSTPASSWORD.""; /*-~- Validation Code -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <?php 
					           
					  gen_image(); 
                                	
					  		           
					  ?>
  </div>
</fieldset>
<?php }?>

<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 
  </label>
  <div class="col-md-7">
  <input class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00023_SITEHOME.""; /*-~- Sign In -~-*/ /*1e*/ ?>" name=submit2> 
  </div>
</fieldset>

    
    <fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""> 
 
  </label>
  <div class="col-md-7">
  <a href="lostpassword.php"><?php /*1s*/ echo "".SOFTBIZ_LC00002_LOSTPASSWORD." "; /*-~- Forgot Password -~-*/ /*1e*/ ?></a>
  </div>
</fieldset>

</form>    


@endsection
@include('includes.panel-one', ['title' =>$form_title2,'data'=>'login-member'])
        
  <div class="row">
<div class="col-md-11">
    <img style="width:100%; height:auto;" src="images/advertise.png">
    </div>
    </div>      
            </div>
          
            </div>
        

      
