<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>


                    
                       
 @section('insert-money')
 
 

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00001_INSERT_MONEY.""; /*-~- Amount to be Added -~-*/ /*1e*/ ?></div>
<div class="col-md-7">
<?php 
							echo $sb_fee_currency.sbcurrency_format($amount); ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_INSERT_MONEY.""; /*-~- Current Balance -~-*/ /*1e*/ ?></div>
<div class="col-md-7">
<?php echo $sb_fee_currency.sbcurrency_format($sb_balance); ?></div>

</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00003_INSERT_MONEY.""; /*-~- Balance After Addition -~-*/ /*1e*/ ?></div>
<div class="col-md-7">
<?php echo $sb_fee_currency.sbcurrency_format($sb_balance+$amount); ?></div>

</div>

<div class="row">
<div class="col-md-11">

<br><br>

 <?php
						switch($pay_method)
						{
						 case 1: echo str_replace("\n","<br>",$rs_a["sb_offline_details"]);				 
						 break;
						 case 2: 
						 
						 $action="https://www.paypal.com/cgi-bin/webscr";
						 if(DMODE){
						 $action="ad_home.php?msg=".urlencode("This feature is disabled in demo");

						 }
                 
				 ?>
                              <form class="form-horizontal"  action="<?php echo $action ; ?>" method="post"  >
                                <input type="hidden" name="cmd" value="_xclick">
                                <input type="hidden" name="business" value="<?php echo $rs_a["sb_paypal_id"]; ?>">
                                <input type="hidden" name="item_name" value="<?php /*1s*/ echo "".SOFTBIZ_LC00004_INSERT_MONEY.""; /*-~- Add Money to account -~-*/ /*1e*/ ?>">
                                <input type="hidden" name="item_number" value="A1">
                                <input type="hidden" name="custom" value="<?php echo $_SESSION["softbiz_bannerad_userid"] ?>">
                                <input type="hidden" name="return" value="<?php echo $rs_a["site_root"]; ?>/thanks.php">
                                <input type="hidden" name="cancel_return" value="<?php echo $rs_a["site_root"]; ?>/cancelpurchase.php">
                                <input type="hidden" name="rm" value="2">
                                <input type="hidden" name="notify_url" value="<?php echo $rs_a["site_root"]; ?>/ipn/ipn_add.php">
                                <input type="hidden" name="no_note" value="1">
                                <input type="hidden" name="currency_code" value="<?php echo $sb_fee_code ?>">
                                <input name="amount" type="hidden" id="amount" value="<?php echo $amount; ?>">
                                <input type="hidden" name="description" value="<?php /*1s*/ echo "".SOFTBIZ_LC00005_INSERT_MONEY.""; /*-~- Added Money To Your Account -~-*/ /*1e*/ ?>">
                                <input class="btn btn-primary" type="submit" name="Submit" value="<?php /*1s*/ echo "".SOFTBIZ_LC00006_INSERT_MONEY.""; /*-~- Continue to Paypal Payment -~-*/ /*1e*/ ?>">
                              </form>
                              <?php
break;
						 case 3: 
						 
						 						 $action="https://www.2checkout.com/cgi-bin/sbuyers/cartpurchase.2c";
						 if(DMODE){
						 $action="ad_home.php?msg=".urlencode("This feature is disabled in demo");

						 }


						  ?>
                              <form class="form-horizontal"  name="checkout" method="post" 
						 action="<?php echo $action ; ?>" >
                                <input type="hidden" name="sid" value="<?php echo $rs_a["sb_seller_id"];?>">
                                <input type="hidden" name="cart_order_id" value="member #<?php echo $oid;?>">
                                <input type="hidden" name="total" value="<?php echo $amount;?>">
                                <input class="btn btn-primary" type="submit" name="Submit" value="<?php /*1s*/ echo "".SOFTBIZ_LC00007_INSERT_MONEY.""; /*-~- Continue to 2Checkout Payment -~-*/ /*1e*/ ?>">
                              </form>
                              <?php 
						 break;
						}
						?>



<br><Br>



</div>
</div>

<div class="row">
<div class="col-md-11">
<?php echo $rs_a["sb_billing_terms"];?> 
</div>
</div>

    @endsection

@include('includes.panel-two', ['title' =>$form_title . $lable,'data'=>'insert-money'])
  