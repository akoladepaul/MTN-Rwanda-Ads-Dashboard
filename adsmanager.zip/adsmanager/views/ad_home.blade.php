<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>
 
           
 
@section('section-one')
<?php 
// Aggregate Banner Statistics For All Your Banners
?>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00001_AD_HOME.""; /*-~- Total Number of Banners Posted -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php 
		  $total=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_ads where adv_id=$id"));
		  echo $total;
		  ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_AD_HOME.""; /*-~- Approved -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php
				              
$app=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_ads where approved='yes' and adv_id=$id"));
             
	              	
		  echo $app;?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00003_AD_HOME.""; /*-~- Disapproved -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $total-$app;?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00004_AD_HOME.""; /*-~- Total Impressions Received -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
  <?php 
				              
		  $total=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select sum(displays) from sbbanners_ads where adv_id=$id"));
		  $total_impressions=0;
             	
		              
		  if($total[0]<>"")
		  {
		    $total_impressions=$total[0];
			echo $total[0];
		  }
		  else
		  {
		  echo $config["null_char"];
		  }
		  ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00005_AD_HOME.""; /*-~- Total Clicks Received -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
  <?php 
				              
		  $total=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select sum(clicks) from sbbanners_ads where adv_id=$id"));
		  $total_clicks=0;
		              
		  if($total[0]<>"")
		  {
		    $total_clicks=$total[0];
			echo $total[0];
		  }
		  else
		  {
		  echo $config["null_char"];
		  }
		  ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00006_AD_HOME.""; /*-~- Average Click Through Rate -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
  <?php 
				  
		  if($total_impressions<>0)
		  {
			echo round(($total_clicks/$total_impressions)*100,2)."%";
		  }
		  else
		  {
		  echo $config["null_char"];
		  }
		  ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00007_AD_HOME." "; /*-~- Latest Impression -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
  <?php 
				              
				$latest_dis=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select unix_timestamp(ondate) as t from sbbanners_displays where adv_id=$id order by id desc"));
				            
				if($latest_dis)
				{
				echo sb_date($latest_dis["t"]);
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00008_AD_HOME." "; /*-~- Latest Click -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php 
				$latest_clk=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select unix_timestamp(ondate) as t from sbbanners_clicks where adv_id=$id order by id desc"));
				if($latest_clk)
				{
				echo sb_date($latest_clk["t"]);
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>


@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00000_AD_HOME,'data'=>'section-one'])
        
 
<?php 
		  $most_viewed =mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_ads where adv_id=$id and paid<>'no' and displays>0 and alowban_size='yes' order by displays desc"));
			  if($most_viewed)
				{		 	 

		  ?>
@section('section-two')
<br>
<?php 
//Most Displayed Banner/Text Ad
?>


<?php 
				              
				  $des_url= $most_viewed['url'];
				  $title=$most_viewed['title'];
				$des1=$most_viewed['description1'];
				$des2=$most_viewed['description2'];
				$dis_url=$most_viewed['displayurl'];
				            
				$size=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where id=".$most_viewed["size_id"]));
				if($most_viewed["textad"]=="yes" )
				{
					echo "<table  border='0' cellpadding='0' cellspacing='1' class='borderstyle'><tr><td>";
					
					echo "<table width='234' height='60' border='0' cellpadding='0' cellspacing='0' class='tablebgcolor'>";
					echo "<tr> ";
				 echo "<td><font class='textdescription'>&nbsp;<a class='titletextadlinkstyle'href='". $des_url."'   target='_blank'>".$title ."</a></font></td>";
				echo "</tr>";
				echo "<tr> ";
				echo  "<td><font class='textdescription'>&nbsp;". $des1."</font></td></tr>";
					echo "<tr><td><font class='textdescription'>&nbsp;".$des2."</font></td></tr>";
					  
			echo "<tr><td><font class='textdescription'>&nbsp;<a class='textadlink' href='". $des_url."'    target='_blank'>". $dis_url."</a></font></td></tr></table></td></tr></table> ";
				}
				else
				{
				if($most_viewed["banner_type"]!="flash")
				{
				?>
                  <img  src="banners/<?php echo $most_viewed["bannerurl"];?>" width=<?php echo $size["width"];?> height=<?php echo $size["height"];?>><br>
                  <?php

}
				   else
				   {
				   ?><br><embed src="<?php echo "banners/". $most_viewed["bannerurl"]; ?>" 

width="<?php echo $size["width"];?>" height="<?php echo $size["height"];?>" PLAY="true" quality="best" PLUGINSPAGE=" http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></embed><?php
}
				   }
                  ?>

@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00009_AD_HOME,'data'=>'section-two'])
 <?php
}
?>
        


<?php 
			              
		  $most_clicked =mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_ads where adv_id=$id and paid<>'no' and clicks>0 and alowban_size='yes' order by clicks desc"));
		              
		 if($most_clicked)
				{
		  ?>
@section('section-three')
<br>
<?php 
//Most Clicked Banner/Text Ad
?>

 <?php 
				              
				 $des_url= $most_clicked['url'];
				  $title=$most_clicked['title'];
				$des1=$most_clicked['description1'];
				$des2=$most_clicked['description2'];
				$dis_url=$most_clicked['displayurl'];
				 $size=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where id=".$most_clicked["size_id"]));
				             
				if($most_clicked["textad"]=="yes" )
				{
					echo "<table  border='0' cellpadding='0' cellspacing='1' class='borderstyle'><tr><td>";
					
					echo "<table width='234' height='60' border='0' cellpadding='0' cellspacing='0' class='tablebgcolor'>";
					echo "<tr> ";
				 echo "<td><font class='textdescription'>&nbsp;<a class='titletextadlinkstyle'href='". $des_url."'   target='_blank'>".$title ."</a></font></td>";
				echo "</tr>";
				echo "<tr> ";
				echo  "<td><font class='textdescription'>&nbsp;". $des1."</font></td></tr>";
					echo "<tr><td><font class='textdescription'>&nbsp;".$des2."</font></td></tr>";
					  
			echo "<tr><td><font class='textdescription'>&nbsp;<a class='textadlink' href='". $des_url."'    target='_blank'>". $dis_url."</a></font></td></tr></table></td></tr></table> ";
				}
				else
				{
				if($most_clicked["banner_type"]!="flash")
				{
				?>
                  <img src="banners/<?php echo $most_clicked["bannerurl"];?>" width=<?php echo $size["width"];?> height=<?php echo $size["height"];?>><br>
                  <?php
}
				   else
				   {
				   ?>
                  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="<?php echo $size["width"];?>" height="<?php echo $size["height"];?>">
                    <param name="movie" value="">
                    <param name="quality" value="high">
                    <embed src="<?php echo "banners/". $most_clicked["bannerurl"]; ?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="<?php echo $size["width"];?>" height="<?php echo $size["height"];?>"></embed></object><br>
                  <?php
}
				   }
				?>

@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00010_AD_HOME,'data'=>'section-three'])

<?php

				}
				
				?>

@section('section-four')
<?php 
//Stats: Clicks / Impressions
?>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00012_AD_HOME.""; /*-~- Today -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
				              
             	
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)=0 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)=0 "));
				            
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00013_AD_HOME.""; /*-~- Yesterday -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)=1 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)=1 "));
				            
				if($clicks||$display)
				{

				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00014_AD_HOME.""; /*-~- Last 7 Days -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)<=7 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)<=7 "));
				            
			if($clicks||$display)
				{

				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00015_AD_HOME.""; /*-~- Last 14 Days -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)<=14 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and TO_DAYS(NOW())-TO_DAYS(ondate)<=14 "));
				            
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00016_AD_HOME.""; /*-~- Last Year -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and DATE_FORMAT(ondate,'%Y')=".(date("Y",time())-1)));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and DATE_FORMAT(ondate,'%Y')=".(date("Y",time())-1)));
				            
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>


@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00011_AD_HOME,'data'=>'section-four'])



@section('section-five')
<?php 
//This Year: Clicks / Impressions
?>
<?php
				for($i=1;$i<=12;$i++)
				{
				            
				$date1=date("Y",time()).$i;
			$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and DATE_FORMAT(ondate,'%Y%c')=$date1"));
		$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and DATE_FORMAT(ondate,'%Y%c')=$date1"));
            
                ?>
<div class="row">
<div class="col-md-4 bold-text">
<?php
switch($i)
				{
				case 1: echo /*2s*/ "".SOFTBIZ_LC00019_AD_HOME."" /*-~-* / "January" / *-~-*/ /*2e*/ ;break;
				case 2: echo /*2s*/ "".SOFTBIZ_LC00020_AD_HOME."" /*-~-* / "Febuary" / *-~-*/ /*2e*/ ;break;
				case 3: echo /*2s*/ "".SOFTBIZ_LC00021_AD_HOME."" /*-~-* / "March" / *-~-*/ /*2e*/ ;break;
				case 4: echo /*2s*/ "".SOFTBIZ_LC00022_AD_HOME."" /*-~-* / "April" / *-~-*/ /*2e*/ ;break;
				case 5: echo /*2s*/ "".SOFTBIZ_LC00023_AD_HOME."" /*-~-* / "May" / *-~-*/ /*2e*/ ;break;
				case 6: echo /*2s*/ "".SOFTBIZ_LC00024_AD_HOME."" /*-~-* / "June" / *-~-*/ /*2e*/ ;break;
				case 7: echo /*2s*/ "".SOFTBIZ_LC00025_AD_HOME."" /*-~-* / "July" / *-~-*/ /*2e*/ ;break;
				case 8: echo /*2s*/ "".SOFTBIZ_LC00026_AD_HOME."" /*-~-* / "August" / *-~-*/ /*2e*/ ;break;
				case 9: echo /*2s*/ "".SOFTBIZ_LC00027_AD_HOME."" /*-~-* / "September" / *-~-*/ /*2e*/ ;break;
				case 10: echo /*2s*/ "".SOFTBIZ_LC00028_AD_HOME."" /*-~-* / "October" / *-~-*/ /*2e*/ ;break;
				case 11: echo /*2s*/ "".SOFTBIZ_LC00029_AD_HOME."" /*-~-* / "November" / *-~-*/ /*2e*/ ;break;
				case 12: echo /*2s*/ "".SOFTBIZ_LC00030_AD_HOME."" /*-~-* / "December" / *-~-*/ /*2e*/ ;break;
				}
				?>
</div>
<div class="col-md-6">
<?php 
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>
</div>
<?php
}
            ?>
@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00017_AD_HOME,'data'=>'section-five'])





@section('section-six')
<?php 
//This Month: Clicks / Impressions
?>

<div class="row">
<?php
for($i=1;$i<=30;$i++)
				{
				            
				$date1=date("Ym",time()).$i;
				$date2=date("Ym",time()).($i+10);
				$date3=date("Ym",time()).($i+20);
			$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
			$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
			$display2=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date2"));
			$clicks2=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date2"));
			$display3=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date3"));
			$clicks3=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date3"));
				            
                ?>
 <?php
 if($i==1 || $i==11 || $i==21)
 {
 ?> <div class="col-md-4"> 
 <div class="row">
 <?php
				}
				?>
  
  
               
<div class="col-md-4 bold-text">
<strong> <?php echo $i;
				?> </strong>
</div>
<div class="col-md-8">
 <?php 
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>

 <?php
 if($i==10 || $i==20 )
 {
 ?> </div></div> 
 <?php
				}
				?>
  
  
<?php
				}
				?>


<div class="col-md-4 bold-text">
<strong> <?php echo 31;
				?> </strong>
</div>
<div class="col-md-8">
<?php
				            
$date1=date("Ym",time())."31";
			$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
			$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
            
				?> <?php 
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>

<?php
// Special case ending column number 3
echo "</div></div>";

?>
</div>


@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00018_AD_HOME,'data'=>'section-six'])




 