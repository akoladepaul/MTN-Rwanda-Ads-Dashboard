<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>
@section('textad-help')
<br>

<?php	echo $edit_guideline; ?>
@endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'textad-help'])

