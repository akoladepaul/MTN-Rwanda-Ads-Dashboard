<?php
foreach($vars as $k=>$v)  { $$k=$v;}
//echo "---" . $sb_username;


 
?>

<div class="top-bar">
<div class="row">


      <div class="col-sm-6 col-xs-4 col-md-offset-2 col-lg-offset-2 col-xl-offset-2  col-md-4  col-lg-4  col-xl-4">
       </div>
       <div class="col-sm-6 col-xs-8 col-md-6  col-lg-6  col-xl-6">
             
                    
  <?php 
	if($lang_enable==1)
	{
		if(isset($_COOKIE["softbizAuctionsLanguageCookie"]))
			$sblang_id=$_COOKIE["softbizAuctionsLanguageCookie"];
		else
			$sblang_id=$config["sbdefault_lang"];
	?>
		 <div class="social" style="display:inline">
                       
                         <ul class="social-share">
        <?php
		$tmp_cnt=0;
		$sbflag_path=sbimg_path_converter("sbads_icons/");
		while($sbrow_lang=mysqli_fetch_array($sbrs_lang) )
		{ 		
			$tmp_cnt++;
			?>
			<li><a href="change_language.php?sbl=<?php echo $sbrow_lang["sb_id"]."&sbr=".urlencode($_SERVER['PHP_SELF']).$strpass; ?>"><img src="<?php echo $sbflag_path.$sbrow_lang["sbflag_image"]; ?>" width="25" height="15" border="0" title="<?php echo $sbrow_lang["sblanguage"]; ?>" /></a> </li>
<?php	}	?>
</ul>
		</div>
<?php	
	}	//lang_enable
	
  ?>                            
                    
       
      </div>        
                        
                            
         </div>
  <!--/.container-->
        <!--/.top-bar--></div>
        <?php
?>