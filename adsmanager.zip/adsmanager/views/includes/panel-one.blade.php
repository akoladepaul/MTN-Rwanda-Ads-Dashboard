
<div class="card ">
  <div class="card-header card-style-one-header-color-one">
    {!!$title!!} 
  </div>
  <div class="card-block style-one-block-color-one">
    <p class="card-text">@yield($data)</p>
  </div>
</div>