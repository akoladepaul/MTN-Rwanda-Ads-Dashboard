<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>
 
@section('menu-one')
<?php 
//Advertiser Menu
?>

<ul class="latest">

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="ad_home.php" class="insidelink" ><?php /*1s*/ echo "".SOFTBIZ_LC00001_LEFT_PANEL.""; /*-~- Home -~-*/ /*1e*/ ?></a>
</li>

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="editmember.php"><?php /*1s*/ echo "".SOFTBIZ_LC00002_LEFT_PANEL.""; /*-~- Edit Profile -~-*/ /*1e*/ ?></a>
</li>


<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="changepassword.php"><?php /*1s*/ echo "".SOFTBIZ_LC00001_CHANGEPASSWORD.""; /*-~- Change Password -~-*/ /*1e*/ ?></a>
</li>

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="logout.php"><?php /*1s*/ echo "".SOFTBIZ_LC00003_LEFT_PANEL.""; /*-~- Logout -~-*/ /*1e*/ ?></a>
</li>

</ul>


@endsection
@include('includes.panel-one', ['title' =>SOFTBIZ_LC00000_LEFT_PANEL,'data'=>'menu-one'])
        
 

        


  @section('menu-two')
<?php 
//My Ads
?>

<ul class="latest">

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="choose_banner.php" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00005_LEFT_PANEL.""; /*-~- Add New Ad -~-*/ /*1e*/ ?></a>
</li>

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="ads.php" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00006_LEFT_PANEL." "; /*-~- Manage Ads -~-*/ /*1e*/ ?></a></li>


<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="ads.php?package=1" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00005_BUY_MORE." "; /*-~- Impressions Based -~-*/ /*1e*/ ?></a></li>

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="ads.php?package=2" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00006_BUY_MORE." "; /*-~- Click Based -~-*/ /*1e*/ ?></a></li>


<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="ads.php?package=3" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00007_BUY_MORE." "; /*-~- Time Based -~-*/ /*1e*/ ?></a>
</li>

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="ads.php?ad_type=text"><?php /*1s*/ echo "".SOFTBIZ_LC00007_LEFT_PANEL.""; /*-~- All Text Ads -~-*/ /*1e*/ ?></a>
</li>


<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="ads.php"><?php /*1s*/ echo "".SOFTBIZ_LC00008_LEFT_PANEL.""; /*-~- All Banners -~-*/ /*1e*/ ?></a>
</li>

</ul>


@endsection
@include('includes.panel-one', ['title' =>SOFTBIZ_LC00004_LEFT_PANEL,'data'=>'menu-two'])



 
@section('menu-three')
<?php 
// My Account
?>

<ul class="latest">

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="addmoney.php" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00008_MYACCOUNT." "; /*-~- Add Money -~-*/ /*1e*/ ?></a>
</li>

<li><i class="glyphicon glyphicon-fire side-icon-color"></i>&nbsp;
<a href="myaccount.php" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00009_LEFT_PANEL.""; /*-~- My Account -~-*/ /*1e*/ ?></a>
</li>

</ul>


@endsection
@include('includes.panel-one', ['title' =>SOFTBIZ_LC00009_LEFT_PANEL,'data'=>'menu-three'])


 