<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?><footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
             <?php   
                printf(SOFTBIZ_LCUPDT2015111000000_10);
			?>	
				
                    
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                      
                        
                        
<li >
<a href="ad_home.php"  ><?php /*1s*/ echo "".SOFTBIZ_LC00001_LEFT_PANEL.""; /*-~- Home -~-*/ /*1e*/ ?></a>
</li>
<li >
<a href="myaccount.php" ><?php /*1s*/ echo "".SOFTBIZ_LC00009_LEFT_PANEL.""; /*-~- My Account -~-*/ /*1e*/ ?></a></li>

<li >
<a href="choose_banner.php" ><?php /*1s*/ echo "".SOFTBIZ_LCUPDT2015111000000_13.""; /*-~- Post New Ad -~-*/ /*1e*/ ?></a></li>

                        
                        
                        
                        
                        
                        
                    </ul>
                </div>
            </div>
            
                  <div class="row">
                <div class="col-sm-12">
      
            <? echo $config["html_footer"];?>
            </div>
            </div>
        </div>
    <!--/#footer--></footer>