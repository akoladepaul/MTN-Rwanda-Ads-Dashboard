


<div class="card ">
  <div class="card-header card-style-one-header-color-two">
    {!!$title!!} 
  </div>
  <div class="card-block style-one-block-color-two">
    <p class="card-text">@yield($data)</p>
  </div>
</div>