    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta name="author" content="">
   
	
	<!-- core CSS -->
    <!--link href="css/bootstrap.min.css" rel="stylesheet"-->
     <link href="css/bootstrap4.css" rel="stylesheet">
   <!--link href="css/font-awesome.min.css" rel="stylesheet"-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/<?=$theme_to_use ?>" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">

         <link href="css/owl.carousel.css" rel="stylesheet">

          <link href="css/stacktable.css" rel="stylesheet">
      
          
         
       <link href="css/owl.theme.default.min.css" rel="stylesheet"> 
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       


     <link href="css/ekko-lightbox.min.css" rel="stylesheet">

   <link href="css/social.css" rel="stylesheet">

<title><?php echo $title_str;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo (defined("SBCHAR_ENCODING"))?SBCHAR_ENCODING:"utf-8"; ?>">
<meta name="keywords" content="<?php echo $site_keywords;?>"> 
<meta name="description" content="<?php echo $site_desc;?>"> 


<script language="JavaScript" type="text/javascript" src="ajax.php"></script>
<script language="JavaScript" type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script language="JavaScript" type="text/javascript" src="sbticker.js"></script>

<script language="JavaScript" type="text/javascript" src="js/owl.carousel.min.js"></script>


<script language="JavaScript" type="text/javascript" src="js/stacktable.js"></script>
<script language="JavaScript" type="text/javascript" src="js/ekko-lightbox.js"></script>




<script language="JavaScript" type="text/JavaScript">
<!--
function sbiz_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>


<script language="JavaScript" type="text/javascript" src="softbiz_functions_js.php"></script>


<?php 
//require_once "styles.php";
?>



