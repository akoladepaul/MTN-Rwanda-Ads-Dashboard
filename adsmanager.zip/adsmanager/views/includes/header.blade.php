<header id="header">
<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>
<?php
$data=array(
'lang_enable'=>$lang_enable,
'vars'=>$vars,
);


?>
@include('includes.top-bar')     
@include('includes.nav-bar')     
</header>

                 <div class="row">
                <div class="col-sm-12 text-center">
      
            <? echo $config["html_header"];?>
            </div>
            </div>
        </div>

            <div class="row">
                <div class="col-sm-12 text-center">

 <?php
if ( isset($_REQUEST["msg"])&&$_REQUEST['msg']<>"")
{
print(sbhtmlentities(stripslashes($_REQUEST['msg']),ENT_QUOTES)); 
}
else
{
echo " ";
}
//end if
?><br><Br>
</div>
</div>