<?php

$title_to_use=(isset($modal_title))?$modal_title:SOFTBIZ_LC00004_FILEUPLOAD;
$id_to_use=(isset($modal_id))?$modal_id:"myModal";
$iframe_to_use=(isset($modal_iframe))?$modal_iframe:"upload-iframe";

?><div id="{{$id_to_use}}" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">{{$title_to_use}} {{--Image uploader --}}</h4>
      </div>
      <div class="modal-body">
      
      <iframe id="{{$iframe_to_use}}" src="" style="zoom:0.60" frameborder="0" height="250" width="99.6%">
 
      
      </iframe>
        
 
   


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>