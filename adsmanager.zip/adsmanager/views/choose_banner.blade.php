<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>

 @section('choose-banner')

 <form class="form-horizontal"  name="form123" onsubmit="return(formValidate(this));" method="post" action="choose_type.php">


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00001_CHOOSE_BANNER.""; /*-~- Choose Ad Type -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="adtype" type="radio" value="banner" checked> <?php /*1s*/ echo "".SOFTBIZ_LC00001_UPDATE_IMPRESSIONS.""; /*-~- Banner Ad -~-*/ /*1e*/ ?><br>
<input name="adtype" type="radio" value="text"> <?php /*1s*/ echo "                                      ".SOFTBIZ_LC00002_UPDATE_IMPRESSIONS.""; /*-~- Text Ad -~-*/ /*1e*/ ?><br>
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">
<input class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00014_CHOOSE_TYPE.""; /*-~- Continue -~-*/ /*1e*/ ?>" name=submit>
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">

  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">

  </div>
</fieldset>


</form>  
    @endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'choose-banner'])

