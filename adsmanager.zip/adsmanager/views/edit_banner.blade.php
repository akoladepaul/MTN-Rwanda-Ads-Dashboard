
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>





@section('package')

@include('includes.modal' , array('submit_to'=>'')) 


 <form   name=form123 onsubmit="return(formValidate(this));" method="post" action="update_banner.php">








<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00004_ADVERTISE.""; /*-~- Banner Type -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">

<select name="banner_type" onChange="dis_desti(this.form);">
                              <option value="image" <?php if(sbhtmlentities($rst["banner_type"],ENT_QUOTES)=="image") echo "selected";?>><?php /*1s*/ echo "".SOFTBIZ_LC00005_ADVERTISE.""; /*-~- Image(.jpg/.gif) -~-*/ /*1e*/ ?></option>
                              <option value="flash" <?php if(sbhtmlentities($rst["banner_type"],ENT_QUOTES)=="flash") echo "selected";?>><?php /*1s*/ echo "".SOFTBIZ_LC00006_ADVERTISE.""; /*-~- Flash(.swf) -~-*/ /*1e*/ ?></option>
                            </select>
  </div>
</fieldset>

  
  <fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00007_ADVERTISE." "; /*-~- Destination URL -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<INPUT name=url  class="form-control"  value="<?php echo sbhtmlentities($rst["url"],ENT_QUOTES);?>" size=25> <input name="id" type="hidden" id="id" value="<?php echo $id;?>">
<small class="text-muted">
<?php /*1s*/ echo "".SOFTBIZ_LC00001_EDIT_BANNER.""; /*-~- Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com -~-*/ /*1e*/ ?>
</small>
  </div>
</fieldset>



<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""><?php /*1s*/ echo "".SOFTBIZ_LC00009_ADVERTISE." "; /*-~- Banner Image -~-*/ /*1e*/ ?></label>  
  <div class="col-md-7">

  <INPUT type="hidden"  class="form-control"   name="bannerurl" id="bannerurl" value="<?php echo sbhtmlentities($rst["bannerurl"],ENT_QUOTES);?>" >
    <button name="logo_upload_button" class="btn btn-primary" id="logo_upload_button" type="button" data-toggle="modal" data-target="#myModal">Upload Image</button>
  </div>
</fieldset>
<script>
$("#logo_upload_button").click(function () { 
//alert("fileupload.php?box=bannerurl&ban_type=" + form123.banner_type.value   );
      $("#upload-iframe").attr("src", "fileupload.php?box=bannerurl&ban_type=" + form123.banner_type.value);
});
</script>



<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">
<input name="sbplan" type="hidden" id="sbplan" value="<?php echo $sbplan; ?>"> 
<input class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00020_EDIT_TEXTAD.""; /*-~- Update -~-*/ /*1e*/ ?>" name=submit> 
            <?php if($config["approval_type"]=='admin'){?>
            <br><?php /*1s*/ echo "".SOFTBIZ_LC00021_EDIT_TEXTAD.""; /*-~- Your Banner will not be displayed until Admin approves the changes. -~-*/ /*1e*/ ?>  
            <?php }	//end if?>            
  </div>
</fieldset>






</form>


 
@endsection
@include('includes.panel-two', ['title' =>$form_title,'data'=>'package'])