<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>

 @section('choose-banner')
 <?php 
	if($num<=0)
	{
	echo "<font size=2 color='#333333' face='Arial, Helvetica, sans-serif'><strong>"./*2s*/ "".SOFTBIZ_LC00008_BUY_MORE." " /*-~-* / "Banner Not Found. Click" / *-~-*/ /*2e*/ ."<a href='ad_home.php'>"./*2s*/ "".SOFTBIZ_LC00009_BUY_MORE."" /*-~-* / "here" / *-~-*/ /*2e*/ ."</a> "./*2s*/ "".SOFTBIZ_LC00010_BUY_MORE."" /*-~-* / "to continue" / *-~-*/ /*2e*/ ."</strong></font>";
	return;
	}
	?>
    

 <form class="form-horizontal"   name=register method=post action="update_impressions.php">


<?php if($rst["size_id"]!= -1)
				  {?>
                  
 <?php 
							              
	$size_query=mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where id=".$rst["size_id"]);
		$cnt=0;
		            
		while($size=mysqli_fetch_array($size_query))
		{
									?>

 <div class="row">                     
 <div class="col-md-12 specific-info darkgray">
                      

<?php /*1s*/ echo "".SOFTBIZ_LC00002_ADVERTISE.""; /*-~- Package Type -~-*/ /*1e*/ ?>: <?php echo $dis; ?>
</div>   
</div>


   <div class="row">      
 <div class="col-md-12 specific-info" >
       
        <strong><?php /*1s*/ echo "".SOFTBIZ_LC00006_CHOOSE_TYPE." "; /*-~- Size -~-*/ /*1e*/ ?>:</strong>  <?php echo $size["width"]."x".$size["height"]; ?><?php /*1s*/ echo " ".SOFTBIZ_LC00007_CHOOSE_TYPE." "; /*-~- px -~-*/ /*1e*/ ?>  <?php if ($size["sbnotes"]<>"")
			  					echo "[" . $size["sbnotes"] . "]" ;?> 
                                
</div>             
</div>

<?php
							              
$sql="select * from sbbanners_plans where sbtype=".$rst["sbtype"]." and size_id=".$size["id"]." order by  price desc ";

$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
             
	              	
while ($rs0=mysqli_fetch_array($rs0_query))
{
$cnt++;
?>


<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"] . " ";
if($rst["sbtype"]==1){
echo SOFTBIZ_LC00003_CHOOSE_TYPE . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Impressions for 
}
else
{
	
if($rst["sbtype"]==2){
echo SOFTBIZ_LC00009_CHOOSE_TYPE . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Clicks for 
}
else
{
	echo ($rs0["credits"]==1)? /*2s*/ " ".SOFTBIZ_LC00003_MYACCOUNT."" /*-~-* / "Month" / *-~-*/ /*2e*/ :/*2s*/ " ".SOFTBIZ_LC00016_CHOOSE_TYPE."" /*-~-* / "Months" / *-~-*/ /*2e*/ ;

echo SOFTBIZ_LCUPDT2015111000000_12; //for ;
}

}

?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>
 <?php
}
 }
 ?>
                              <?php 	if($cnt>0)	
 							{		// means rec found display continue button?>
                            
                            
                            
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">
<input name="id" type="hidden" id="id" value="<?php echo $rst["id"];?>"> 
  <input name="sbstrpass" type="hidden" id="sbstrpass" value="<?php echo $sbstrpass;?>">                                <input type="submit" class="btn btn-primary" value="<?php /*1s*/ echo "".SOFTBIZ_LC00001_BUY_MORE.""; /*-~- Buy Now -~-*/ /*1e*/ ?>" name="submit">
                                  
  </div>
</fieldset>

<div class="row">
<div class="col-md-12 ">
<?php /*1s*/ echo "".SOFTBIZ_LC00007_FILEUPLOAD.""; /*-~- NOTE -~-*/ /*1e*/ ?>:<?php /*1s*/ echo "                                  ".SOFTBIZ_LC00002_BUY_MORE.""; /*-~- This process is irreversible, money once paid can't be refunded. -~-*/ /*1e*/ ?>
</div>
</div>
<?php 
							}
							else
							{?>
                            <?php /*1s*/ echo "".SOFTBIZ_LC00003_BUY_MORE.""; /*-~- There is no package available for this banner size. -~-*/ /*1e*/ ?>
                             <?php 
							}		//end if else?>
                            
 
 <?php }else{//$rst["size_id"]?>
 
  <?php 
									$cnt=0;
																		?>
                                                                                                   
 <?php
							              
$sql="select * from sbbanners_textad_plans where sbtype=".$rst["sbtype"]." order by  price desc ";

$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
             
	              	
while ($rs0=mysqli_fetch_array($rs0_query))
{
$cnt++;
?>
<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"] . " ";
if($rst["sbtype"]==1){
echo SOFTBIZ_LC00003_CHOOSE_TYPE . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Impressions for 
}

else
{
	
if($rst["sbtype"]==2){
echo SOFTBIZ_LC00009_CHOOSE_TYPE . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Clicks for 
}
else
{
	echo ($rs0["credits"]==1)? /*2s*/ " ".SOFTBIZ_LC00003_MYACCOUNT."" /*-~-* / "Month" / *-~-*/ /*2e*/ :/*2s*/ " ".SOFTBIZ_LC00016_CHOOSE_TYPE."" /*-~-* / "Months" / *-~-*/ /*2e*/ ;

echo SOFTBIZ_LCUPDT2015111000000_12; //for ;
}

}

?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>

 <?php
}
 ?>
                              <?php 	if($cnt>0)	
 							{		// means rec found display continue button?>
                            
                            
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">
<input name="id" type="hidden" id="id2" value="<?php echo $rst["id"];?>"> 
 <input name="sbstrpass" type="hidden" id="sbstrpass" value="<?php echo $sbstrpass;?>">                                 <input type="submit" value="<?php /*1s*/ echo "".SOFTBIZ_LC00001_BUY_MORE.""; /*-~- Buy Now -~-*/ /*1e*/ ?>"  name="submit">
                                  
  </div>
</fieldset>


<div class="row">
<div class="col-md-12 ">
<?php /*1s*/ echo "".SOFTBIZ_LC00007_FILEUPLOAD.""; /*-~- NOTE -~-*/ /*1e*/ ?>:<?php /*1s*/ echo "                                  ".SOFTBIZ_LC00002_BUY_MORE.""; /*-~- This process is irreversible, money once paid can't be refunded. -~-*/ /*1e*/ ?>
</div>
</div>


<?php 
							}
							else
							{?><?php /*1s*/ echo "".SOFTBIZ_LC00004_BUY_MORE.""; /*-~- There is no package available for this text ad. -~-*/ /*1e*/ ?> <?php 
							}		//end if else?>
                            
  <?php }//$rst["size_id"]?>                          



</form>  
    @endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'choose-banner'])




                              
            