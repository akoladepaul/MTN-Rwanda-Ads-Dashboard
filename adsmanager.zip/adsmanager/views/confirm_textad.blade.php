
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>

@section('package')

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_CHOOSE_TYPE." "; /*-~- Package Name -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sbrow_chk["sbname"]; ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_ADVERTISE.""; /*-~- Package Type -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo  $dis?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00004_CHOOSE_TYPE.""; /*-~- Price -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sb_fee_currency.sbcurrency_format($sbrow_chk["price"]); ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
 <?php 
				$month="";
				if($sbrow_chk["sbtype"]==1)	
				echo /*2s*/ "".SOFTBIZ_LC00003_CHOOSE_TYPE."" /*-~-* / "Impressions" / *-~-*/ /*2e*/ ;
				elseif($sbrow_chk["sbtype"]==2)
				echo /*2s*/ "".SOFTBIZ_LC00009_CHOOSE_TYPE."" /*-~-* / "Clicks" / *-~-*/ /*2e*/ ;
				else
				{
				echo /*2s*/ "".SOFTBIZ_LC00012_CHOOSE_TYPE."" /*-~-* / "Duration" / *-~-*/ /*2e*/ ;
				$month=($sbrow_chk['credits']==1)?/*2s*/ " ".SOFTBIZ_LC00003_MYACCOUNT."" /*-~-* / "Month" / *-~-*/ /*2e*/ :/*2s*/ " ".SOFTBIZ_LC00016_CHOOSE_TYPE."" /*-~-* / "Months" / *-~-*/ /*2e*/ ;
				} ?>
</div>
<div class="col-md-6">
 <?php echo $sbrow_chk['credits'].$month;?>
</div>
</div>



<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00010_EDIT_TEXTAD.""; /*-~- Title -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo sbhtmlentities(stripslashes($_POST['title']),ENT_QUOTES)?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00013_EDIT_TEXTAD.""; /*-~- Description 1 -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo sbhtmlentities(stripslashes($_POST['description1']),ENT_QUOTES)?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00015_EDIT_TEXTAD.""; /*-~- Description 2 -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo sbhtmlentities(stripslashes($_POST['description2']),ENT_QUOTES)?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00016_EDIT_TEXTAD.""; /*-~- Display Url -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo sbhtmlentities(stripslashes($_POST['display_url']),ENT_QUOTES)?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00007_ADVERTISE.""; /*-~- Destination URL -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo sbhtmlentities(stripslashes($_POST['url']),ENT_QUOTES)?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">

</div>
<div class="col-md-2">

<FORM name="form123"  id="form123" method="post" action="insert_textad.php">
						 <input name="sbplan" type="hidden" id="sbplan" value="<?php echo $sbplan; ?>"> 
                          <input name="title" type="hidden" id="title" value=" <?php echo sbhtmlentities(stripslashes($_POST['title']),ENT_QUOTES)?>"> 
                          <input name="description1" type="hidden" id="description1" value="<?php echo sbhtmlentities(stripslashes($_POST['description1']),ENT_QUOTES)?>"> 
                          <input name="description2" type="hidden" id="description2" value="<?php echo sbhtmlentities(stripslashes($_POST['description2']),ENT_QUOTES)?>"> 
                          <input name="url" type="hidden" id="url" value="<?php echo sbhtmlentities(stripslashes($_POST['url']),ENT_QUOTES)?>"> 
                          <input name="display_url" type="hidden" id="display_url" value="<?php echo sbhtmlentities(stripslashes($_POST['display_url']),ENT_QUOTES)?>"> 
                          <!--input name="sbvarify" type="hidden" id="sbvarify" value="<?php //echo $_REQUEST['sbvarify'];?>"-->
                          <input class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00001_CONFIRM_TEXTAD.""; /*-~- Add -~-*/ /*1e*/ ?>" name=submit> 
                      </form>
                      

</div>
<div class="col-md-2">
 <FORM class="form-inline" name="cancel_frm"  id="cancel_frm" method="post" action="ads.php">
						   <input class="btn btn-danger" type="submit" name="Submit" value="<?php /*1s*/ echo "".SOFTBIZ_LC00002_CONFIRM_TEXTAD.""; /*-~- Cancel -~-*/ /*1e*/ ?>" >
                      </form>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
</div>
<div class="col-md-6">
<strong><?php /*1s*/ echo "".SOFTBIZ_LC00003_CONFIRM_TEXTAD.""; /*-~- NOTE: -~-*/ /*1e*/ ?></strong>
<?php /*1s*/ echo "".SOFTBIZ_LC00002_BUY_MORE.""; /*-~- This process is irreversible, money once paid can't be refunded. -~-*/ /*1e*/ ?>
</div>
</div>
@endsection
@include('includes.panel-one', ['title' =>$form_title,'data'=>'package'])


  
        
                    