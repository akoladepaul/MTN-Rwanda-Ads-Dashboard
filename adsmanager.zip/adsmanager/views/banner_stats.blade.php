<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>
 
           
 
@section('section-one')
<?php 
// Aggregate Banner Statistics For All Your Banners
?>

<div class="row product-cell   " >
<div class="col-md-12 col-lg-12 col-xl-12 text-center search-result-item">
<?php if($rs0['textad']=='no') 
					{ ?>

 <?php
if($rs0["banner_type"]!="flash")
				{
				?>
                  <img src="banners/<?php echo $rs0["bannerurl"];?>" width=<?php echo $size["width"];?> height=<?php echo $size["height"];?>> 
                  <?php
}
					else
					{
					?>
                    
  <embed src="<?php echo "banners/". $rs0["bannerurl"]; ?>" 

width="<?php echo $size["width"];?>" height="<?php echo $size["height"];?>" PLAY="true" quality="best" PLUGINSPAGE=" http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></embed> 
                  <?php
}
			?>
            
 <?php 
			  } else {
			  ?>
    <?php $tbwid=234;
						$tbheight=60;
						$row=(int)($size["height"]/$tbheight);
						$column=(int)($size["width"]/$tbwid);
						//$tdwid=$wid/$column;
						//$tdheight=$height/$row;
						//echo $row." -----------".$column;
						?>          
            <table width="234" height="60" border="0" cellpadding="0" cellspacing="0" class="tablebgcolor">
							<tr> 
				            <td><font class='textdescription'>&nbsp;<a class="titletextadlinkstyle" href="<?php echo $rs0['url'];  ?>" target="_blank"><?php echo $rs0['title'];  ?></a></font></td>
					</tr>
					<tr> 
				  <td><font class="textdescription">&nbsp;<?php echo $rs0['description1'];  ?></font></td>
					  </tr>
					<tr>  
				  <td><font class="textdescription">&nbsp;<?php echo $rs0['description2'];  ?></font></td>
				</tr>
					<tr> 
				  <td><font class='textdescription'>&nbsp;<a class="textadlink" href="<?php echo $rs0['url'];  ?>" target="_blank"><?php echo $rs0['displayurl'];  ?></a></font></td>
					</tr>
				  </table>
                  
      <?php  }//if sbtaxtad?>                                           
</div>
<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12  search-result-item">

<div class="col-sm-6 col-md-6 bold-text datarow-title">
<?php echo ($rs0["textad"]=='yes')? /*2s*/ "".SOFTBIZ_LC00002_UPDATE_IMPRESSIONS."" /*-~-* / "Text Ad" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00032_ADS."" /*-~-* / "Banner" / *-~-*/ /*2e*/ ;?> #
</div>
<div class="col-sm-6 col-md-6 text-left ">
<?php echo  $rs0["id"]; ?>
</div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title ">
<?php echo ($rs0["textad"]=='yes')? /*2s*/ "".SOFTBIZ_LC00033_ADS."" /*-~-* / "Text Ad Type" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00004_ADVERTISE."" /*-~-* / "Banner Type" / *-~-*/ /*2e*/ ;?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
 <?php
echo $dis; ?></div>

<?php if($rs0["sbtype"]!=3)
			  {	?>
<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo($rs0["sbtype"]==1)?/*2s*/ "".SOFTBIZ_LC00012_ADS."" /*-~-* / "Impressions Purchased" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00034_ADS."" /*-~-* / "Clicks Purchased" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo($rs0["sbtype"]==1)?$rs0["credits"]:$rs0["sb_clicks_purchased"]; ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo($rs0["sbtype"]==1)?/*2s*/ "".SOFTBIZ_LC00016_ADS."" /*-~-* / "Impressions Left" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00017_ADS."" /*-~-* / "Clicks Left" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo($rs0["sbtype"]==1)?($rs0["credits"]-$rs0["displays"]):($rs0["sb_clicks_purchased"]-$rs0["clicks"]); ?></div>

<?php }else { ?>

<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00013_ADS.""; /*-~- Expiry Date -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo sb_date($rs0["sb_expiry"]); ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00018_ADS.""; /*-~- Days Left -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo ($rs0["sb_left"]>=0)?$rs0["sb_left"]:/*2s*/ "".SOFTBIZ_LC00035_ADS."" /*-~-* / "Expired" / *-~-*/ /*2e*/ ; ?></div>

 <?php } ?>

<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo /*2s*/ "".SOFTBIZ_LC00015_ADS."" /*-~-* / "Clicks Received" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo $rs0["clicks"]; ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo /*2s*/ "".SOFTBIZ_LC00014_ADS."" /*-~-* / "Impressions Received" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo $rs0["displays"]; ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00023_ADS.""; /*-~- Click through Rate -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php 
						if($rs0["displays"]>0)
						{
						echo round((($rs0["clicks"]/$rs0["displays"])*100),2);
						echo "%";
						}
						else
						{
						echo "0%";
						}
						?></div>



<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo " ".SOFTBIZ_LC00024_ADS." "; /*-~- Status -~-*/ /*1e*/ ?>
</div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php 
						if($rs0["approved"]=="yes")
						{
						echo /*2s*/ "".SOFTBIZ_LC00002_AD_HOME."" /*-~-* / "Approved" / *-~-*/ /*2e*/ ;
						}
						else
						{
						echo /*2s*/ "".SOFTBIZ_LC00006_ADS."" /*-~-* / "Waiting for Approval" / *-~-*/ /*2e*/ ;
						}
						 ?></div>

<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00018_EDIT_TEXTAD." "; /*-~- Destination Url -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo($rs0["banner_type"]!="flash")? $rs0["url"]: $config['null_char'];?></div>

<?php if ($size["sbnotes"]<>"")
			  { ?>
<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00025_ADS." "; /*-~- Note -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo $size["sbnotes"]; ?></div>
<?php		}	?>





       
</div>

</div>




@endsection
@include('includes.panel-two', ['title' =>$form_title,'data'=>'section-one'])
        
 



@section('section-four')
<?php 
//Stats: Clicks / Impressions
?>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00012_AD_HOME.""; /*-~- Today -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)=0 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)=0 "));
				            
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00013_AD_HOME.""; /*-~- Yesterday -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php
				               
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)=1 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)=1 "));
				            
				if($clicks||$display)
				{

				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00014_AD_HOME.""; /*-~- Last 7 Days -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)<=7 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)<=7 "));
				            
			if($clicks||$display)
				{

				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00015_AD_HOME.""; /*-~- Last 14 Days -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)<=14 "));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id  and TO_DAYS(NOW())-TO_DAYS(ondate)<=14 "));
				            
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00016_AD_HOME.""; /*-~- Last Year -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
				              
				$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id  and DATE_FORMAT(ondate,'%Y')=".(date("Y",time())-1)));
				$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id  and DATE_FORMAT(ondate,'%Y')=".(date("Y",time())-1)));
				            
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
</div>
</div>


@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00011_AD_HOME,'data'=>'section-four'])



@section('section-five')
<?php 
//This Year: Clicks / Impressions
?>
<?php
				for($i=1;$i<=12;$i++)
				{
				            
				$date1=date("Y",time()).$i;
			$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%c')=$date1"));
		$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%c')=$date1"));
            
                ?>
<div class="row">
<div class="col-md-4 bold-text">
<?php
switch($i)
				{
				case 1: echo /*2s*/ "".SOFTBIZ_LC00019_AD_HOME."" /*-~-* / "January" / *-~-*/ /*2e*/ ;break;
				case 2: echo /*2s*/ "".SOFTBIZ_LC00020_AD_HOME."" /*-~-* / "Febuary" / *-~-*/ /*2e*/ ;break;
				case 3: echo /*2s*/ "".SOFTBIZ_LC00021_AD_HOME."" /*-~-* / "March" / *-~-*/ /*2e*/ ;break;
				case 4: echo /*2s*/ "".SOFTBIZ_LC00022_AD_HOME."" /*-~-* / "April" / *-~-*/ /*2e*/ ;break;
				case 5: echo /*2s*/ "".SOFTBIZ_LC00023_AD_HOME."" /*-~-* / "May" / *-~-*/ /*2e*/ ;break;
				case 6: echo /*2s*/ "".SOFTBIZ_LC00024_AD_HOME."" /*-~-* / "June" / *-~-*/ /*2e*/ ;break;
				case 7: echo /*2s*/ "".SOFTBIZ_LC00025_AD_HOME."" /*-~-* / "July" / *-~-*/ /*2e*/ ;break;
				case 8: echo /*2s*/ "".SOFTBIZ_LC00026_AD_HOME."" /*-~-* / "August" / *-~-*/ /*2e*/ ;break;
				case 9: echo /*2s*/ "".SOFTBIZ_LC00027_AD_HOME."" /*-~-* / "September" / *-~-*/ /*2e*/ ;break;
				case 10: echo /*2s*/ "".SOFTBIZ_LC00028_AD_HOME."" /*-~-* / "October" / *-~-*/ /*2e*/ ;break;
				case 11: echo /*2s*/ "".SOFTBIZ_LC00029_AD_HOME."" /*-~-* / "November" / *-~-*/ /*2e*/ ;break;
				case 12: echo /*2s*/ "".SOFTBIZ_LC00030_AD_HOME."" /*-~-* / "December" / *-~-*/ /*2e*/ ;break;
				}
				?>
</div>
<div class="col-md-6">
<?php 
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>
</div>
<?php
}
            ?>
@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00017_AD_HOME,'data'=>'section-five'])





@section('section-six')
<?php 
//This Month: Clicks / Impressions
?>

<div class="row">
<?php
for($i=1;$i<=30;$i++)
				{
				$date1=date("Ym",time()).$i;
				$date2=date("Ym",time()).($i+10);
				$date3=date("Ym",time()).($i+20);
			$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
			$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
			$display2=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%m%e')=$date2"));
			$clicks2=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%m%e')=$date2"));
			$display3=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%m%e')=$date3"));
			$clicks3=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id and DATE_FORMAT(ondate,'%Y%m%e')=$date3"));
				            
				            
                ?>
 <?php
 if($i==1 || $i==11 || $i==21)
 {
 ?> <div class="col-md-4"> 
 <div class="row">
 <?php
				}
				?>
  
  
               
<div class="col-md-4 bold-text">
<strong> <?php echo $i;
				?> </strong>
</div>
<div class="col-md-8">
 <?php 
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>

 <?php
 if($i==10 || $i==20 )
 {
 ?> </div></div> 
 <?php
				}
				?>
  
  
<?php
				}
				?>


<div class="col-md-4 bold-text">
<strong> <?php echo 31;
				?> </strong>
</div>
<div class="col-md-8">
<?php
				            
$date1=date("Ym",time())."31";
			$display=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_displays where adv_id=$id and banner_id=$banner_id and  DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
			$clicks=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_clicks where adv_id=$id and banner_id=$banner_id and  DATE_FORMAT(ondate,'%Y%m%e')=$date1"));
            
				?> <?php 
				if($clicks||$display)
				{
				if($clicks)
				{
				echo $clicks;
				}
				else
				{
		  echo $config["null_char"];
				}
				?>
                  /&nbsp; 
                  <?php 
				if($display)
				{
				echo $display;
				}
				else
				{
		  echo $config["null_char"];
				}
				}
				else
				{
		  echo $config["null_char"];
				}?>
</div>

<?php
// Special case ending column number 3
echo "</div></div>";

?>
</div>


@endsection
@include('includes.panel-two', ['title' =>SOFTBIZ_LC00018_AD_HOME,'data'=>'section-six'])




 