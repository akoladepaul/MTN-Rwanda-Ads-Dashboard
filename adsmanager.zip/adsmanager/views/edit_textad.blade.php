
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>
@section('pack-form')



 <form name="form123" onsubmit="return(formValidate(this));" method="post" action="update_textad.php">


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00010_EDIT_TEXTAD.""; /*-~- Title -~-*/ /*1e*/ ?><br>
<a href="textadhelp.php" target="_blank"><?php /*1s*/ echo "".SOFTBIZ_LC00011_EDIT_TEXTAD.""; /*-~- Editorial guidelines -~-*/ /*1e*/ ?></a>
  </label>
  <div class="col-md-7">
<input name="title" type="text" id="title"  onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)"  class="form-control"  value="<?php echo $rst["title"];?>">
<small class="text-muted"><?php /*1s*/ echo "".SOFTBIZ_LC00012_EDIT_TEXTAD.""; /*-~- Title should not be more than 25 characters. -~-*/ /*1e*/ ?></small>
  </div>
</fieldset>

  
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00013_EDIT_TEXTAD.""; /*-~- Description 1 -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="description1" type="text" id="description1" onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)" value="<?php echo $rst["description1"];?>"  class="form-control" > 


<small class="text-muted"><?php /*1s*/ echo "".SOFTBIZ_LC00014_EDIT_TEXTAD.""; /*-~- Description should not be more than 35 characters. -~-*/ /*1e*/ ?></small>
  </div>
</fieldset>

  
  
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00015_EDIT_TEXTAD." "; /*-~- Description 2 -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="description2" type="text" id="description2" onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)" value="<?php echo $rst["description2"];?>"  class="form-control" >
<small class="text-muted">
<?php /*1s*/ echo "".SOFTBIZ_LC00014_EDIT_TEXTAD.""; /*-~- Description should not be more than 35 characters. -~-*/ /*1e*/ ?>
</small>
  </div>
</fieldset>

  
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00016_EDIT_TEXTAD.""; /*-~- Display Url -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="display_url" type="text" id="display_url" onKeyUp="change_prv(this.form)" onClick="change_prv(this.form)" value="<?php echo $rst["displayurl"];?>" class="form-control" >

<small class="text-muted">
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00017_EDIT_TEXTAD.""; /*-~- Display url should not be more than 35 characters. -~-*/ /*1e*/ ?>
</small>
  </div>
</fieldset>

  
  <fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00007_ADVERTISE." "; /*-~- Destination URL -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<INPUT name=url  value="<?php echo $rst["url"];?>"  class="form-control"  onClick="change_prv(this.form)" onKeyUp="change_prv(this.form)">
                        
                        
         <small class="text-muted">               <?php /*1s*/ echo "                          ".SOFTBIZ_LC00007_ADVERTISE_TEXT.""; /*-~- Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com -~-*/ /*1e*/ ?>
         </small>
  </div>
</fieldset>

      <fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">
  <input name="sbplan" type="hidden" id="sbplan" value="<?php echo $sbplan; ?>">
  <input name="id" type="hidden" id="id" value="<?php echo $_REQUEST["id"];?>"> 
<input class="btn btn-primary"  type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00020_EDIT_TEXTAD.""; /*-~- Update -~-*/ /*1e*/ ?>" name=submit> 

<?php if($config["approval_type"]=='admin'){?>
            <br><?php /*1s*/ echo "".SOFTBIZ_LC00021_EDIT_TEXTAD.""; /*-~- Your Banner will not be displayed until Admin approves the changes. -~-*/ /*1e*/ ?>  
            <?php }	//end if?>  
  </div>
</fieldset>

</form>

@endsection
@include('includes.panel-two', ['title' =>$form_title,'data'=>'pack-form'])

                 