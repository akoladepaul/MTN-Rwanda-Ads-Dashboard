
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>

@section('package-top')

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_CHOOSE_TYPE." "; /*-~- Package Name -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sbrow_chk["sbname"]; ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_ADVERTISE.""; /*-~- Package Type -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo  $dis?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00004_CHOOSE_TYPE.""; /*-~- Price -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sb_fee_currency.sbcurrency_format($sbrow_chk["price"]); ?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00003_ADVERTISE.""; /*-~- Banner Size -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php 
						              
	$size_query=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where id=".$sbrow_chk["size_id"]));
                   	
	            
	echo $size_query["width"]."x".$size_query["height"]; ?>
                          px<font size="2" face="Arial, Helvetica, sans-serif"> 
                          <?php if ($size_query["sbnotes"]<>"")
			  					echo ' ['.$size_query["sbnotes"].']'; ?>
</div>
</div>

@endsection
@include('includes.panel-two', ['title' =>$form_title2,'data'=>'package-top'])


@section('package')

@include('includes.modal' , array('submit_to'=>'')) 


 <form name=form123 id=form123 class="form-horizontal" onsubmit=return(formValidate(this)); 
                  method=post action="confirm_bannerad.php">








<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00004_ADVERTISE.""; /*-~- Banner Type -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">

<select name="banner_type" onChange="dis_desti(this.form);" class="form-control">
                            <option value="image"><?php /*1s*/ echo "".SOFTBIZ_LC00005_ADVERTISE.""; /*-~- Image(.jpg/.gif) -~-*/ /*1e*/ ?></option>
							<?php if($sbrow_chk["sbtype"]<>"2")
							{?>
                            <option value="flash"><?php /*1s*/ echo "".SOFTBIZ_LC00006_ADVERTISE.""; /*-~- Flash(.swf) -~-*/ /*1e*/ ?></option>
                          <?php }?>
						  </select>
  </div>
</fieldset>

  
  <fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00007_ADVERTISE." "; /*-~- Destination URL -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<INPUT name=url  value="http://"  class="form-control" >
<small class="text-muted">
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00008_ADVERTISE.""; /*-~- Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com -~-*/ /*1e*/ ?>
</small>
  </div>
</fieldset>

<!--
<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00009_ADVERTISE." "; /*-~- Banner Image -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<INPUT  class="form-control"  name="bannerurl" id="bannerurl" value="" readonly>
                          <input type=BUTTON name=btn_name2 value="<?php /*1s*/ echo "".SOFTBIZ_LC00012_FILEUPLOAD.""; /*-~- Upload -~-*/ /*1e*/ ?>" onClick=attachment(this.form)>
                          <input type=BUTTON name=buttonname2 value="<?php /*1s*/ echo "".SOFTBIZ_LC00010_ADVERTISE.""; /*-~- Remove -~-*/ /*1e*/ ?>" onClick=removeattachment()>

  </div>
</fieldset>
-->

<fieldset class="form-group row">
  <label class="col-md-4 form-control-label" for=""><?php /*1s*/ echo "".SOFTBIZ_LC00009_ADVERTISE." "; /*-~- Banner Image -~-*/ /*1e*/ ?></label>  
  <div class="col-md-7">

  <INPUT type="hidden"   name="bannerurl" id="bannerurl" value="" >
    <button name="logo_upload_button" class="btn btn-primary" id="logo_upload_button" type="button" data-toggle="modal" data-target="#myModal">Upload Image</button>
  </div>
</fieldset>
<script>
$("#logo_upload_button").click(function () { 
//alert("fileupload.php?box=bannerurl&ban_type=" + form123.banner_type.value   );
      $("#upload-iframe").attr("src", "fileupload.php?box=bannerurl&ban_type=" + form123.banner_type.value);
});
</script>



<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 

  </label>
  <div class="col-md-7">
<input name="sbplan" type="hidden" id="sbplan" value="<?php echo $sbplan; ?>"> 
<input class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00014_CHOOSE_TYPE.""; /*-~- Continue -~-*/ /*1e*/ ?>" name=submit> 
                          
  </div>
</fieldset>






</form>


 
@endsection
@include('includes.panel-one', ['title' =>$form_title,'data'=>'package'])