<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>

<?php if(isset($_REQUEST['amount_rq']) && is_numeric($_REQUEST['amount_rq']))
		  {	
		  		if(isset($_REQUEST['ad_type']) && ($_REQUEST['ad_type']=='text'))
				$ad_type=/*2s*/ "".SOFTBIZ_LC00006_ADDMONEY."" /*-~-* / "add text ad" / *-~-*/ /*2e*/ ;
				else
		  		$ad_type=/*2s*/ "".SOFTBIZ_LC00007_ADDMONEY."" /*-~-* / "add banner" / *-~-*/ /*2e*/ ;
				
				if(isset($_REQUEST['buy_type']) && ($_REQUEST['buy_type']=='duration'))
				$ad_type=/*2s*/ "".SOFTBIZ_LC00008_ADDMONEY."" /*-~-* / "buy more duration" / *-~-*/ /*2e*/ ;
				elseif(isset($_REQUEST['buy_type']) && ($_REQUEST['buy_type']=='clicks'))
		  		$ad_type=/*2s*/ "".SOFTBIZ_LC00009_ADDMONEY."" /*-~-* / "buy more clicks" / *-~-*/ /*2e*/ ;
				elseif(isset($_REQUEST['buy_type']) && ($_REQUEST['buy_type']=='impressions'))
		  		$ad_type=/*2s*/ "".SOFTBIZ_LC00010_ADDMONEY."" /*-~-* / "buy more impressions" / *-~-*/ /*2e*/ ;

		  	?>
            
<?php printf(/*2s*/ "".SOFTBIZ_LC00011_ADDMONEY."" /*-~-* / "Your %s request has not been processed due to lack of funds.<br>" / *-~-*/ /*2e*/ ,$ad_type);printf(/*2s*/ "".SOFTBIZ_LC00012_ADDMONEY."" /*-~-* / "You need at least %s for chosen package.<br> Add some money to your account or choose some other package" / *-~-*/ /*2e*/ ,$sb_fee_currency.sbcurrency_format((real)$_REQUEST['amount_rq']));

					   ?>
                       
                    <?php }?>
                    
                    
                       
 @section('add-money')

 <form class="form-horizontal"  name="form1" method="post" action="insert_money.php" onSubmit="return Validate(this);">


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00001_ADDMONEY.""; /*-~- Add to my account -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  
  <div class="input-group">
  <span class="input-group-addon" id="basic-addon3"><?php echo $sb_fee_currency; ?> </span>
  <input name="amount" type="text" id="amount"  class="form-control"> 
</div>  


  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo " ".SOFTBIZ_LC00002_ADDMONEY.""; /*-~- Payment Method -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
  <?php
					if($config["sb_enable_paypal"]=="yes")
					{	
                    ?>
                    <input type="radio" name="paymnt_method" value="2" checked>
<?php /*1s*/ echo "".SOFTBIZ_LC00003_ADDMONEY.""; /*-~- PayPal -~-*/ /*1e*/ ?><br>
<?php
				   }
					if($config["sb_enable_checkout"]=="yes")
					{	
                    ?>
                     <input type="radio" name="paymnt_method" value="3" checked>
<?php /*1s*/ echo "".SOFTBIZ_LC00004_ADDMONEY.""; /*-~- 2Checkout -~-*/ /*1e*/ ?><br>
 <?php
					}
				   if($config["sb_enable_offline"]=="yes")
				   {
                    ?>
                     <input name="paymnt_method" type="radio" value="1" checked>
<?php /*1s*/ echo "".SOFTBIZ_LC00005_ADDMONEY.""; /*-~- Pay Offline -~-*/ /*1e*/ ?><br>
 <?php
					}?>
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  
  </label>
  <div class="col-md-7">
 <input type="submit" name="Submit" class="btn btn-primary" value="<?php /*1s*/ echo "".SOFTBIZ_LC00014_CHOOSE_TYPE.""; /*-~- Continue -~-*/ /*1e*/ ?>">
  </div>
</fieldset>



</form>  
    @endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'add-money'])

