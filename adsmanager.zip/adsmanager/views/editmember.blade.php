<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>

 @section('edit-member')

 <form class="form-horizontal"  action="updatemember.php" method="post" name="frm1" id="frm1"  onSubmit="return Validator(this);">


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00009_SITEHOME.""; /*-~- Your Name -~-*/ /*1e*/ ?>  
  </label>
  <div class="col-md-7">
 <input name=uname  value="<?php echo $uname;?>"  class="form-control" >
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00010_SITEHOME.""; /*-~- Your Address -~-*/ /*1e*/ ?> 
  </label>
  <div class="col-md-7">
 <input name="add"  value="<?php echo $add;?>"  class="form-control" >
  </div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00011_SITEHOME.""; /*-~- City -~-*/ /*1e*/ ?> 
  </label>
  <div class="col-md-7">
 <input name="city"  value="<?php echo $city;?>"  class="form-control" >
  </div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00012_SITEHOME.""; /*-~- State -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
 <input name="state" value="<?php echo $state;?>"  class="form-control" >
  </div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00013_SITEHOME.""; /*-~- Country -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
 <SELECT name=country class="select-two">
                      <OPTION value=0 selected
                          <?php if($country==0) {echo " selected ";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00014_SITEHOME." "; /*-~- Select a Country -~-*/ /*1e*/ ?></option>
                      <?php 
						  $country1=mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_country order by country");
						  while($rst= mysqli_fetch_array($country1))
						  {
						  ?>
                      <OPTION value=<?php echo $rst["id"];?> <?php if($rst["id"]==$country) {echo " selected ";}?>><?php echo $rst["country"];?></OPTION>
                      <?php
} // wend
							   ?>
                    </SELECT>
  </div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00015_SITEHOME." "; /*-~- Website URL -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
 <input name="url"  value="<?php echo $url;?>"  class="form-control" >
  </div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  
  </label>
  <div class="col-md-7">
 <input class="btn btn-primary" name="Submit" type="submit"  value="<?php /*1s*/ echo "".SOFTBIZ_LC00020_EDIT_TEXTAD." "; /*-~- Update -~-*/ /*1e*/ ?>">
  </div>
</fieldset>



</form>  
    @endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'edit-member'])

