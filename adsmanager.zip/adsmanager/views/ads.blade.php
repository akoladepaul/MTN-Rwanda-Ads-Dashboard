
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>

@section('search-ads')

<form class="form-horizontal" action="ads.php" name="form1" method="post" onSubmit="return validate(this);">

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00002_ADS.""; /*-~- Keyword -~-*/ /*1e*/ ?></label>
  <div class="col-md-7">
  <input name="keyword" type="text" id="keyword" value="<?php echo $keyword;?>"`></div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00003_ADS.""; /*-~- Search in -~-*/ /*1e*/ ?></label>
  <div class="col-md-7">
   <input name="radio" type="radio" value="1" checked >
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00004_ADS." "; /*-~- Banner # -~-*/ /*1e*/ ?>
      <input type="radio" name="radio" value="2" <?php if($radio==2)
					{ echo " checked";}
					?>><?php /*1s*/ echo "".SOFTBIZ_LC00007_ADVERTISE.""; /*-~- Destination URL -~-*/ /*1e*/ ?></div>
</fieldset>



<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00007_MYACCOUNT.""; /*-~- Show -~-*/ /*1e*/ ?></label>
  <div class="col-md-7">
  <input name="show" type="radio" value="1" checked >
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00005_ADS.""; /*-~- All -~-*/ /*1e*/ ?></font></font>
      <input type="radio" name="show" value="2" <?php if($show==2)
					{ echo " checked";}
					?>>
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00002_AD_HOME." "; /*-~- Approved -~-*/ /*1e*/ ?>
      <input type="radio" name="show" value="3" <?php if($show==3)
					{ echo " checked";}
					            
                             
					              	
					?>>
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00006_ADS.""; /*-~- Waiting for Approval -~-*/ /*1e*/ ?></div>
</fieldset>



<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00006_CHOOSE_TYPE.""; /*-~- Size -~-*/ /*1e*/ ?></label>
  <div class="col-md-7">
  <select name="size_id">
                            <option value="" selected><?php /*1s*/ echo "".SOFTBIZ_LC00007_ADS.""; /*-~- All Sizes -~-*/ /*1e*/ ?></option>
                            <?php 
						$size_query=mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes order by width");
						while($size=mysqli_fetch_array($size_query))
						{	$note='';
					 	if ($size["sbnotes"]<>"")
			  			$note= ' ['.$size["sbnotes"].']'; 
                      ?>
                            <option value="<?php echo $size["id"];?>" <?php if($size_id==$size["id"])
					  {echo "selected";}
					  ?>><?php echo $size["width"]."x".$size["height"].$note;?></option>
                            <?php
}
                    ?>
                          </select> </div>
</fieldset>



<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00008_ADS.""; /*-~- Ad Type -~-*/ /*1e*/ ?></label>
  <div class="col-md-7">
  <select name="ad_type">
                            <option value="banner" <?php if(sbhtmlentities(stripslashes($ad_type),ENT_QUOTES)=="banner") { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00001_UPDATE_IMPRESSIONS.""; /*-~- Banner Ad -~-*/ /*1e*/ ?></option>
                            <option value="text" <?php if(sbhtmlentities(stripslashes($ad_type),ENT_QUOTES)=="text") { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00002_UPDATE_IMPRESSIONS.""; /*-~- Text Ad -~-*/ /*1e*/ ?></option>
                          </select></div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00002_ADVERTISE.""; /*-~- Package Type -~-*/ /*1e*/ ?></label>
  <div class="col-md-7">
  <select name="package" id="package">
                            <option value="" selected><?php /*1s*/ echo "".SOFTBIZ_LC00009_ADS.""; /*-~- All Packages -~-*/ /*1e*/ ?></option>
                            <option value="1" <?php if($package==1)
					  			{echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00005_BUY_MORE.""; /*-~- Impressions Based -~-*/ /*1e*/ ?></option>
                            <option value="2" <?php if($package==2)
					  			{echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00006_BUY_MORE.""; /*-~- Click Based -~-*/ /*1e*/ ?></option>
                            <option value="3" <?php if($package==3)
					  			{echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00007_BUY_MORE.""; /*-~- Time Based -~-*/ /*1e*/ ?></option>
                          </select></div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00010_ADS.""; /*-~- Sort by -~-*/ /*1e*/ ?> </label>
  <div class="col-md-7">
  <select name="field">
                            <option value="date_submitted" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="date_submitted")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00011_ADS.""; /*-~- Date Added -~-*/ /*1e*/ ?></option>
                            <option value="credits" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="credits")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00012_ADS.""; /*-~- Impressions Purchased -~-*/ /*1e*/ ?></option>
							<option value="sbexpiry" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="sbexpiry")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00013_ADS.""; /*-~- Expiry Date -~-*/ /*1e*/ ?></option>
                            <option value="displays" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="displays")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00014_ADS.""; /*-~- Impressions Received -~-*/ /*1e*/ ?></option>
                            <option value="clicks" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="clicks")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00015_ADS.""; /*-~- Clicks Received -~-*/ /*1e*/ ?></option>
                            <option value="credits-displays" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="credits-displays")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00016_ADS.""; /*-~- Impressions Left -~-*/ /*1e*/ ?></option>
							 <option value="sb_clicks_purchased-clicks" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="sb_clicks_purchased-clicks")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00017_ADS."                            "; /*-~- Clicks Left -~-*/ /*1e*/ ?></option>
							<option value="TO_DAYS(sbexpiry)-TO_DAYS(NOW())" <?php if(isset($_REQUEST["field"])&&(sbhtmlentities(stripslashes($_REQUEST["field"]),ENT_QUOTES)=="TO_DAYS(sbexpiry)-TO_DAYS(NOW())")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00018_ADS."                            "; /*-~- Days Left -~-*/ /*1e*/ ?></option>
                          </select>
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00019_ADS.""; /*-~- Order -~-*/ /*1e*/ ?> <select name="order">
        <option value="asc" <?php if(isset($_REQUEST["order"])&&($_REQUEST["order"]=="asc")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00020_ADS.""; /*-~- Ascending -~-*/ /*1e*/ ?></option>
                            <option value="desc" <?php if(isset($_REQUEST["order"])&&($_REQUEST["order"]=="desc")) { echo "selected";}?>><?php /*1s*/ echo "".SOFTBIZ_LC00021_ADS.""; /*-~- Descending -~-*/ /*1e*/ ?></option>
                          </select></div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  <?php /*1s*/ echo "".SOFTBIZ_LC00006_MYACCOUNT.""; /*-~- Records Per Page -~-*/ /*1e*/ ?></label>
  <div class="col-md-7">
  <select name="recperpage">
                            <option value="1" <?php if($recperpage==1) { echo "selected";}?>>1</option>
                            <option value="5" <?php if($recperpage==5) { echo "selected";}?>>5</option>
                            <option value="10" <?php if($recperpage==10) { echo "selected";}?>>10</option>
                            <option value="20" <?php if($recperpage==20) { echo "selected";}?>>20</option>
                            <option value="30" <?php if($recperpage==30) { echo "selected";}?>>30</option>
                            <option value="50" <?php if($recperpage==50) { echo "selected";}?>>50</option>
                            <option value="100" <?php if($recperpage==100) { echo "selected";}?>>100</option>
                          </select></div>
</fieldset>

<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
  </label>
  <div class="col-md-7">
  <input class="btn btn-primary" type="submit" name="Submit2" value="<?php /*1s*/ echo "".SOFTBIZ_LC00022_ADS.""; /*-~- Search -~-*/ /*1e*/ ?>"></div>
</fieldset>


</form>
@endsection
  @include('includes.panel-two', ['title' =>$form_title,'data'=>'search-ads'])
  
  
  
  
  
  
  
  
  
  
  
  @section('show-result')
  <?php
			              
$cnt=0;
$num_ads=mysqli_num_rows($rs_query);
             
	              	
if($num_ads>0)
{

while (($rs0=mysqli_fetch_array($rs_query)) && ($cnt<$recperpage))
{
$cnt++;
if($rs0["sbtype"]==1)	
$dis=/*2s*/ "".SOFTBIZ_LC00005_BUY_MORE."" /*-~-* / "Impressions Based" / *-~-*/ /*2e*/ ;
elseif($rs0["sbtype"]==2)
$dis=/*2s*/ "".SOFTBIZ_LC00006_BUY_MORE."" /*-~-* / "Click Based" / *-~-*/ /*2e*/ ;
else
$dis=/*2s*/ "".SOFTBIZ_LC00007_BUY_MORE."" /*-~-* / "Time Based" / *-~-*/ /*2e*/ ;
$size=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where id=".$rs0["size_id"]));
?> 


<div class="row product-cell  <?=($cnt%2==0)?'lightgray-bg':'' ?>  " >
<div class="col-md-12 col-lg-12 col-xl-12 text-center search-result-item">
<?php if($rs0['textad']=='no') 
					{ ?>

 <?php
if($rs0["banner_type"]!="flash")
				{
				?>
                  <img src="banners/<?php echo $rs0["bannerurl"];?>" width=<?php echo $size["width"];?> height=<?php echo $size["height"];?>> 
                  <?php
}
					else
					{
					?>
                    
  <embed src="<?php echo "banners/". $rs0["bannerurl"]; ?>" 

width="<?php echo $size["width"];?>" height="<?php echo $size["height"];?>" PLAY="true" quality="best" PLUGINSPAGE=" http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></embed> 
                  <?php
}
			?>
            
 <?php 
			  } else {
			  ?>
    <?php $tbwid=234;
						$tbheight=60;
						$row=(int)($size["height"]/$tbheight);
						$column=(int)($size["width"]/$tbwid);
						//$tdwid=$wid/$column;
						//$tdheight=$height/$row;
						//echo $row." -----------".$column;
						?>          
            <table width="234" height="60" border="0" cellpadding="0" cellspacing="0" class="tablebgcolor">
							<tr> 
				            <td><font class='textdescription'>&nbsp;<a class="titletextadlinkstyle" href="<?php echo $rs0['url'];  ?>" target="_blank"><?php echo $rs0['title'];  ?></a></font></td>
					</tr>
					<tr> 
				  <td><font class="textdescription">&nbsp;<?php echo $rs0['description1'];  ?></font></td>
					  </tr>
					<tr>  
				  <td><font class="textdescription">&nbsp;<?php echo $rs0['description2'];  ?></font></td>
				</tr>
					<tr> 
				  <td><font class='textdescription'>&nbsp;<a class="textadlink" href="<?php echo $rs0['url'];  ?>" target="_blank"><?php echo $rs0['displayurl'];  ?></a></font></td>
					</tr>
				  </table>
                  
      <?php  }//if sbtaxtad?>                                           
</div>
<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12  search-result-item">

<div class="col-sm-6 col-md-6 bold-text datarow-title">
<?php echo ($rs0["textad"]=='yes')? /*2s*/ "".SOFTBIZ_LC00002_UPDATE_IMPRESSIONS."" /*-~-* / "Text Ad" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00032_ADS."" /*-~-* / "Banner" / *-~-*/ /*2e*/ ;?> #
</div>
<div class="col-sm-6 col-md-6 text-left ">
<?php echo  $rs0["id"]; ?>
</div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title ">
<?php echo ($rs0["textad"]=='yes')? /*2s*/ "".SOFTBIZ_LC00033_ADS."" /*-~-* / "Text Ad Type" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00004_ADVERTISE."" /*-~-* / "Banner Type" / *-~-*/ /*2e*/ ;?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
 <?php
echo $dis; ?></div>

<?php if($rs0["sbtype"]!=3)
			  {	?>
<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo($rs0["sbtype"]==1)?/*2s*/ "".SOFTBIZ_LC00012_ADS."" /*-~-* / "Impressions Purchased" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00034_ADS."" /*-~-* / "Clicks Purchased" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo($rs0["sbtype"]==1)?$rs0["credits"]:$rs0["sb_clicks_purchased"]; ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo($rs0["sbtype"]==1)?/*2s*/ "".SOFTBIZ_LC00016_ADS."" /*-~-* / "Impressions Left" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00017_ADS."" /*-~-* / "Clicks Left" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo($rs0["sbtype"]==1)?($rs0["credits"]-$rs0["displays"]):($rs0["sb_clicks_purchased"]-$rs0["clicks"]); ?></div>

<?php }else { ?>

<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00013_ADS.""; /*-~- Expiry Date -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo sb_date($rs0["sb_expiry"]); ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00018_ADS.""; /*-~- Days Left -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo ($rs0["sb_left"]>=0)?$rs0["sb_left"]:/*2s*/ "".SOFTBIZ_LC00035_ADS."" /*-~-* / "Expired" / *-~-*/ /*2e*/ ; ?></div>

 <?php } ?>

<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo /*2s*/ "".SOFTBIZ_LC00015_ADS."" /*-~-* / "Clicks Received" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo $rs0["clicks"]; ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php echo /*2s*/ "".SOFTBIZ_LC00014_ADS."" /*-~-* / "Impressions Received" / *-~-*/ /*2e*/ ; ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo $rs0["displays"]; ?></div>


<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00023_ADS.""; /*-~- Click through Rate -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php 
						if($rs0["displays"]>0)
						{
						echo round((($rs0["clicks"]/$rs0["displays"])*100),2);
						echo "%";
						}
						else
						{
						echo "0%";
						}
						?></div>



<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo " ".SOFTBIZ_LC00024_ADS." "; /*-~- Status -~-*/ /*1e*/ ?>
</div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php 
						if($rs0["approved"]=="yes")
						{
						echo /*2s*/ "".SOFTBIZ_LC00002_AD_HOME."" /*-~-* / "Approved" / *-~-*/ /*2e*/ ;
						}
						else
						{
						echo /*2s*/ "".SOFTBIZ_LC00006_ADS."" /*-~-* / "Waiting for Approval" / *-~-*/ /*2e*/ ;
						}
						 ?></div>

<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00018_EDIT_TEXTAD." "; /*-~- Destination Url -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo($rs0["banner_type"]!="flash")? $rs0["url"]: $config['null_char'];?></div>

<?php if ($size["sbnotes"]<>"")
			  { ?>
<div class="col-sm-6 col-md-6 text-left bold-text datarow-title">
<?php /*1s*/ echo "".SOFTBIZ_LC00025_ADS." "; /*-~- Note -~-*/ /*1e*/ ?></div>
<div class="col-sm-6 col-md-6 text-left datarow-data">
<?php echo $size["sbnotes"]; ?></div>
<?php		}	?>



<div class="col-sm-6 col-md-6 text-left datarow-data">
<a href="buy_more.php?id=<?php echo $rs0["id"];?>&pg=<?php  echo $pg.$strpass; ?>" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00026_ADS." "; /*-~- Buy More -~-*/ /*1e*/ ?><?php if($rs0["sbtype"]==1) echo /*2s*/ "".SOFTBIZ_LC00003_CHOOSE_TYPE."" /*-~-* / "Impressions" / *-~-*/ /*2e*/ ; elseif($rs0["sbtype"]==2) echo /*2s*/ "".SOFTBIZ_LC00009_CHOOSE_TYPE."" /*-~-* / "Clicks" / *-~-*/ /*2e*/ ; elseif($rs0["sbtype"]==3) echo /*2s*/ "".SOFTBIZ_LC00012_CHOOSE_TYPE."" /*-~-* / "Duration" / *-~-*/ /*2e*/ ;  ?></a> | <a href="<?php echo($rs0['textad']=='no')? 'edit_banner.php':'edit_textad.php';?>?id=<?php echo $rs0["id"];?>" class="insidelink"><?php /*1s*/ echo "".SOFTBIZ_LC00027_ADS.""; /*-~- Edit -~-*/ /*1e*/ ?></a> | <a href="banner_stats.php?id=<?php echo $rs0["id"];?>" class="insidelink"><?php echo ($rs0["textad"]=='yes')? /*2s*/ "".SOFTBIZ_LC00002_UPDATE_IMPRESSIONS."" /*-~-* / "Text Ad" / *-~-*/ /*2e*/ :/*2s*/ "".SOFTBIZ_LC00032_ADS."" /*-~-* / "Banner" / *-~-*/ /*2e*/ ;?><?php /*1s*/ echo "".SOFTBIZ_LC00028_ADS.""; /*-~- Stats -~-*/ /*1e*/ ?></a></div>


       
</div>

</div>
   <?php
}  //end while
  }  // if record found
 else
 {
 ?> 
 
 <div class="row " >
<div class="col-md-12">
  <?php /*1s*/ echo "".SOFTBIZ_LC00029_ADS." "; /*-~- No Ad satisfy the criteria you specified. -~-*/ /*1e*/ ?>
 </div>
 </div> 
   <?php
}
					?>
  @endsection
  @include('includes.panel-one', ['title' =>$form_title,'data'=>'show-result'])
  


             
            
              
			 
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" Class="titlestyle">
                    <?PHP
		if($pages>0)
		{

		  	if($pages>1)
			{	
        ?>
                    <tr valign="top"> 
                      <td width="82%" height="19" align="center" valign="bottom">
                        <?php
			printf( /*2s*/ "".SOFTBIZ_LC00036_ADS."" /*-~-* / "Page %s of %s<br>" / *-~-*/ /*2e*/ ,$pg,$pages);	
			?>
                      </td>
                    </tr>
<?php
			}

?>                    <tr valign="top" > 
                      <td width="82%" align="center" valign="bottom"  Class="titlestyle"> 
                        
                        <fo nt class="smalltext"> 
                        <?php
						            
//-----------------------------PAGE ARRAY
	$limit=5;
	$limit_xtra=3;
	$start_from=1;
	if($pages<=$limit) $limit=$pages-1;
	if($pg>$start_from+ceil($limit/2))
	$start_from=(($pg+ceil($limit/2))<$pages)?$pg-floor(($start_from+$limit)/2):$pages-$limit;
	$up_to=$start_from+$limit-1;
	$page_arr=array();
	for($j=0,$i=$start_from;$j<=$limit;$j++,$i++)
	$page_arr[$j]=$i;

	$start_page_arr=array();
	$frst_page=1;
	$start_page_arr[0]=$frst_page;
	if(($frst_page<$up_to))
	{	
		$page_index=ceil(($up_to-$frst_page)/2);
		$cnt=0;
		while((($up_to-$page_index)<$start_from) && (($up_to-$page_index)>0) && ($cnt<$limit_xtra))
		{
			$cnt++;
			$start_page_arr[count($start_page_arr)]=($up_to-$page_index);
			$frst_page=($up_to-$page_index);	
			$page_index=ceil(($up_to-$frst_page)/2);
		}
	}

	$last_page_arr=array();
	$last_page=$pages;
	$last_page_arr[0]=$last_page;
	if(($last_page>$up_to))
	{	
		$page_index=floor(($last_page-$start_from)/2);
		$cnt=0;
		while((($start_from+$page_index)>($start_from+$limit)) && ($cnt<$limit_xtra))
		{
			$cnt++;
			$last_page_arr[count($last_page_arr)]=($start_from+$page_index);
			$last_page=($start_from+$page_index);	
			$page_index=floor(($last_page-$start_from)/2);
		}
	}
	
	/*for($i=0;$i<count($page_arr);$i++)
	$start_page_arr[count($start_page_arr)]=$page_arr[$i];
	
	$page_arr=$start_page_arr;
	for($i=count($last_page_arr)-1;$i>=0;$i--)
	$page_arr[count($page_arr)]=$last_page_arr[$i];
	*/	if(isset($_REQUEST["sort_id"]) )
		{
		$strpass.="&sort_id=".$_REQUEST['sort_id'];
		}
	            
	if( ($start_page_arr[0]<>$page_arr[0]))
	{
	for($i=0;$i<count($start_page_arr);$i++)
	echo "<a href='".$_SERVER['PHP_SELF']."?$strpass&pg=$start_page_arr[$i]'  class='pagelink'>$start_page_arr[$i]</a>&nbsp;&nbsp;";
	echo "&nbsp;&nbsp;&nbsp;";
	//echo "<a href='".$_SERVER['PHP_SELF']."?pg=".($pg-1)."'>Previous</a>&nbsp;";
	}
	
	foreach($page_arr as $p)
	{
	if($p==$pg)
	echo "<b>".$p."</b>&nbsp;&nbsp;";
	else
	echo "<a href='".$_SERVER['PHP_SELF']."?$strpass&pg=$p' class='pagelink'>".$p."</a>&nbsp;&nbsp;";
	}
	if( ($last_page_arr[0]<>$page_arr[$limit]))
	{
	//echo "&nbsp;<a href='".$_SERVER['PHP_SELF']."?pg=".($pg+1)."'>Next</a>";
	echo "&nbsp;&nbsp;&nbsp;";
	for($i=count($last_page_arr)-1;$i>=0;$i--)
	echo "<a href='".$_SERVER['PHP_SELF']."?$strpass&pg=$last_page_arr[$i]' class='pagelink'>$last_page_arr[$i]</a>&nbsp;&nbsp;";
	}
//-----------------------------
?>
                        </font></td>
                    </tr>
                    <?php }?>
                  </table>