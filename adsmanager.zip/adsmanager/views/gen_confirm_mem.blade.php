<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>

  
 
@section('message')
<br>
 <?php
	if(isset($_REQUEST["errmsg"])&&($_REQUEST["errmsg"]<>""))
	{
  ?><strong><?php echo sbhtmlentities(stripslashes($_REQUEST["errmsg"]),ENT_QUOTES);?></strong><br>
  <?php
	}  		//end if errmsg set & not empty
  ?>
  
        <?php /*1s*/ echo " ".SOFTBIZ_LC00012_ADVERTISE." "; /*-~- Click -~-*/ /*1e*/ ?><a href="ad_home.php"><?php /*1s*/ echo "".SOFTBIZ_LC00009_BUY_MORE.""; /*-~- here -~-*/ /*1e*/ ?></a> 
<?php /*1s*/ echo "            ".SOFTBIZ_LC00000_GEN_CONFIRM_MEM.""; /*-~- to go to advertiser home. -~-*/ /*1e*/ ?><br>

<?php /*1s*/ echo " ".SOFTBIZ_LC00012_ADVERTISE." "; /*-~- Click -~-*/ /*1e*/ ?><a href="choose_banner.php"><?php /*1s*/ echo "".SOFTBIZ_LC00009_BUY_MORE.""; /*-~- here -~-*/ /*1e*/ ?></a> 
<?php /*1s*/ echo "            ".SOFTBIZ_LC00001_GEN_CONFIRM_MEM.""; /*-~- to add new advertisement. -~-*/ /*1e*/ ?><br>

<?php /*1s*/ echo " ".SOFTBIZ_LC00012_ADVERTISE." "; /*-~- Click -~-*/ /*1e*/ ?><a href="ads.php"><?php /*1s*/ echo "".SOFTBIZ_LC00009_BUY_MORE.""; /*-~- here -~-*/ /*1e*/ ?></a> 
<?php /*1s*/ echo "            ".SOFTBIZ_LC00002_GEN_CONFIRM_MEM.""; /*-~- to manage your advertisements. -~-*/ /*1e*/ ?><br>

<?php /*1s*/ echo " ".SOFTBIZ_LC00012_ADVERTISE." "; /*-~- Click -~-*/ /*1e*/ ?><a href="addmoney.php"><?php /*1s*/ echo "".SOFTBIZ_LC00009_BUY_MORE.""; /*-~- here -~-*/ /*1e*/ ?></a> 
<?php /*1s*/ echo "            ".SOFTBIZ_LC00003_GEN_CONFIRM_MEM.""; /*-~- to add money to the account. -~-*/ /*1e*/ ?><br>

<?php /*1s*/ echo " ".SOFTBIZ_LC00012_ADVERTISE." "; /*-~- Click -~-*/ /*1e*/ ?><a href="myaccount.php"><?php /*1s*/ echo "".SOFTBIZ_LC00009_BUY_MORE.""; /*-~- here -~-*/ /*1e*/ ?></a> 
<?php /*1s*/ echo "            ".SOFTBIZ_LC00004_GEN_CONFIRM_MEM.""; /*-~- to view account transactions. -~-*/ /*1e*/ ?><br>

<?php /*1s*/ echo "".SOFTBIZ_LC00012_ADVERTISE." "; /*-~- Click -~-*/ /*1e*/ ?><a href="logout.php"><?php /*1s*/ echo "".SOFTBIZ_LC00009_BUY_MORE.""; /*-~- here -~-*/ /*1e*/ ?></a> 
<?php /*1s*/ echo "            ".SOFTBIZ_LC00005_GEN_CONFIRM_MEM.""; /*-~- to logout -~-*/ /*1e*/ ?><br>

@endsection
@include('includes.panel-one', ['title' =>$form_title,'data'=>'message'])
        
 
      
