<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>

 @section('change-password')

 <form class="form-horizontal"  action="updatepassword.php" method="post" name="frm1" id="frm1"  onSubmit="return Val();">


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
<?php /*1s*/ echo "".SOFTBIZ_LC00002_CHANGEPASSWORD." "; /*-~- Current Password -~-*/ /*1e*/ ?> 
  </label>
  <div class="col-md-7">
<input name="currpassword" type="password"  id="currpassword3" value="" class="form-control" > 
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00003_CHANGEPASSWORD.""; /*-~- New Password -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="newpassword" type="password"  id="newpassword3" class="form-control" >

<small class="text-muted">
<?php printf(/*2s*/ "".SOFTBIZ_LC00009_CHANGEPASSWORD." " /*-~-* / "must be atleast %s" / *-~-*/ /*2e*/ ,$pwd_len); echo ($pwd_len==1)? /*2s*/ "".SOFTBIZ_LC00010_CHANGEPASSWORD."" /*-~-* / "character" / *-~-*/ /*2e*/  :/*2s*/ "".SOFTBIZ_LC00011_CHANGEPASSWORD."" /*-~-* / "characters" / *-~-*/ /*2e*/ ?>
</small>
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
 <?php /*1s*/ echo "".SOFTBIZ_LC00004_CHANGEPASSWORD.""; /*-~- Retype Password -~-*/ /*1e*/ ?>
  </label>
  <div class="col-md-7">
<input name="retypepassword" type="password"  id="retypepassword3" class="form-control" >
<small class="text-muted">
<?php printf(/*2s*/ "".SOFTBIZ_LC00009_CHANGEPASSWORD." " /*-~-* / "must be atleast %s" / *-~-*/ /*2e*/ ,$pwd_len); echo ($pwd_len==1)? /*2s*/ "".SOFTBIZ_LC00010_CHANGEPASSWORD."" /*-~-* / "character" / *-~-*/ /*2e*/  :/*2s*/ "".SOFTBIZ_LC00011_CHANGEPASSWORD."" /*-~-* / "characters" / *-~-*/ /*2e*/ ?>
</small>
  </div>
</fieldset>


<fieldset class="form-group row">
  <label class="col-md-4  form-control-label" for=""> 
 
  </label>
  <div class="col-md-7">
<input class="btn btn-primary" name="Submit" type="submit" value="<?php /*1s*/ echo "".SOFTBIZ_LC00005_CHANGEPASSWORD.""; /*-~- Update Password -~-*/ /*1e*/ ?>">
  </div>
</fieldset>


</form>  
    @endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'change-password'])

