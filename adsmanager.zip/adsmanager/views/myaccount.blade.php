
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>

@section('select-dates')
<table width="100%" border="0" cellpadding="2" cellspacing="5">
        <form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
          <tr valign="top"> 
            <td width="20%"  class="innertablestyle"><strong><?php /*1s*/ echo "".SOFTBIZ_LC00001_MYACCOUNT.""; /*-~- From -~-*/ /*1e*/ ?>
            </strong></td>
            <td width="80%"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td width="11%"><?php /*1s*/ echo "".SOFTBIZ_LC00002_MYACCOUNT.""; /*-~- Day -~-*/ /*1e*/ ?></td>
                  <td width="2%">&nbsp;</td>
                  <td width="12%"><?php /*1s*/ echo "".SOFTBIZ_LC00003_MYACCOUNT.""; /*-~- Month -~-*/ /*1e*/ ?></td>
                  <td width="2%">&nbsp;</td>
                  <td width="77%"><?php /*1s*/ echo "".SOFTBIZ_LC00004_MYACCOUNT.""; /*-~- Year -~-*/ /*1e*/ ?></td>
                </tr>
                <tr> 
                  <td><select name="from_day" id="from_day">
                      <!--option value="0">-</option-->
                      <?php 	for($i=1;$i<=31;$i++)
						{
							echo "<option value=\"$i\"";
							if($from_day == $i)
								echo 'selected';
							echo ">$i</option>"; 
						}						?>
                    </select></td>
                  <td>&nbsp;</td>
                  <td><select name="from_month" id="from_month">
                      <!--option value="0">-</option-->
                      <?php 	for($i=1;$i<=12;$i++)
						{
							echo "<option value=\"$i\"";
							if($from_month == $i)
								echo 'selected';
							echo ">$i</option>"; 
						}						?>
                    </select></td>
                  <td>&nbsp;</td>
                  <td><select name="from_year" id="from_year">
                      <!--option value="0">-</option-->
                      <?php 
					  $curyear=date("Y");
					  	for($i=$curyear-15;$i<=$curyear+1;$i++)
						{
							echo "<option value=\"$i\"";
							if($from_year == $i)
								echo 'selected';
							echo ">$i</option>"; 
						}						?>
                    </select></td>
                </tr>
              </table></td>
          </tr><?php
                          
          ?><tr valign="top"> 
            <td  class="innertablestyle"><strong><?php /*1s*/ echo "".SOFTBIZ_LC00005_MYACCOUNT.""; /*-~- To -~-*/ /*1e*/ ?>
            </strong></td>
            <td> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td width="11%"><select name="to_day" id="to_day">
                      <!--option value="0">-</option-->
                      <?php 	for($i=1;$i<=31;$i++)
						{
							echo "<option value=\"$i\"";
							if($to_day == $i)
								echo 'selected';
							echo ">$i</option>"; 
						}						?>
                    </select></td>
                  <td width="2%">&nbsp;</td>
                  <td width="12%"><select name="to_month" id="to_month">
                      <!--option value="0">-</option-->
                      <?php 	for($i=1;$i<=12;$i++)
						{
							echo "<option value=\"$i\"";
							if($to_month == $i)
								echo 'selected';
							echo ">$i</option>"; 
						}						?>
                    </select></td>
                  <td width="2%">&nbsp;</td>
                  <td width="77%"><select name="to_year" id="to_year">
                      <!--option value="0">-</option-->
                      <?php 	
					  	for($i=$curyear-5;$i<=$curyear+1;$i++)
						{
							echo "<option value=\"$i\"";
							if($to_year == $i)
								echo 'selected';
							echo ">$i</option>"; 
						}						?>
                    </select></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td  valign="top" class="innertablestyle"><strong></strong></td>
            <td width="60%"> <input type="submit" name="Submit" value="<?php /*1s*/ echo "".SOFTBIZ_LC00007_MYACCOUNT.""; /*-~- Show -~-*/ /*1e*/ ?>"></td>
          </tr>
        </form>
      </table>

@endsection
@include('includes.panel-two', ['title' =>$title,'data'=>'select-dates'])

<div align="center"><strong><?php 

printf(/*2s*/ "".SOFTBIZ_LC00014_MYACCOUNT."" /*-~-* / "Your current balance is %s" / *-~-*/ /*2e*/ ,$sb_fee_currency.sbcurrency_format($balance["total"]));

?></strong> <a href="addmoney.php"><?php /*1s*/ echo "".SOFTBIZ_LC00008_MYACCOUNT.""; /*-~- Add Money -~-*/ /*1e*/ ?></a></div>
      
@section('show-transactions')


<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td valign="top">            
		  <table width="100%" border="0" cellspacing="0" cellpadding="0">

		      <td class="mainMiddle"><table width="100%" border="0" cellpadding="1" cellspacing="0">
                  <?php 
			                       
					if ($rst)
				    {
				  ?>
              <tr> 
                <td valign="middle"> 
                  <table  width="100%" border="0" cellpadding="1" cellspacing="0" class="stackable table-striped">
                 <thead>
                    <tr class="bold-text"> 
                      <td valign="top" width="15%" ><?php /*1s*/ echo "".SOFTBIZ_LC00009_MYACCOUNT.""; /*-~- Amount -~-*/ /*1e*/ ?></td>
                      <td valign="top" width="25%" ><?php /*1s*/ echo "".SOFTBIZ_LC00010_MYACCOUNT.""; /*-~- Date -~-*/ /*1e*/ ?></td>
                      <td  valign="top"><?php /*1s*/ echo "".SOFTBIZ_LC00011_MYACCOUNT.""; /*-~- Description -~-*/ /*1e*/ ?></td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
					  $cnt=0;
                      while($rst)
					  {
					  ?>
                    <tr> 
                      <td  ><font class="smalltext"><?php 
					  if($rst["amount"]>0)
					  {
					  echo $sb_fee_currency.' ';
					  printf("%s",sbcurrency_format($rst["amount"]));
					  }
					  else
					  {
					  echo "<font class='red'>($sb_fee_currency ";
					  printf("%s",sbcurrency_format($rst["amount"]*(-1)));
					  echo ")</font>";
					  }?>
                        </font></td>
                      <td  ><font class="smalltext"><?php
						 echo sb_date($rst["t"],0);?>
                        </font></td>
                      <td  ><?php echo $rst["description"];?></td>
                    </tr>
                    <?php
					  $rst=mysqli_fetch_array($sql);
        			  $cnt++;            
					}// end while
					?>
                    </tbody>
                  </table>
			    </td>
              </tr>
                  <?php
					 }// end transaction found
					 else
					 {
					?>
               <tr> 
                <td valign="middle"> 
                 <table width="100%" border="0" cellspacing="0" cellpadding="1" class="onepxtable">
                    <tr > 
                      <td  class="innertablestyle">&nbsp;<?php /*1s*/ echo "".SOFTBIZ_LC00013_MYACCOUNT.""; /*-~- There are no transactions satisfying your criteria. -~-*/ /*1e*/ ?></td>
                    </tr>
                  </table>
			     </td>
              </tr>
                  <?php 
					}	//end else i.e. no transaction found 
                  ?>
              </table></td>
		      </tr>
             
		    </table>		  </td></tr>
      </table>
@endsection
@include('includes.panel-one', ['title' =>$title2,'data'=>'show-transactions'])
