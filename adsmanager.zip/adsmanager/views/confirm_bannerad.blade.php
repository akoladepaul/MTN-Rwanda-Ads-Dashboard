
<?php foreach($vars as $k=>$v)  { global $$k; $$k=$v; } ?>

@section('package')

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_CHOOSE_TYPE." "; /*-~- Package Name -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sbrow_chk["sbname"]; ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00002_ADVERTISE.""; /*-~- Package Type -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo  $dis?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00004_CHOOSE_TYPE.""; /*-~- Price -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php echo $sb_fee_currency.sbcurrency_format($sbrow_chk["price"]); ?>
</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
 <?php 
				$month="";
				if($sbrow_chk["sbtype"]==1)	
				echo /*2s*/ "".SOFTBIZ_LC00003_CHOOSE_TYPE."" /*-~-* / "Impressions" / *-~-*/ /*2e*/ ;
				elseif($sbrow_chk["sbtype"]==2)
				echo /*2s*/ "".SOFTBIZ_LC00009_CHOOSE_TYPE."" /*-~-* / "Clicks" / *-~-*/ /*2e*/ ;
				else
				{
				echo /*2s*/ "".SOFTBIZ_LC00012_CHOOSE_TYPE."" /*-~-* / "Duration" / *-~-*/ /*2e*/ ;
				$month=($sbrow_chk['credits']==1)?/*2s*/ " ".SOFTBIZ_LC00003_MYACCOUNT."" /*-~-* / "Month" / *-~-*/ /*2e*/ :/*2s*/ " ".SOFTBIZ_LC00016_CHOOSE_TYPE."" /*-~-* / "Months" / *-~-*/ /*2e*/ ;
				} ?>
</div>
<div class="col-md-6">
 <?php echo $sbrow_chk['credits'].$month;?>
</div>
</div>



<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00003_ADVERTISE.""; /*-~- Banner Size -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
 <?php 
						              
	$size_query=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where id=".$sbrow_chk["size_id"]));
                   	
	            
	echo $size_query["width"]."x".$size_query["height"]; ?>
<?php /*1s*/ echo "                          ".SOFTBIZ_LC00007_CHOOSE_TYPE.""; /*-~- px -~-*/ /*1e*/ ?>
                          <?php if ($size_query["sbnotes"]<>"")
			  					echo ' ['.$size_query["sbnotes"].']'; ?>
</div>
</div>







<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00007_ADVERTISE." "; /*-~- Destination URL -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php echo($_POST['banner_type']!="flash")? sbhtmlentities(stripslashes($_REQUEST['url']),ENT_QUOTES) : $config['null_char'];?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">
<?php /*1s*/ echo "".SOFTBIZ_LC00004_ADVERTISE.""; /*-~- Banner Type -~-*/ /*1e*/ ?>
</div>
<div class="col-md-6">
<?php echo sbhtmlentities(stripslashes($_POST['banner_type']),ENT_QUOTES) ;?>
</div>
</div>

<div class="row">
<div class="col-md-4 bold-text">

</div>
<div class="col-md-2">

<FORM name="form123" method="post" action="insert_banner.php">
					    <input name="sbplan" type="hidden" id="sbplan" value="<?php echo $sbplan; ?>">
					  <input name="url" type="hidden" id="url" value="<?php echo sbhtmlentities(stripslashes($_POST['url']),ENT_QUOTES) ;?>">
					  <input name="banner_type" type="hidden" id="banner_type" value="<?php echo sbhtmlentities(stripslashes($_POST['banner_type']),ENT_QUOTES) ;?>">
					  <input name="bannerurl" type="hidden" id="bannerurl" value="<?php echo sbhtmlentities(stripslashes( $_POST['bannerurl']),ENT_QUOTES) ;?>">
					  <input class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00001_CONFIRM_TEXTAD.""; /*-~- Add -~-*/ /*1e*/ ?>" name=submit>
					  </form>
                      

</div>
<div class="col-md-2">
<FORM name="formcancel" method="post" action="ads.php">
					  <input  class="btn btn-danger" type="submit" name="Submit" value="<?php /*1s*/ echo "".SOFTBIZ_LC00002_CONFIRM_TEXTAD.""; /*-~- Cancel -~-*/ /*1e*/ ?>" >
                      </form>
                      
                      

</div>
</div>


<div class="row">
<div class="col-md-4 bold-text">
</div>
<div class="col-md-6">
<strong><?php /*1s*/ echo "".SOFTBIZ_LC00003_CONFIRM_TEXTAD.""; /*-~- NOTE: -~-*/ /*1e*/ ?></strong>
<?php /*1s*/ echo "".SOFTBIZ_LC00002_BUY_MORE.""; /*-~- This process is irreversible, money once paid can't be refunded. -~-*/ /*1e*/ ?>
</div>
</div>
@endsection
@include('includes.panel-one', ['title' =>$form_title,'data'=>'package'])


  
  
  
