<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>

 @section('choose-type')

 <form class="form-horizontal"  name="form123" onsubmit="return(formValidate(this));" method="post" action="<?php echo $act; ?>">



<?php 
                      if($_REQUEST['adtype']!='text')
					  {
						  
						  
						  
						  $size_query=mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where 1 order by sborder");
		$cnt=0;
		$sbi=0;
		            
		while($size=mysqli_fetch_array($size_query))
		{
		            
			$sql="select * from sbbanners_plans where sbtype=1 and size_id=".$size["id"]." order by price desc";
			$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
			$num_plans=mysqli_num_rows($rs0_query);
                   	
			            
			if($num_plans>0)
			{		
				
				if($sbi==0)
				{
					$sbi++;		//used here to display rows once only	
					
					  ?>
 <div class="row">                     
 <div class="col-md-12 specific-info darkgray">
                      <?php /*1s*/ echo "".SOFTBIZ_LC00001_CHOOSE_TYPE.""; /*-~- Package Type: Impressions Based -~-*/ /*1e*/ ?>
</div>                     
  </div> <?php } ?>
   <div class="row">      
 <div class="col-md-12 specific-info" >
       
        <strong><?php /*1s*/ echo "".SOFTBIZ_LC00006_CHOOSE_TYPE." "; /*-~- Size -~-*/ /*1e*/ ?>:</strong>  <?php echo $size["width"]."x".$size["height"]; ?><?php /*1s*/ echo " ".SOFTBIZ_LC00007_CHOOSE_TYPE." "; /*-~- px -~-*/ /*1e*/ ?>  <?php if ($size["sbnotes"]<>"")
			  					echo "[" . $size["sbnotes"] . "]" ;?> 
                                
</div>             
</div>

<fieldset class="form-group row">
<label class="col-md-11  form-control-label" for="" style="font-weight:normal">
<?php
}
?>
 
<?php
		while ($rs0=mysqli_fetch_array($rs0_query))
			{
				$cnt++;	?>
                
                                      

  
<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"] . " " . SOFTBIZ_LC00003_CHOOSE_TYPE . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Impressions for ?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>
 

 <?php
}	//end while
?>   <?php  if($num_plans>0)
			{  ?> </label></fieldset> <?php } ?>

<?php
		}		//end while
 ?>


<?php
// Starting code for click based banner ads 
?>

<?php
$size_query=mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where 1 order by sborder");
		$sbi=0;
		while($size=mysqli_fetch_array($size_query))
		{
		            
			$sql="select * from sbbanners_plans where sbtype=2 and size_id=".$size["id"]." order by price desc";
			$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
			$num_plans=mysqli_num_rows($rs0_query);
			            
			if($num_plans>0)
			{
				if($sbi==0)
				{
					$sbi++;		//used here to display rows once only
							?>

<div class="row">                     
 <div class="col-md-12 specific-info  darkgray">
 <?php /*1s*/ echo "".SOFTBIZ_LC00008_CHOOSE_TYPE.""; /*-~- Package Type: Click Based -~-*/ /*1e*/ ?>
</div></div>
<?php 		}		//end if $sbi=0 ?>


<div class="row">                     
 <div class="col-md-12 specific-info">
       
        <strong><?php /*1s*/ echo "".SOFTBIZ_LC00006_CHOOSE_TYPE." "; /*-~- Size -~-*/ /*1e*/ ?>:</strong>  <?php echo $size["width"]."x".$size["height"]; ?><?php /*1s*/ echo " ".SOFTBIZ_LC00007_CHOOSE_TYPE." "; /*-~- px -~-*/ /*1e*/ ?>  <?php if ($size["sbnotes"]<>"")
			  					echo "[" . $size["sbnotes"] . "]" ;?> 
                                
</div>             
</div>
<fieldset class="form-group row">
<label class="col-md-11  form-control-label" for="" style="font-weight:normal"><?php

$closefiledset=1;
			}
			?>




<?php
		while ($rs0=mysqli_fetch_array($rs0_query))
			{
				$cnt++;	?>
  
  
    
<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"] . " " . SOFTBIZ_LC00009_CHOOSE_TYPE . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Clicks for ?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>
  

 <?php
}	//end while
?>  <?php  if($closefiledset==1)
			{  ?> </label></fieldset> <?php $closefiledset=0; } ?>

<?php
		}		//end while
 ?>
 
               
                
  
<?php
// Starting code for TIME based banner ads 
?>
  
   <?php
							            
$size_query=mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_sizes where 1 order by sborder");
		$sbi=0;
		            
		while($size=mysqli_fetch_array($size_query))
		{
		            
			$sql="select * from sbbanners_plans where sbtype=3 and size_id=".$size["id"]." order by price desc";
			$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
			$num_plans=mysqli_num_rows($rs0_query);
			            
			if($num_plans>0)
			{
				if($sbi==0)
				{
					$sbi++;		//used here to display rows once only
							?>
                            
                            
<div class="row">                     
 <div class="col-md-12 specific-info  darkgray">
 <?php /*1s*/ echo "".SOFTBIZ_LC00011_CHOOSE_TYPE.""; /*-~- Package Type: Time Based -~-*/ /*1e*/ ?>      
 </div></div>
 <?php 		}		//end if $sbi=0 ?>
 
             
                            
 <div class="row">                     
 <div class="col-md-12 specific-info">
       
        <strong><?php /*1s*/ echo "".SOFTBIZ_LC00006_CHOOSE_TYPE." "; /*-~- Size -~-*/ /*1e*/ ?>:</strong>  <?php echo $size["width"]."x".$size["height"]; ?><?php /*1s*/ echo " ".SOFTBIZ_LC00007_CHOOSE_TYPE." "; /*-~- px -~-*/ /*1e*/ ?>  <?php if ($size["sbnotes"]<>"")
			  					echo "[" . $size["sbnotes"] . "]" ;?> 
                                
</div>  </div>           

<fieldset class="form-group row">
 <label class="col-md-11  form-control-label" for="" style="font-weight:normal"> <?php
$closefiledset=1;
			}
			?>





<?php
		while ($rs0=mysqli_fetch_array($rs0_query))
			{
				$cnt++;	?>
  
  
  
<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"]; echo ($rs0["credits"]==1)? /*2s*/ " ".SOFTBIZ_LC00003_MYACCOUNT."" /*-~-* / "Month" / *-~-*/ /*2e*/ :/*2s*/ " ".SOFTBIZ_LC00016_CHOOSE_TYPE."" /*-~-* / "Months" / *-~-*/ /*2e*/ ; ?> <?php echo  " "  . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Clicks for ?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>


 <?php
}	//end while
?>  <?php  if($closefiledset==1)
			{  ?> </label></fieldset> <?php $closefiledset=0; } ?>

<?php
		}		//end while
 ?>
 
 
 <?php
 
 //Now Entering ELSE PART i.e. the text ads part 
 //Starting with impression based text
 ?>
 <?php }else{?>
 
<?php
							            
$cnt=0;
			$sql="select * from sbbanners_textad_plans where sbtype=1 order by price desc";
			$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
			$num_plans=mysqli_num_rows($rs0_query);
			            
			if($num_plans>0)
			{		
				if($cnt==0)	{ 
			?>
            
            
 <div class="row">                     
 <div class="col-md-12 specific-info">
                      <?php /*1s*/ echo "".SOFTBIZ_LC00001_CHOOSE_TYPE.""; /*-~- Package Type: Impressions Based -~-*/ /*1e*/ ?>
</div></div>                     
	
 <fieldset class="form-group row">
 <label class="col-md-11  form-control-label" for="" style="font-weight:normal"> 
				
				<?php
				
				$closefiledset=1;
				}
				
			}
			?>                             
     
<?php


		while ($rs0=mysqli_fetch_array($rs0_query))
			{
				$cnt++;	?>
                
<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"] ?> <?php echo  " "  . SOFTBIZ_LC00003_CHOOSE_TYPE . " "  . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Impressions for ?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>
  

 <?php
}	//end while
?> 
                
                      
     <?php  if($closefiledset==1)
			{  ?> </label></fieldset> <?php $closefiledset=0; } ?>
                            
<?php

// Now click based text

?>
<?php
							            
$sbi=0;
                   	
			$sql="select * from sbbanners_textad_plans where sbtype=2 order by price desc";
			$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
			$num_plans=mysqli_num_rows($rs0_query);
			            
			if($num_plans>0)
			{
				if($sbi==0)
				{
					$sbi++;		//used here to display rows once only
							?>



<div class="row">                     
 <div class="col-md-12 specific-info">
                      <?php /*1s*/ echo "".SOFTBIZ_LC00008_CHOOSE_TYPE.""; /*-~- Package Type: Click Based -~-*/ /*1e*/ ?>
</div> </div>             
<fieldset class="form-group row">
 <label class="col-md-11  form-control-label" for="" style="font-weight:normal"> 

 <?php 		
 
 $closefiledset=1;
 }		//end if $sbi=0 ?>
 
 
 <?php
} ?>

  <?php

		while ($rs0=mysqli_fetch_array($rs0_query))
			{
				$cnt++;	?>
                
                
   
<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"] ?> <?php echo  " "  . SOFTBIZ_LC00009_CHOOSE_TYPE . " "  . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Clicks for ?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>
  

 <?php
}	//end while
?> 
                
       <?php  if($closefiledset==1)
			{  ?> </label></fieldset> <?php $closefiledset=0; } ?>

<?php

// Now Time based text

?>

 <?php
							            
$sbi=0;
			$sql="select * from sbbanners_textad_plans where sbtype=3 order by price desc";
			$rs0_query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
			$num_plans=mysqli_num_rows($rs0_query);
			            
			if($num_plans>0)
			{
				if($sbi==0)
				{
					$sbi++;		//used here to display rows once only
							?>
                            
<div class="row">                     
 <div class="col-md-12 specific-info">
                     <?php /*1s*/ echo "".SOFTBIZ_LC00011_CHOOSE_TYPE.""; /*-~- Package Type: Time Based -~-*/ /*1e*/ ?>
                     </div>         </div>

<fieldset class="form-group row">
<label class="col-md-11  form-control-label" for="" style="font-weight:normal"> <?php 	$closefiledset=1;	}		//end if $sbi=0 ?>
 
 
 <?php
} ?>
                            
  
  <?php

		while ($rs0=mysqli_fetch_array($rs0_query))
			{
				$cnt++;	?>
                
                
    
<input name="plan" type="radio" value="<?php echo $rs0["id"]; ?>" <?php
echo($cnt==1)?"checked":''; ?>> <strong><?php echo $rs0["sbname"]; ?></strong>  <?php echo $rs0["credits"]; echo ($rs0["credits"]==1)? /*2s*/ " ".SOFTBIZ_LC00003_MYACCOUNT."" /*-~-* / "Month" / *-~-*/ /*2e*/ :/*2s*/ " ".SOFTBIZ_LC00016_CHOOSE_TYPE."" /*-~-* / "Months" / *-~-*/ /*2e*/ ; ?> <?php echo  " "  . " " . SOFTBIZ_LCUPDT2015111000000_12 . " " ; //Clicks for ?><?php echo $sb_fee_currency.sbcurrency_format($rs0["price"]); ?><br>
 

 <?php
}	//end while
?> 
                
                      
     <?php  if($closefiledset==1)
			{  ?> </label></fieldset> <?php $closefiledset=0; } ?>


<?php }  // End of else part for text ads
				
	


			
				
					  ?>

<fieldset class="form-group row">
  <div class="col-md-11">
<input class="btn btn-primary" type=submit value="<?php /*1s*/ echo "".SOFTBIZ_LC00014_CHOOSE_TYPE.""; /*-~- Continue -~-*/ /*1e*/ ?>" name=submit>
  </div>
</fieldset>

<?php 	if($cnt==0)
									{	//i.e. no rec to display
									?>
 <div class="col-md-12 specific-info">
                                   <?php /*1s*/ echo "".SOFTBIZ_LC00015_CHOOSE_TYPE.""; /*-~- There are no purchase packages defined by the admin. -~-*/ /*1e*/ ?>
                                   </div>
                                    <?php 	}	//end else if $cnt>1?>


</form>  
    @endsection

@include('includes.panel-two', ['title' =>$form_title,'data'=>'choose-type'])

                    
                          
 
