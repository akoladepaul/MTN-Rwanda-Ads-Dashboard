<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Si prega di specificare un titolo!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Titolo sopra di 25 caratteri non è permesso!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Si prega di specificare un description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 sopra 35 carattere non è permesso!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Si prega di specificare un description2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Description2 sopra 35 carattere non è permesso!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Si prega di specificare URL di visualizzazione!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Si prega di specificare URL di destinazione!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Si prega di caricare un immagine del banner.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Modifica informazioni Testo annuncio");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Titolo");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","linee guida editoriali");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Titolo non dovrebbe essere più di 25 caratteri.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","Descrizione 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","Descrizione non dovrebbe essere più di 35 caratteri.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","Descrizione 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","URL di visualizzazione");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","URL di visualizzazione non deve essere più di 35 caratteri.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","URL di destinazione");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","Indirizzo di destinazione deve includere http: // www. per esempio. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Aggiornare");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Il tuo banner non sarà visualizzato fino a quando Admin approva le modifiche.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","ID non valido, in grado di continuare");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","L'accesso non autorizzato, in grado di continuare");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Si prega di specificare l'indirizzo e-mail valido");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","Indirizzo e-mail sembra errato (controllo @ e di.)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","Il nome utente non sembra essere valido.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","Indirizzo IP di destinazione non è valido!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","Il nome di dominio non sembra essere valido.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","L'indirizzo deve terminare con un dominio valido, o due lettere paese.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","L'indirizzo è manca un nome host!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Carica file immagine");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Scegliere un file da caricare");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Si prega di caricare .gif / .jpg / .jpeg / .bmp / ​​.png file solo");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Si prega di caricare i file .swf solo");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Carica immagine");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Per aggiungere un'immagine, fare clic sul pulsante 'Sfoglia' e selezionare il file o digitare il percorso del file nella casella di testo qui sotto.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Quindi fare clic su Carica pulsante per completare il processo.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","NOTA");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","Il trasferimento dei file può richiedere da pochi secondi ad alcuni minuti a seconda della dimensione del file. Aspetta mentre viene caricato il file.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","Il file verrà rinominato se il file con lo stesso nome è già presente");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Premi il pulsante [Sfoglia] per trovare il file sul computer.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Immagine");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Caricare");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Scegli le date");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","Da parte di");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","Giorno");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Mese");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Anno");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","A");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Record per pagina");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","Mostrare");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Aggiungere denaro");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Quantità");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Data");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Descrizione");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","Le transazioni");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","Nessuna transazione trovato soddisfino i tuoi criteri.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Il tuo saldo attuale è% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Pagina% 1 $ s di% 2 $ s <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Acquisto pacchetto");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Tipo confezione: Impressioni Based");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Nome del pacchetto");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","impressioni");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Prezzo");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Prezzo / Impression");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Dimensione");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Tipo confezione: Clicca Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","clic");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Prezzo / Click");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Tipo confezione: Time Based");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Durata");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Prezzo / mese");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","proseguire");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","Non ci sono formule di acquisto definite da un amministratore.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","mesi");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Accesso non valido, in grado di continuare");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","Cartellone pubblicitario");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","Testo annuncio");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Il tuo% 1 $ s è stato accreditato richiesta% 2 $ s.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Alcuni Errore, riprova");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","Accesso non autorizzato, negato");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","Annuncio di testo è stato aggiunto. Il tuo annuncio di testo apparirà nel nostro banner dei rotatori non appena sarà approvato.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","Annuncio di testo è stato aggiunto.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Il componente aggiuntivo richiesta di annuncio di testo non è stato elaborato a causa della mancanza di fondi. Aggiungete un po 'di denaro sul tuo conto e riprova");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Alcuni errori si è verificato, riprova");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Le modifiche sono state inviate per l'approvazione di amministrazione");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","accesso Inavlid, in grado di continuare");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","Impossibile aggiornare i dettagli della bandiera, riprova");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Scegliere tipo corretto bandiera");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Aggiungi nuovo Banner");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","tipo di pacchetto");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","Banner Size");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Tipo Banner");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Immagine (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","URL di destinazione");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","URL di destinazione non richiesto per il tipo di banner flash. Destinazione indirizzo del sito web dovrebbe comprende http: // www. per esempio. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","Immagine banner");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Rimuovere");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Impressione");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Clic");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","Devi essere loggato per accedere a questa pagina!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Aiuto per il testo annuncio distacco");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Norme redazionali");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Si prega di inserire le informazioni di accesso!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Benvenuto% s, sei connesso in successo.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Si prega di inserire dati di accesso corretti!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Acquista più impressioni");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Acquista ora");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Questo processo è irreversibile, una volta che il denaro versato non può essere rimborsato.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","Non vi è alcun pacchetto disponibile per questo formato banner.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","Non vi è alcun pacchetto disponibile per questo annuncio di testo.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","impressioni base");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Clicca Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","Time Based");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Banner non trovato. Clic");
//here
define("SOFTBIZ_LC00009_BUY_MORE","Qui");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","continuare");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Contenuto annuncio");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Aggiungere");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Annulla");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","NOTA:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Indietro");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Siamo spiacenti, inserzionista con l'e-mail% s esiste già.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","Stai Registerd successo con noi");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Alcuni Errore durante. Riprova!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","pagare");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Importo da aggiungere");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Bilancio corrente");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Equilibrio dopo l'aggiunta");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Aggiungere denaro per tenere conto");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Il denaro aggiunto al tuo conto");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Continuare a pagamento di Paypal");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Continuare a pagamento 2Checkout");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Termini e condizioni");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","disconnesso");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","attraverso Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","attraverso 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","La password è stata cambiata!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","La password non può essere aggiornato perché la vecchia password non era corretta");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Si prega di specificare un valore diverso da zero positivo numerico!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Aggiungi al mio account");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Metodo di pagamento");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Pay Offline");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","aggiungi annuncio di testo");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","aggiungi bandiera");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","comprare di più la durata");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","comprare più clic");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","acquistare più impressioni");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","Richiedi il tuo% s non è stato elaborato a causa della mancanza di fondi. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Hai bisogno di almeno% s per il pacchetto scelto. <br> Aggiungere un po 'di denaro sul tuo conto o scegliere qualche altro pacchetto");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Si prega di inserire la password attuale");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Cambia la password");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","Password attuale");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","nuova password");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Ripeti password");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Aggiornamento password");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Nuova password deve essere lunga atleast% s caratteri");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Si prega di inserire la nuova password");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","Password riscritto doesnot corrisponde alla nuova password");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","deve essere atleast% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","carattere");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","personaggi");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Il tuo banner è stato aggiornato");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Statistiche Banner aggregata per tutti i tuoi banner");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Numero totale di bandiere Pubblicato");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","Approvato");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","Non approvato");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Totale impressioni ricevute");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Totale click ricevuti");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Media Click Through Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Ultime Impression");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Ultimo Click");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","Più visualizzati Banner / Testo annuncio");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","La più cliccata Banner / Testo annuncio");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Statistiche: clic / impressioni");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Oggi");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Ieri");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Ultimi 7 giorni");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Ultimi 14 giorni");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","L'anno scorso");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","Questo Anno: clic / impressioni");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","Questo mese: clic / impressioni");
//January
define("SOFTBIZ_LC00019_AD_HOME","gennaio");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Febbraio");
//March
define("SOFTBIZ_LC00021_AD_HOME","marzo");
//April
define("SOFTBIZ_LC00022_AD_HOME","aprile");
//May
define("SOFTBIZ_LC00023_AD_HOME","Può");
//June
define("SOFTBIZ_LC00024_AD_HOME","giugno");
//July
define("SOFTBIZ_LC00025_AD_HOME","luglio");
//August
define("SOFTBIZ_LC00026_AD_HOME","agosto");
//September
define("SOFTBIZ_LC00027_AD_HOME","settembre");
//October
define("SOFTBIZ_LC00028_AD_HOME","ottobre");
//November
define("SOFTBIZ_LC00029_AD_HOME","novembre");
//December
define("SOFTBIZ_LC00030_AD_HOME","dicembre");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Banner è stato aggiunto. Il tuo banner apparirà nel nostro banner dei rotatori non appena sarà approvato.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Banner è stato aggiunto.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","La tua richiesta aggiungono la bandiera non è stato elaborato a causa della mancanza di fondi. Aggiungete un po 'di denaro sul tuo conto e riprova");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Tipi di annunci");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Scegli Tipo di annuncio");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Indirizzo email non valido.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Si prega di specificare il codice di convalida");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Ha dimenticato la password");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Si prega di fornire la tua email id. Invieremo la password in email.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","E-mail identificativo utente");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Codice di validazione");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Invia richiesta");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","Il nome utente l'indirizzo e-mail sembra valido");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","IP di destinazione l'indirizzo e-mail non è valido");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","Il nome di dominio nell'indirizzo di posta elettronica sembra valido");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","L'indirizzo email deve terminare in un dominio valido o due lettere paese");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","Indirizzo e-mail manca un nome host");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Specificare il testo visualizzato l'immagine del codice di convalida sopra. Questo testo è caso sensibile.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","codice di convalida specificato non era corretta");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","Per favore inserisci il tuo nome!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Inserisci il tuo indirizzo!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Inserisci la tua città!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Inserisci il tuo Stato!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Selezionare il paese!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Inserisci il tuo URL del sito web!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Per favore, inserisci la password.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Le passwords non corrispondono.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Nuovo inserzionista: iscrizione compilando seguente modulo");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Il tuo nome");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Il tuo indirizzo");
//City
define("SOFTBIZ_LC00011_SITEHOME","Città");
//State
define("SOFTBIZ_LC00012_SITEHOME","Stato");
//Country
define("SOFTBIZ_LC00013_SITEHOME","Nazione");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Seleziona un Paese");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","URL del sito");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","La tua email");
//Password
define("SOFTBIZ_LC00017_SITEHOME","parola d'ordine");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","conferma password");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","invio");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Si prega di specificare il tuo indirizzo email.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Si prega di specificare la password.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Gli inserzionisti esistenti: clicca qui");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Registrati");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","La password deve essere lunga caratteri atleast% s.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","inserzionista Menu");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Casa");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Modifica Profilo");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Disconnettersi");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","I miei annunci");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Aggiungi nuovo annuncio");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Gestione degli annunci");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Tutti gli annunci di testo");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","tutti i banner");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Il mio account");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Hi <font class = 'red'> '% 1 $ s' </ font>, il tuo saldo del conto è% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Combinazione di colori");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Inserisci un valore numerico valido per la bandiera #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Ricerca Banner / Testo annuncio");
//Keyword
define("SOFTBIZ_LC00002_ADS","Parola chiave");
//Search in
define("SOFTBIZ_LC00003_ADS","Cerca nel");
//Banner #
define("SOFTBIZ_LC00004_ADS","Banner #");
//All
define("SOFTBIZ_LC00005_ADS","Tutti");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","In attesa di approvazione");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Tutte le taglie");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Tipo di annuncio");
//All Packages
define("SOFTBIZ_LC00009_ADS","tutti i pacchetti");
//Sort by
define("SOFTBIZ_LC00010_ADS","Ordina per");
//Date Added
define("SOFTBIZ_LC00011_ADS","data aggiunta");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","impressioni acquistate");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Data di scadenza");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","impressioni ricevute");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","click ricevuti");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","impressioni sinistra");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","clic sinistro");
//Days Left
define("SOFTBIZ_LC00018_ADS","giorni sinistra");
//Order
define("SOFTBIZ_LC00019_ADS","Ordine");
//Ascending
define("SOFTBIZ_LC00020_ADS","Ascendente");
//Descending
define("SOFTBIZ_LC00021_ADS","Discendente");
//Search
define("SOFTBIZ_LC00022_ADS","Ricerca");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Percentuale di clic");
//Status
define("SOFTBIZ_LC00024_ADS","Stato");
//Note
define("SOFTBIZ_LC00025_ADS","Nota");
//Buy More
define("SOFTBIZ_LC00026_ADS","Compra di più");
//Edit
define("SOFTBIZ_LC00027_ADS","Modifica");
//Stats
define("SOFTBIZ_LC00028_ADS","Statistiche");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","No Ad soddisfano i criteri specificati.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Risultati della ricerca per annuncio% s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","risultati della ricerca annuncio per l'annuncio #% s");
//Banner
define("SOFTBIZ_LC00032_ADS","bandiera");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Testo Tipo di annuncio");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","clic acquistate");
//Expired
define("SOFTBIZ_LC00035_ADS","Scaduto");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","Pagina% s di% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Modifica Banner Informazioni");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","URL di destinazione non richiesto per il tipo di banner flash. Indirizzo di destinazione deve includere http: // www. per esempio. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","statistica");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Digitare");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","postato su");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Si prega di fornire il proprio ID e-mail per recuperare la password!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","La password è stata via e-mail");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","E-mail è stato disattivato da admin, in grado di inviare la password.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","Nessun membro trovato con tale id-mail!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Il tuo profilo è stato aggiornato");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Aggiungere Processo di denaro");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","Hai cancellato il tuo denaro richiesta di aggiunta a paypal.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Nuovo annuncio di testo pubblicato: Clic");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Nuovo annuncio di testo pubblicato: Impressioni");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Nuovo annuncio di testo pubblicato: Mesi");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","Estesa annuncio di testo: Clic");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","Estesa annuncio di testo: Impressioni");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","Estesa annuncio di testo: Mesi");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Nuovo Banner annuncio postato: Clic");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Nuovo Banner annuncio postato: Impressioni");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Nuovo Banner annuncio postato: Mesi");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","Esteso banner: Clic");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","Esteso banner: Impressioni");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","Esteso banner: Mesi");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","Il denaro aggiunto attraverso 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","Il denaro aggiunto con paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","per andare al inserzionista casa.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","per aggiungere nuovo annuncio.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","per gestire i vostri annunci.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","per aggiungere i soldi sul conto.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","per visualizzare le transazioni di conto.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","logout");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Si prega di essere a conoscenza se il testo dell'annuncio non è conforme alle linee guida editoriali allora il vostro annuncio potrebbe essere sospeso");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Titolo non dovrebbe essere più di 25 caratteri.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Si prega di specificare un description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 non dovrebbe essere più di 35 caratteri.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Description2 non dovrebbe essere più di 35 caratteri.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","Informazioni sul pacchetto");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Aggiungere Contenuto");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Destinazione indirizzo del sito web dovrebbe comprende http: // www <br> ad es.. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Il pagamento è stato aggiunto al tuo conto");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Accesso non valido, negato");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Il componente aggiuntivo Richiedi pagamento è stato accettato. I fondi saranno molto presto apparirà nel tuo account.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Stato di caricamento di file di immagine");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","Image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","FINIRE");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Solo .jpg / png / gif / bmp / ​​jpeg / .swf formati di file sono consentiti. <br> Si prega di chiudere questa finestra e riprova");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","File caricati deve essere inferiore% SKB. Si prega di chiudere questa finestra e riprova");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Successo: file è stato caricato");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Errore: Dimensioni più di 512000 byte");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Errore: file parzialmente caricato");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Errore: Nessun file Caricati");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","File non può essere caricato, probabilmente a causa di restrizioni nei permessi di directory di destinazione");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Errore: File non caricato. Controllare la dimensione e riprovare.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Torna indietro");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Tutti i diritti riservati.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Messaggio");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","per");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Inserisci nuovo annuncio");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","La mia impressione annunci");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Clicca Based annunci");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","Tempo legato annunci");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Premi il pulsante [Sfoglia] per trovare il file sul computer e quindi fare clic sul pulsante [Inserisci] per caricarlo.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Immagine");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Caricare");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Aspetta, non riceverai alcuna notifica fino a quando il file viene completamente trasferito.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Questa funzione è stata disabilitata nella demo.");

?>