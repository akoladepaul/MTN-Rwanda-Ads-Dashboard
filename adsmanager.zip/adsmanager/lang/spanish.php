<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Por favor, especifique un título!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Título superior a 25 caracteres no está permitido!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Por favor especificar una description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 por encima de 35 caracteres no está permitido!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Por favor especificar una descripción2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Descripción2 por encima de 35 caracteres no está permitido!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Por favor, especifique la URL visible!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Por favor especifique la URL de destino!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Sube una imagen de una bandera.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Editar la información del texto del anuncio");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Título");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","directrices editoriales");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","El título no debe contener más de 25 caracteres.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","Descripción 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","La descripción no debe ser más de 35 caracteres.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","Descripción 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","URL visible");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Ver URL no debe contener más de 35 caracteres.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","URL de destino");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","Dirección de destino debe incluir http: // www. p.ej. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Actualizar");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Su bandera no se mostrará hasta que aprueba los cambios de administración.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","ID no válida, incapaz de continuar");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","El acceso no autorizado, incapaz de continuar");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Por favor, especifique la dirección de correo electrónico válida");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","dirección de correo electrónico parece incorrecto (cheque @ y del.)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","El nombre de usuario no parece ser válida.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","Dirección IP de destino no es válido!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","El nombre de dominio no parece ser válida.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","La dirección debe terminar en un dominio válido, o dos letras del país.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","Esta dirección no se encuentra un nombre de host!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Sube un archivo de imagen");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Por favor, seleccione un archivo para cargar");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Por favor, sube .gif / .jpg / .jpeg / bmp / ​​png sólo de archivos");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Por favor, sube archivos .swf solamente");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Cargar imagen");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Para añadir una imagen, haga clic en el botón \"Examinar\" y seleccione el archivo o escriba la ruta de acceso al archivo en el cuadro de texto a continuación.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Luego haga clic en el botón Subir para completar el proceso.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","NOTA");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","La transferencia de archivos puede llevar desde unos pocos segundos a unos pocos minutos, dependiendo del tamaño del archivo. Espere un momento el archivo está siendo cargado.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","El archivo será renombrado si el archivo con el mismo nombre ya está presente");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Golpear el botón [Examinar] para buscar el archivo en su ordenador.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Imagen");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Subir");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","elegir fechas");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","De");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","Día");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Mes");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Año");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","A");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Registros por página");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","Espectáculo");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Agregar dinero");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Cantidad");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Fecha");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Descripción");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","Actas");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","No se han encontrado transacciones que cumplan sus criterios.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Su saldo actual es% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","La página% 1 $ s de% 2 $ s <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","la compra del paquete");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Tipo de paquete: impresiones sobre la base");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Nombre del paquete");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","impresiones");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Precio");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Precio / Impresión");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","tamaño");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Tipo de paquete: Haga clic Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","clics");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Precio / Haga clic");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Tipo de paquete: basada en el tiempo");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Duración");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Precio / Mes");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","Continuar");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","No hay paquetes de compra definidos por el administrador.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","Meses");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Acceso no válido, incapaz de continuar");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","Cartel publicitario");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","texto del anuncio");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Su% 1 $ s se ha acreditado los solicitados% 2 $ s.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Algunos de error ocurrido, por favor intente de nuevo");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","El acceso no autorizado, denegado");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","anuncio de texto se ha añadido con éxito. Su anuncio de texto aparecerá en nuestro banner rotador tan pronto como sea aprobada.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","anuncio de texto se ha añadido con éxito.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Su petición de añadir el texto del anuncio no se ha procesado debido a la falta de fondos. Añadir un poco de dinero a su cuenta y vuelva a intentarlo");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Algunos Error al Inténtelo de nuevo");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Los cambios se han enviado para su aprobación del administrador");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","Acceso Inavlid, incapaz de continuar");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","No se puede actualizar datos de banner, por favor intente de nuevo");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Por favor, elegir el tipo correcto de la bandera");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Añadir Nuevo Banner");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","Tipo de paquete");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","tamaño de su lona");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Tipo Banner");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Imagen (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","URL de destino");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","URL de destino no se requiere para el tipo banner en flash. Destino dirección del sitio web debe incluye http: // www. p.ej. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","imagen del Anuncio");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","retirar");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Impresión");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Hacer clic");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","Tienes que iniciar sesión para acceder a esta página!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Ayuda para texto Ad posting");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Guía editorial");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Por favor, introduzca la información de inicio de sesión!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Bienvenido% s, que tiene en que ha iniciado sesión con éxito.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Por favor, introduzca la información de inicio de sesión correcto!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Comprar más impresiones");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Compra ahora");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Este proceso es irreversible, una vez que el dinero pagado no puede ser devuelto.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","No hay paquetes disponibles para este tamaño de banner.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","No hay paquetes disponibles para este anuncio de texto.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","Basado impresiones");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Haga clic Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","basada en el tiempo");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Banner no encontrado. Hacer clic");
//here
define("SOFTBIZ_LC00009_BUY_MORE","aquí");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","continuar");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Contenido del anuncio");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Añadir");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Cancelar");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","NOTA:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Espalda");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Lo sentimos, anunciante con el correo electrónico% s ya existe.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","Estás Registerd éxito con nosotros");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Algunos error ha ocurrido. Inténtalo de nuevo!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","Paga");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Cantidad a añadir");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Saldo actual");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","El equilibrio después de la adición");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Agregar dinero a la cuenta");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","El dinero añadido a su cuenta");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Continuará el pago de PayPal");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Continúe 2Checkout Pago");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Términos y Condiciones");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","Desconectado");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","A través de Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","A través de 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","¡La contraseña ha sido cambiada!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","La contraseña no se ha podido actualizar porque su antigua contraseña era incorrecta");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Por favor, especifique un valor numérico positivo distinto de cero!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Añadir a mi cuenta");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Método de pago");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Pago Desconectado");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","añadir el texto del anuncio");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","agrega la bandera");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","comprar más duración");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","comprar más clics");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","comprar más impresiones");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","Su% s petición no ha sido procesada debido a la falta de fondos. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Se necesita al menos% s para el paquete elegido. <br> Añadir un poco de dinero a su cuenta o elegir algún otro paquete");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Por favor, introduzca su contraseña actual");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Cambia la contraseña");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","contraseña actual");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","nueva contraseña");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Vuelva a escribir la contraseña");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Actualiza contraseña");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Nueva contraseña debe tener al menos% s caracteres");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Por favor, introduzca la nueva contraseña");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","volver a teclear la contraseña doesnot coincidir con la nueva contraseña");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","debe tener una antigüedad% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","personaje");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","caracteres");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Su banner se ha actualizado");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Estadísticas agregadas Banner para todas sus Banderas");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Número total de Banderas de publicación");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","Aprobado");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","desaprobado");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Impresiones totales recibidos");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Total de clics recibidos");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Promedio Click Through Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","última impresión");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Haga clic última");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","Más mostrados Banner / texto del anuncio");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","La mayoría Ad / Texto Clicked Banner");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Estadística: clics / impresiones");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Hoy");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Ayer");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Los últimos 7 días");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Últimos 14 días");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","El año pasado");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","Este Año: clics / impresiones");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","Este mes: clics / impresiones");
//January
define("SOFTBIZ_LC00019_AD_HOME","enero");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","febuary");
//March
define("SOFTBIZ_LC00021_AD_HOME","marzo");
//April
define("SOFTBIZ_LC00022_AD_HOME","abril");
//May
define("SOFTBIZ_LC00023_AD_HOME","Mayo");
//June
define("SOFTBIZ_LC00024_AD_HOME","junio");
//July
define("SOFTBIZ_LC00025_AD_HOME","julio");
//August
define("SOFTBIZ_LC00026_AD_HOME","agosto");
//September
define("SOFTBIZ_LC00027_AD_HOME","septiembre");
//October
define("SOFTBIZ_LC00028_AD_HOME","octubre");
//November
define("SOFTBIZ_LC00029_AD_HOME","noviembre");
//December
define("SOFTBIZ_LC00030_AD_HOME","diciembre");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Banner ha sido agregado con éxito. Su Banner aparecerá en nuestro banner rotador tan pronto como sea aprobada.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Banner ha sido agregado con éxito.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","Su solicitud agrega la bandera no ha sido procesada debido a la falta de fondos. Añadir un poco de dinero a su cuenta y vuelva a intentarlo");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Tipos de anuncio");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Elija tipo de anuncio");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","dirección de correo electrónico válida.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Por favor, especifique el código de validación");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Se te olvidó tu contraseña");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Por favor proporcione su correo electrónico de identificación. Le enviaremos su contraseña por correo electrónico.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","Identificación de correo");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Código de validación");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Enviar petición");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","El nombre de usuario en la dirección de correo electrónico parece no válido");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","IP de destino en la dirección de correo electrónico no es válido");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","El nombre de dominio en la dirección de correo electrónico parece no válido");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","La dirección de correo electrónico debe terminar en un dominio válido o dos letras del país");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","dirección de correo electrónico no se encuentra un nombre de host");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Especificar el texto que se muestra la imagen de código de validación anteriormente en. Este texto es el caso en minúsculas.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","código de validación especificada es incorrecta");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","¡Por favor, escriba su nombre!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Por favor, introduzca su dirección!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Por favor, introduzca su ciudad!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Por favor ingrese su estado!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Por favor seleccione el país!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Introduzca su URL del sitio web!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Por favor, ingrese contraseña.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Las contraseñas no coinciden.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Nuevo Anunciante: Inscripción rellenando siguiente formulario");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Tu nombre");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Su dirección");
//City
define("SOFTBIZ_LC00011_SITEHOME","Ciudad");
//State
define("SOFTBIZ_LC00012_SITEHOME","Estado");
//Country
define("SOFTBIZ_LC00013_SITEHOME","País");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Seleccione un país");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","URL del sitio web");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Tu correo electrónico");
//Password
define("SOFTBIZ_LC00017_SITEHOME","Contraseña");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","Confirmar contraseña");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","Enviar");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Por favor, indique su dirección de correo electrónico.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Por favor, especifique la contraseña.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Los anunciantes: Conexión aquí");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Registrarse");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","La contraseña debe tener al menos% s caracteres de longitud.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","Menú del anunciante");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Casa");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Editar perfil");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Cerrar sesión");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","Mis Anuncios");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Añadir nuevo anuncio");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Administrar anuncios");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Todos los anuncios de texto");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","todas las Banderas");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Mi cuenta");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Hola <font class = \"rojo\"> \"% 1 $ s '</ font>, el saldo de la cuenta es de% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Esquema de colores");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Por favor, introduzca un valor numérico válido para la bandera #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Banderas de la búsqueda / texto del anuncio");
//Keyword
define("SOFTBIZ_LC00002_ADS","Palabra clave");
//Search in
define("SOFTBIZ_LC00003_ADS","Busca en");
//Banner #
define("SOFTBIZ_LC00004_ADS","la bandera #");
//All
define("SOFTBIZ_LC00005_ADS","Todas");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","A la espera de la aprobación");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Todos los tamaños");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Tipo de anuncio");
//All Packages
define("SOFTBIZ_LC00009_ADS","todos los paquetes");
//Sort by
define("SOFTBIZ_LC00010_ADS","Ordenar por");
//Date Added
define("SOFTBIZ_LC00011_ADS","Fecha Agregada");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","impresiones compradas");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Fecha de caducidad");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","impresiones recibidas");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","clics recibidos");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","impresiones izquierda");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","clics izquierda");
//Days Left
define("SOFTBIZ_LC00018_ADS","izquierda días");
//Order
define("SOFTBIZ_LC00019_ADS","Orden");
//Ascending
define("SOFTBIZ_LC00020_ADS","ascendente");
//Descending
define("SOFTBIZ_LC00021_ADS","descendente");
//Search
define("SOFTBIZ_LC00022_ADS","Buscar");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Clic por calificaciones");
//Status
define("SOFTBIZ_LC00024_ADS","Estado");
//Note
define("SOFTBIZ_LC00025_ADS","Nota");
//Buy More
define("SOFTBIZ_LC00026_ADS","Comprar más");
//Edit
define("SOFTBIZ_LC00027_ADS","Editar");
//Stats
define("SOFTBIZ_LC00028_ADS","Estadísticas");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","Sin anuncios que cumplan los criterios especificados.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Resultados de búsqueda de anuncios para% s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","Resultados de búsqueda para ad ad #% s");
//Banner
define("SOFTBIZ_LC00032_ADS","Bandera");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Escribe texto del anuncio");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","clics compradas");
//Expired
define("SOFTBIZ_LC00035_ADS","Muerto");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","La página% s de% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Editar información de la bandera");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","URL de destino no se requiere para el tipo banner en flash. Dirección de destino debe incluir http: // www. p.ej. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","Estadística");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Tipo");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","Publicado en");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Por favor proporcione su ID de correo electrónico para recuperar su contraseña!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Su contraseña ha sido enviada por correo electrónico");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","El correo electrónico ha sido deshabilitado por el administrador, no puede enviar la contraseña.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","No se encontró con miembros tales ID de correo electrónico!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Tu perfil ha sido actualizado");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Añadir Proceso de dinero");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","Ha cancelado su solicitud de dinero Agregar a paypal.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Nuevo anuncio de texto colocado: Clics");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Nuevo anuncio de texto colocado: Impresiones");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Nuevo anuncio de texto colocado: Meses");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","texto extendido de anuncios: Los clics");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","texto extendido anuncio: Impresiones");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","texto extendido de anuncios: Meses");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Nuevo Banner aviso colocado: Clics");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Nuevo Banner aviso colocado: Impresiones");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Nuevo Banner aviso colocado: Meses");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","bandera extendida de anuncios: Los clics");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","bandera extendida anuncio: Impresiones");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","bandera extendida anuncio: Meses");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","El dinero añadido a través de 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","El dinero añadido a través de paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","para ir al anunciante casa.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","añadir nuevo anuncio.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","para administrar sus anuncios.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","para agregar dinero a la cuenta.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","para ver las transacciones de cuenta.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","cerrar la sesión");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Tenga en cuenta si el texto no se ajusta a las pautas editoriales a continuación, su anuncio se puede suspender");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","El título no debe contener más de 25 caracteres.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Por favor especificar una description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 no debe contener más de 35 caracteres.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Descripción2 no debe contener más de 35 caracteres.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","Información del paquete");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Añadir contenido");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Destino dirección del sitio web debe incluye http: // www <br> por ejemplo.. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","El pago se han añadido a su cuenta");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Acceso no válido, negado");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Su Agregar solicitud de dinero ha sido aceptada. Los fondos serán muy pronto aparecerá en su cuenta.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Estado de carga de archivos de imagen");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","Image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","TERMINAR");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Sólo .jpg / png / gif / bmp / ​​.jpeg / .swf se permiten formatos de archivo. <br> Por favor, cierre esta ventana y vuelva a intentarlo");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Archivos cargados deben ser inferior a SKB%. Por favor, cierre esta ventana y vuelva a intentarlo");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Éxito: El archivo ha sido subido");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Error: Tamaño del archivo más de 512000 bytes");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Error: Archivo parcialmente cargado");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Error: No se archivo subido");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","El archivo no se pudo cargar probablemente debido a restricciones de permisos en el directorio de destino");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Error: Archivo no se han subido. Comprobar el tamaño y del intento otra vez.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Regresa");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Todos los derechos reservados.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Mensaje");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","para");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Publicar nuevo anuncio");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","Mi impresión Anuncios");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Haga clic en Anuncios basados");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","Anuncios de duración limitada");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Golpear el botón [Examinar] para buscar el archivo en su ordenador y haga clic en el botón [Insert] para subirlo.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Imagen");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Subir");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Espere, no recibirá ninguna notificación hasta que el archivo se transfiere completamente.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Esta función se ha desactivado en la demo.");

?>