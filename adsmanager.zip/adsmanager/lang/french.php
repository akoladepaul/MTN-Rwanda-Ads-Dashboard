<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","S'il vous plaît indiquer un titre!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Titre ci-dessus 25 caractères ne sont pas permis!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","S'il vous plaît spécifier un description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 supérieure à 35 caractères ne sont pas permis!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","S'il vous plaît spécifier un description2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Description2 supérieure à 35 caractères ne sont pas permis!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","S'il vous plaît spécifier l'affichage url!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","S'il vous plaît spécifier l'URL de destination!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","S'il vous plaît télécharger une image de la bannière.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Modifier le texte des annonces Informations");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Titre");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","Ligne éditoriale");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Titre ne devrait pas être plus de 25 caractères.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","Description de 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","Description de ne devrait pas être plus de 35 caractères.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","Description de 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","Affichage Url");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Affichage url ne devrait pas être plus de 35 caractères.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","Destination Url");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","L'adresse de destination devrait inclure http: // www. par exemple. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Mettre à jour");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Votre bannière ne sera pas affiché jusqu'à ce que l'administrateur approuve les modifications.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","Invalid Id, incapable de continuer");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","L'accès non autorisé, incapable de continuer");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","S'il vous plaît indiquer l'adresse e-mail valide");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","Adresse e-mail semble incorrecte (chèque @ et de.)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","Le nom d'utilisateur ne semble pas être valide.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","Adresse IP de destination est invalide!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","Le nom de domaine ne semble pas être valide.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","L'adresse doit se terminer dans un domaine valide, ou deux lettres du pays.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","Cette adresse est manquant un nom d'hôte!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Télécharger le fichier d'image");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","S'il vous plaît choisir un fichier à télécharger");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","S'il vous plaît télécharger des .gif / .jpg / .jpeg / bmp / ​​.png fichiers uniquement");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","S'il vous plaît télécharger les fichiers .swf seulement");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Télécharger image");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Pour ajouter une image, cliquez sur le bouton \"Parcourir\" et sélectionnez le fichier, ou tapez le chemin du fichier dans la boîte de texte ci-dessous.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Ensuite, cliquez sur Télécharger pour terminer le processus.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","REMARQUE");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","Le transfert de fichiers peut prendre de quelques secondes à quelques minutes en fonction de la taille du fichier. S'il vous plaît avoir la patience pendant que le fichier est téléchargé.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","Le fichier sera renommé si le fichier avec le même nom est déjà présent");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Appuyez sur le bouton [Parcourir] pour trouver le fichier sur votre ordinateur.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","image");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Télécharger");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Choisir des dates");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","De");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","journée");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Mois");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","An");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","À");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Rapports par Page");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","Montrer");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Ajouter de l'argent");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Montant");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","date");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","La description");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","Transactions");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","Aucune transaction trouvée corresponde à vos critères.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Votre solde actuel est% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Page% 1 $ s de% 2 $ de la <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Achat paquet");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Type d'emballage: Impressions Based");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Nom du paquet");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","Impressions");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Prix");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Prix ​​/ Impression");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Taille");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Type d'emballage: Cliquez Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","Clics");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Prix ​​/ Cliquez");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Type d'emballage: Temps Based");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Durée");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Prix ​​/ Mois");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","Continuer");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","Il n'y a pas de paquets d'achat définies par l'administrateur.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","Mois");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Accès invalide, incapable de continuer");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","Bannière de publicité");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","Ad texte");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Votre% 1 $ s a été crédité les demandées% 2 $ s.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Une erreur survenue, s'il vous plaît essayer à nouveau");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","L'accès non autorisé, refusé");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","ad texte a été ajouté avec succès. Votre annonce texte apparaîtra dans notre rotateur bannière dès qu'il sera approuvé.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","ad texte a été ajouté avec succès.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Votre demande texte d'annonce complémentaire n'a pas été traité en raison du manque de fonds. Ajouter un peu d'argent à votre compte et essayez à nouveau");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Une erreur est survenue, s'il vous plaît essayer à nouveau");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Vos changements ont été envoyés pour approbation admin");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","accès Inavlid, incapable de continuer");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","Impossible de mettre à jour les détails de la bannière, s'il vous plaît essayer à nouveau");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","S'il vous plaît choisir le type de bannière correcte");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Ajouter une nouvelle bannière");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","Type d'emballage");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","Bannière Taille");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Type de bannière");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Image (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","URL de destination");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","Destination Url pas nécessaire pour le type flash bannière. adresse du site Web de destination devrait inclut http: // www. par exemple. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","banner image");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Retirer");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Impression");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Cliquez");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","Vous devez être connecté pour accéder à cette page!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Aide pour l'affichage texte d'annonce");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Consignes de rédaction");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","S'il vous plaît entrer les informations de connexion!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Bienvenue% s, vous avez connecté avec succès.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","S'il vous plaît entrer les informations de connexion correctes!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Acheter Plus Impressions");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Acheter maintenant");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Ce processus est irréversible, l'argent une fois payé ne peut pas être remboursé.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","Il n'y a pas de paquet disponible pour cette taille de la bannière.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","Il n'y a pas de paquet disponible pour cette annonce textuelle.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","Impressions Sur la base");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Cliquez Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","Time Based");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Bannière non trouvé. Cliquez");
//here
define("SOFTBIZ_LC00009_BUY_MORE","ici");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","continuer");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Contenu de l'annonce");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Ajouter");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Annuler");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","REMARQUE:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Arrière");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Désolé, annonceur avec l'email% s existe déjà.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","Vous Registerd avec succès avec nous");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Certaines erreurs sont survenues. Veuillez réessayer!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","Payer");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Montant à ajouter");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Solde actuel");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Solde Après addition");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Ajouter de l'argent pour tenir compte");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Ajout argent sur votre compte");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Continuer à Paypal Paiement");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Continuer à 2Checkout Paiement");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Termes et conditions");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","Hors ligne");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","Grâce à Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","Grâce à 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","Le mot de passe a été changé!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","Mot de passe n'a pas pu être mis à jour parce que votre ancien mot de passe est incorrect");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","S'il vous plaît spécifier un zéro non valeur numérique positive!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Ajouter à mon compte");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Mode de paiement");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Pay Offline");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","ajouter du texte ad");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","ajouter bannière");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","acheter plus la durée");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","acheter plus de clics");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","acheter plus d'impressions");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","la demande de Votre% n'a pas été traité en raison du manque de fonds. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Vous avez besoin d'au moins% s pour forfait choisi. <br> Ajouter un peu d'argent à votre compte ou choisir un autre paquet");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","S'il vous plaît entrez mot de passe actuel");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Changer le mot de passe");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","Mot de passe actuel");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","nouveau mot de passe");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Retaper le mot de passe");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Mise à jour Mot de passe");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Nouveau mot de passe doit être des personnages de atleast% à long");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","S'il vous plaît entrer Nouveau mot de passe");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","mot de passe retapé doesnot correspondre au nouveau mot de passe");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","doit être atleast% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","personnage");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","personnages");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Votre bannière a été mis à jour");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Aggregate Statistiques Bannière pour toutes vos bannières");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Nombre total de Bannières Publié");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","A approuvé");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","Refusée");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Nombre total d'impressions reçues");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Nombre total de clics reçus");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Taux de clics moyen");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Dernières Impression");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Dernières Cliquez");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","La plupart affichés Banner / Ad texte");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","Les plus cliqués Bannière / texte");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Stats: Clics / Impressions");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Aujourd'hui");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Hier");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Les 7 derniers jours");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Les 14 derniers jours");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","L'année dernière");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","Cette Année: Clics / Impressions");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","Ce mois-ci: Clics / Impressions");
//January
define("SOFTBIZ_LC00019_AD_HOME","janvier");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Febuary");
//March
define("SOFTBIZ_LC00021_AD_HOME","Mars");
//April
define("SOFTBIZ_LC00022_AD_HOME","avril");
//May
define("SOFTBIZ_LC00023_AD_HOME","Mai");
//June
define("SOFTBIZ_LC00024_AD_HOME","juin");
//July
define("SOFTBIZ_LC00025_AD_HOME","juillet");
//August
define("SOFTBIZ_LC00026_AD_HOME","août");
//September
define("SOFTBIZ_LC00027_AD_HOME","septembre");
//October
define("SOFTBIZ_LC00028_AD_HOME","octobre");
//November
define("SOFTBIZ_LC00029_AD_HOME","novembre");
//December
define("SOFTBIZ_LC00030_AD_HOME","décembre");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Banner a été ajouté avec succès. Votre bannière apparaîtra dans notre rotateur bannière dès qu'il sera approuvé.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Banner a été ajouté avec succès.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","Votre demande add bannière n'a pas été traité en raison du manque de fonds. Ajouter un peu d'argent à votre compte et essayez à nouveau");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Types d'annonces");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Choisissez Type d'annonce");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Adresse e-mail invalide.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","S'il vous plaît indiquer le code de validation");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Mot de passe oublié");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","S'il vous plaît fournir votre email id. Nous vous enverrons votre mot de passe par courrier électronique.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","Email ID");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Code de validation");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Envoyer une demande");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","Le nom d'utilisateur dans l'adresse e-mail semble invalide");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","Destination IP dans l'adresse e-mail est invalide");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","Le nom de domaine dans l'adresse e-mail semble invalide");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","L'adresse de courriel doit se terminer dans un domaine valide ou deux lettres du pays");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","Adresse e-mail manque un nom d'hôte");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Spécifiez le texte affiché dans l'image du code de validation ci-dessus. Ce texte est le cas dans le sensible.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","code de validation spécifié était incorrect");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","S'il vous plaît entrez votre nom!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","S'il vous plaît Entrez votre adresse!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","S'il vous plaît Entrez votre ville!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","S'il vous plaît Entrez votre état!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","S'il vous plaît Choisir un pays!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","S'il vous plaît Entrez votre URL de site web!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Veuillez entrer le mot de passe.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Les mots de passe ne correspondent pas.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Nouveau Annonceur: Inscription en remplissant le formulaire ci-dessous");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","votre nom");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Votre adresse");
//City
define("SOFTBIZ_LC00011_SITEHOME","Ville");
//State
define("SOFTBIZ_LC00012_SITEHOME","Etat");
//Country
define("SOFTBIZ_LC00013_SITEHOME","Pays");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Choisissez un pays");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","URL de site web");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Votre Email");
//Password
define("SOFTBIZ_LC00017_SITEHOME","Mot de passe");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","Confirmez le mot de passe");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","Soumettre");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","S'il vous plaît indiquer votre adresse e-mail.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","S'il vous plaît indiquer le mot de passe.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Les annonceurs existants: Connectez-vous ici");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Se connecter");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","Mot de passe doit être des personnages de atleast% de long.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","Annonceur Menu");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Accueil");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Modifier le profil");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Se déconnecter");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","Mes annonces");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Ajouter une nouvelle annonce");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","gerer annonces");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Toutes les annonces textuelles");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","Toutes les bannières");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Mon compte");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Salut <font class = 'red'> </ font> '% 1 $ s', solde de votre compte est% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Schéma de couleur");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","S'il vous plaît Entrez une valeur numérique valide pour Bannière #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Recherche Bannières / Ad texte");
//Keyword
define("SOFTBIZ_LC00002_ADS","Mot-clé");
//Search in
define("SOFTBIZ_LC00003_ADS","Rechercher dans");
//Banner #
define("SOFTBIZ_LC00004_ADS","Bannière #");
//All
define("SOFTBIZ_LC00005_ADS","Tout");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","En attente d'approbation");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Toutes les tailles");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Type d'annonce");
//All Packages
define("SOFTBIZ_LC00009_ADS","Tous les forfaits");
//Sort by
define("SOFTBIZ_LC00010_ADS","Trier par");
//Date Added
define("SOFTBIZ_LC00011_ADS","date ajoutée");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","Impressions Achats");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Date d'expiration");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","Impressions reçus");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","Clics reçus");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","Impressions gauche");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","Clics gauche");
//Days Left
define("SOFTBIZ_LC00018_ADS","Jours restants");
//Order
define("SOFTBIZ_LC00019_ADS","Commande");
//Ascending
define("SOFTBIZ_LC00020_ADS","Ascendant");
//Descending
define("SOFTBIZ_LC00021_ADS","Descendant");
//Search
define("SOFTBIZ_LC00022_ADS","Chercher");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Taux de clics");
//Status
define("SOFTBIZ_LC00024_ADS","statut");
//Note
define("SOFTBIZ_LC00025_ADS","Remarque");
//Buy More
define("SOFTBIZ_LC00026_ADS","Acheter plus");
//Edit
define("SOFTBIZ_LC00027_ADS","modifier");
//Stats
define("SOFTBIZ_LC00028_ADS","Statistiques");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","Aucune annonce satisfait aux critères spécifiés.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Résultats de la recherche d'annonce pour% s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","Résultats de la recherche pour Ad Ad #% s");
//Banner
define("SOFTBIZ_LC00032_ADS","Bannière");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Texte Type d'annonce");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","Clics Achats");
//Expired
define("SOFTBIZ_LC00035_ADS","Expiré");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","Page% s de% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Modifier Bannière d'information");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","Destination Url pas nécessaire pour le type flash bannière. L'adresse de destination devrait inclure http: // www. par exemple. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","Statistiques");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Type");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","Posté sur");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","S'il vous plaît fournir votre email id pour récupérer votre mot de passe!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Votre mot de passe a été envoyé par courriel");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","Email a été désactivé par admin, incapable d'envoyer votre mot de passe.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","Aucun membre trouvé avec cette id e-mail!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Votre profil a été mis à jour");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Ajouter Processus d'argent");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","Vous avez annulé votre argent Demande Ajouter à paypal.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Nouvelle annonce texte affiché: Clics");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Nouvelle annonce texte affiché: Impressions");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Nouvelle annonce texte affiché: Mois");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","Extended ad texte: Clics");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","Extended ad texte: Impressions");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","Extended ad texte: Mois");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Nouvelle Bannière annonce affichée: Clics");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Nouvelle Bannière annonce affichée: Impressions");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Nouvelle Bannière annonce affichée: Mois");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","bannière Extended ad: Clicks");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","banner ad Extended: Impressions");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","banner ad Extended: Mois");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","L'argent ajouté par 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","L'argent ajouté par paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","pour aller à l'annonceur maison.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","pour ajouter une nouvelle publicité.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","pour gérer vos annonces.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","à ajouter de l'argent sur le compte.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","pour afficher les transactions du compte.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","dconnecter");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","S'il vous plaît être conscient si votre texte d'annonce ne se conforme pas aux directives éditoriales alors votre annonce pourrait être suspendu");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Titre ne devrait pas être plus de 25 caractères.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","S'il vous plaît spécifier un description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 ne devrait pas être plus de 35 caractères.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Description2 ne devrait pas être plus de 35 caractères.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","Trousse d'information");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Ajouter Sommaire");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","adresse du site Web de destination devrait inclut http: // www par exemple. <br>. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Le paiement a été ajouté à votre compte");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Accès non valide, refusé");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Votre demande d'argent Ajouter a été acceptée. Les fonds seront très bientôt apparaître dans votre compte.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Statut Upload Image File");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","TERMINER");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Seulement .jpg / .png / .gif / bmp / ​​.jpeg / .swf formats de fichiers sont autorisés. <br> S'il vous plaît fermer cette fenêtre et essayez à nouveau");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Les fichiers téléchargés doivent être inférieures à% SKB. S'il vous plaît fermer cette fenêtre et essayez à nouveau");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Succès: Le fichier a été téléchargé");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Erreur: la taille du fichier plus de 512000 octets");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Erreur: fichier partiellement téléchargé");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Erreur: Aucun fichier Téléchargé");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","Le fichier ne peut être téléchargé sans doute en raison des restrictions d'autorisation sur le répertoire de destination");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Erreur: Fichier non Téléchargé. Vérifiez Taille & Try Again.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Retourner");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Tous les droits sont réservés.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Message");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","pour");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Post New Ad");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","Mon impression annonces");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Cliquez Based annonces");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","Temps lié annonces");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Appuyez sur le bouton [Parcourir] pour trouver le fichier sur votre ordinateur, puis cliquez sur le bouton [Insérer] pour le télécharger.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","image");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Télécharger");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","S'il vous plaît avoir la patience, vous ne recevrez aucune notification jusqu'à ce que le fichier soit complètement transféré.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Cette fonctionnalité a été désactivée dans la démo.");

?>