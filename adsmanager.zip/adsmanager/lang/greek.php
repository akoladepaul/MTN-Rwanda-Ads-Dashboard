<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Παρακαλείστε να προσδιορίσετε έναν τίτλο!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Τίτλος άνω των 25 χαρακτήρων δεν επιτρέπεται!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Παρακαλείστε να προσδιορίσετε μια description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 πάνω από 35 χαρακτήρα δεν επιτρέπεται!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Παρακαλείστε να προσδιορίσετε μια περιγραφή2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Περιγραφή2 πάνω από 35 χαρακτήρα δεν επιτρέπεται!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Παρακαλείστε να προσδιορίσετε τη διεύθυνση URL εμφάνισης!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Παρακαλείστε να προσδιορίσετε τη διεύθυνση URL προορισμού!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Παρακαλούμε να ανεβάσετε μια εικόνα banner.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Επεξεργασία πληροφοριών κειμένου διαφήμισης");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Τίτλος");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","Οδηγίες Σύνταξης");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Ο τίτλος δεν πρέπει να είναι πάνω από 25 χαρακτήρες.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","περιγραφή 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","Περιγραφή δεν πρέπει να είναι πάνω από 35 χαρακτήρες.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","περιγραφή 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","Διεύθυνση URL εμφάνισης");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Εμφάνιση url δεν πρέπει να είναι πάνω από 35 χαρακτήρες.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","Διεύθυνση URL προορισμού");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","Διεύθυνση προορισμού θα πρέπει να περιλαμβάνει το http: // www. πχ. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Εκσυγχρονίζω");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Banner σας δεν θα εμφανιστεί μέχρι Διαχειριστής εγκρίνει τις αλλαγές.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","Μη έγκυρη ταυτότητα, αδυνατεί να συνεχίσει");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","Η μη εξουσιοδοτημένη πρόσβαση, δεν μπορεί να συνεχίσει");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Παρακαλείστε να προσδιορίσετε έγκυρη διεύθυνση ηλεκτρονικού ταχυδρομείου");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","διεύθυνση ηλεκτρονικού ταχυδρομείου φαίνεται λανθασμένη (@ ελέγχου και. του)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","Το όνομα χρήστη δεν φαίνεται να ισχύει.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","διεύθυνση προορισμού IP δεν είναι έγκυρη!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","Το όνομα τομέα δεν φαίνεται να είναι έγκυρη.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","Η διεύθυνση πρέπει να τελειώνει με έναν έγκυρο τομέα, ή δύο χώρες γράμμα.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","Αυτή η διεύθυνση λείπει ένα όνομα!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Μεταφόρτωση αρχείου Εικόνα");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Παρακαλώ επιλέξτε ένα αρχείο για να φορτώσετε");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Παρακαλώ ανεβάστε .gif / .jpg / .jpeg / .bmp / ​​.png αρχεία μόνο");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Παρακαλώ ανεβάστε .swf αρχεία μόνο");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Ανέβασμα εικόνας");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Για να προσθέσετε μια εικόνα, κάντε κλικ στο κουμπί \"Αναζήτηση\" και επιλέξτε το αρχείο ή πληκτρολογήστε τη διαδρομή προς το αρχείο στο κείμενο-πλαίσιο που ακολουθεί.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Στη συνέχεια, κάντε κλικ στο κουμπί Αποστολή για να ολοκληρώσετε τη διαδικασία.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","ΣΗΜΕΊΩΣΗ");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","Η μεταφορά αρχείων μπορεί να διαρκέσει από λίγα δευτερόλεπτα έως μερικά λεπτά ανάλογα με το μέγεθος του αρχείου. Παρακαλούμε να έχετε υπομονή, ενώ το αρχείο που φορτώθηκε.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","Το αρχείο θα μετονομαστεί αν το αρχείο με το ίδιο όνομα υπάρχει ήδη");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Πατήστε το κουμπί [Αναζήτηση] για να βρείτε το αρχείο στον υπολογιστή σας.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Εικόνα");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Μεταφόρτωση");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Επιλέξτε Ημερομηνίες");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","Από");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","Ημέρα");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Μήνας");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Έτος");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","Να");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Εγγραφές ανά σελίδα");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","προβολή");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Προσθέστε χρήματα");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Ποσό");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Ημερομηνία");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Περιγραφή");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","συναλλαγές");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","Καμία συναλλαγή βρέθηκαν να ικανοποιούν τα κριτήριά σας.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Το τρέχον υπόλοιπό σας είναι% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Σελίδα% 1 $ s% 2 $ s <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Πακέτο αγορά");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Τύπος συσκευασίας: Εντυπώσεις Βασισμένο");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Όνομα πακέτου");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","εντυπώσεις");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Τιμή");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Τιμή / εμφανίσεων");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Μέγεθος");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Τύπος συσκευασίας: Κάντε κλικ Βασισμένο");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","κλικ");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Τιμή / Κλικ");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Τύπος συσκευασίας: Ώρα Βασισμένο");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Διάρκεια");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Τιμή / Μήνα");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","Να συνεχίσει");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","Δεν υπάρχουν πακέτα αγορά ορίζεται από το διαχειριστή.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","μήνες");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Μη έγκυρη πρόσβαση, δεν μπορεί να συνεχίσει");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","banner διαφήμιση");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","Διαφημιστικό κείμενο");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Σας% 1 $ s έχει πιστωθεί τα ζητούμενα% 2 $ s.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Μερικά σφάλμα, δοκιμάστε ξανά");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","Η μη εξουσιοδοτημένη πρόσβαση, αρνήθηκε");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","το διαφημιστικό κείμενο έχει προστεθεί με επιτυχία. Διαφήμιση κειμένου σας θα εμφανιστεί στο banner rotator μας το συντομότερο θα εγκριθεί.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","το διαφημιστικό κείμενο έχει προστεθεί με επιτυχία.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Ανάθεση κείμενο διαφήμισης σας δεν έχει υποβληθεί σε επεξεργασία, λόγω της έλλειψης κονδυλίων. Προσθέστε κάποια χρήματα στο λογαριασμό σας και προσπαθήστε ξανά");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Κάποιο λάθος συνέβη, δοκιμάστε ξανά");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Οι αλλαγές σας έχουν αποσταλεί για έγκριση διαχειριστή");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","Μη έγκυρη πρόσβαση, δεν μπορεί να συνεχίσει");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","Ανίκανος να ενημερώσετε τα στοιχεία πανό, δοκιμάστε ξανά");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Παρακαλώ επιλέξτε το σωστό τύπο banner");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Προσθέστε Νέα Διαφήμιση");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","πακέτο Τύπος");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","Διαφήμιση Μέγεθος");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Διαφήμιση Τύπος");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Εικόνας (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","Η διεύθυνση URL προορισμού");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","Διεύθυνση URL προορισμού δεν απαιτείται για τον τύπο flash banner. Προορισμός διεύθυνση της ιστοσελίδας θα πρέπει να περιλαμβάνει http: // www. πχ. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","Διαφήμιση εικόνας");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Αφαιρώ");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Εντύπωση");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Κλίκ");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","Θα πρέπει να συνδεθείτε για να αποκτήσετε πρόσβαση σε αυτήν τη σελίδα!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Βοήθεια για Κείμενο απόσπαση διαφήμισης");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Οδηγίες Σύνταξης");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Παρακαλώ εισάγετε τα στοιχεία σύνδεσης!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Καλώς% s, έχετε συνδεθεί-in με επιτυχία.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Παρακαλούμε, εισάγετε σωστά στοιχεία σύνδεσης!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Αγοράστε περισσότερες εμφανίσεις");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Αγορασε τωρα");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Αυτή η διαδικασία είναι μη αναστρέψιμη, τα χρήματα τη στιγμή που καταβάλλονται δεν μπορεί να επιστραφεί.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","Δεν υπάρχει διαθέσιμη για αυτό το μέγεθος banner πακέτο.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","Δεν υπάρχει διαθέσιμη για αυτήν τη διαφήμιση κειμένου πακέτο.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","εντυπώσεις βάση");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Κάντε κλικ Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","Ώρα Βασισμένο");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Διαφήμιση δεν βρέθηκε. Κλίκ");
//here
define("SOFTBIZ_LC00009_BUY_MORE","εδώ");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","να συνεχίσει");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Περιεχόμενα ad");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Προσθέτω");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Ματαίωση");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","ΣΗΜΕΊΩΣΗ:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Πίσω");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Λυπούμαστε, αλλά διαφημιζόμενος με το email% s υπάρχει ήδη.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","Είστε γράφτηκε με επιτυχία μαζί μας");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Μερικά Σφάλμα μεσολαβήσει. ΠΑΡΑΚΑΛΩ προσπαθησε ξανα!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","Πληρωμή");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Ποσό που πρέπει να προστεθεί");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Τωρινή ισσοροπία");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Υπόλοιπο μετά την προσθήκη");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Προσθέσετε χρήματα στο λογαριασμό");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Προστέθηκε χρήματα στο λογαριασμό σας");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Συνεχίστε να Paypal Πληρωμής");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Συνεχίστε να 2Checkout Πληρωμής");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Όροι και Προϋποθέσεις");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","offline");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","μέσω Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","μέσω 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","Κωδικός πρόσβασης έχει αλλάξει!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","Ο κωδικός πρόσβασης δεν μπορεί να ενημερωθεί επειδή τον παλιό κωδικό πρόσβασής σας ήταν λανθασμένη");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Παρακαλείστε να προσδιορίσετε μια μη μηδενική θετική αριθμητική τιμή!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Προσθέτω στο λογαριασμό μου");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Μέθοδος πληρωμής");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Pay Αποσυνδεδεμένος");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","προσθέσετε κείμενο διαφήμισης");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","προσθέσετε banner");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","αγοράσουν περισσότερα διάρκειας");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","αγοράσουν περισσότερα κλικ");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","αγοράζουν περισσότερες εμφανίσεις");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","αίτημα σας% s δεν έχει υποβληθεί σε επεξεργασία, λόγω της έλλειψης κονδυλίων. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Χρειάζεστε τουλάχιστον% s για τις επιλεγμένες πακέτο. <br> Προσθέστε κάποια χρήματα στο λογαριασμό σας ή να επιλέξετε κάποιο άλλο πακέτο");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Παρακαλούμε, εισάγετε Current Password");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Άλλαξε κωδικό");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","τρέχων κωδικός πρόσβασης");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","Νέος Κωδικός");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Πληκτρολογήστε ξανά τον κωδικό πρόσβασης");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Ενημέρωση κωδικού");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Νέα κωδικός πρόσβασης πρέπει να είναι μακρά Atleast% s χαρακτήρες");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Παρακαλούμε, εισάγετε New Password");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","Retyped κωδικό doesnot ταιριάζει με το νέο κωδικό πρόσβασης");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","πρέπει να είναι τουλάχιστον% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","χαρακτήρας");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","χαρακτήρες");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","banner σας έχει ενημερωθεί");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Συγκεντρωτικά Στατιστικά Διαφήμιση για όλους Banners σας");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Συνολικός αριθμός των πανό Δημοσιεύτηκε");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","Εγκεκριμένη");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","Απορρίφθηκε");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Συνολικές εμφανίσεις Ελήφθη");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Συνολικά κλικ Ελήφθη");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Μέσος όρος Κάντε κλικ Μέσω Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Τελευταία εντύπωση");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Τελευταία Κάντε κλικ");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","Οι περισσότεροι Εμφανίζεται Διαφήμιση / Διαφήμιση με κείμενο");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","Οι περισσότερες αγγελίες / Κείμενο κλικ στο Banner");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Στατιστικά: Κλικ / εμφανίσεις");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Σήμερα");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Εχθές");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Τελευταίες 7 Ημέρες");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Τελευταίες 14 Ημέρες");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","Πέρυσι");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","Αυτό Έτος: Κλικ / εμφανίσεις");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","Αυτό το μήνα: Κλικ / εμφανίσεις");
//January
define("SOFTBIZ_LC00019_AD_HOME","Ιανουάριος");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Φεβρουάριος");
//March
define("SOFTBIZ_LC00021_AD_HOME","Μάρτιος");
//April
define("SOFTBIZ_LC00022_AD_HOME","Απρίλιος");
//May
define("SOFTBIZ_LC00023_AD_HOME","Μάιος");
//June
define("SOFTBIZ_LC00024_AD_HOME","Ιούνιος");
//July
define("SOFTBIZ_LC00025_AD_HOME","Ιούλιος");
//August
define("SOFTBIZ_LC00026_AD_HOME","Αύγουστος");
//September
define("SOFTBIZ_LC00027_AD_HOME","Σεπτέμβριος");
//October
define("SOFTBIZ_LC00028_AD_HOME","Οκτώβριος");
//November
define("SOFTBIZ_LC00029_AD_HOME","Νοέμβριος");
//December
define("SOFTBIZ_LC00030_AD_HOME","Δεκέμβριος");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Διαφήμιση έχει προστεθεί με επιτυχία. Banner σας θα εμφανιστεί στο banner rotator μας το συντομότερο θα εγκριθεί.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Διαφήμιση έχει προστεθεί με επιτυχία.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","το αίτημα προσθήκης banner σας δεν έχει υποβληθεί σε επεξεργασία, λόγω της έλλειψης κονδυλίων. Προσθέστε κάποια χρήματα στο λογαριασμό σας και προσπαθήστε ξανά");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Τύποι διαφήμισης");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Επιλέξτε Τύπος διαφήμισης");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Μη έγκυρη διεύθυνση e-mail.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Παρακαλείστε να προσδιορίσετε τον κωδικό επικύρωσης");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Ξεχάσατε τον κωδικό");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Παρακαλείσθε να δώσετε ταυτότητα ηλεκτρονικού ταχυδρομείου σας. Θα στείλουμε τον κωδικό πρόσβασής σας στο e-mail.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","Ταυτότητα ηλεκτρονικού ταχυδρομείου");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Κωδικός επικύρωσης");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Στείλε αίτημα");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","Το όνομα χρήστη στη διεύθυνση ηλεκτρονικού ταχυδρομείου που φαίνεται άκυρο");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","IP προορισμού στην διεύθυνση ηλεκτρονικού ταχυδρομείου δεν είναι έγκυρη");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","Το όνομα τομέα στη διεύθυνση ηλεκτρονικού ταχυδρομείου που φαίνεται άκυρο");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","Η διεύθυνση ηλεκτρονικού ταχυδρομείου πρέπει να καταλήξει σε ένα έγκυρο τομέα ή δύο χώρες-mail");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","διεύθυνση ηλεκτρονικού ταχυδρομείου λείπει ένα όνομα κεντρικού υπολογιστή");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Καθορίστε το κείμενο που εμφανίζεται στην παραπάνω κωδικό επικύρωσης εικόνα. Αυτό το κείμενο είναι περίπτωση ευαίσθητη.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","Καθορισμένη κωδικό επικύρωσης ήταν λανθασμένη");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","Παρακαλώ εισάγετε το όνομά σας!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Παρακαλώ εισάγετε σας!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Παρακαλώ εισάγετε πόλη σας!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Παρακαλούμε, εισάγετε μέλος σας!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Επιλέξτε μια Χώρα!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Παρακαλώ εισάγετε διεύθυνση της ιστοσελίδας σας!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Παρακαλώ εισάγετε τον κωδικό.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Οι κωδικοί πρόσβασης δεν ταιριάζουν.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Νέα Διαφημιστής: Εγγραφή συμπληρώνοντας παρακάτω φόρμα");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Το όνομα σου");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Η διεύθυνση σου");
//City
define("SOFTBIZ_LC00011_SITEHOME","Πόλη");
//State
define("SOFTBIZ_LC00012_SITEHOME","Κατάσταση");
//Country
define("SOFTBIZ_LC00013_SITEHOME","Χώρα");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Επιλέξτε μια χώρα");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","Διεύθυνση Ιστοσελίδας");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Η διεύθυνση του ηλεκτρονικού σου ταχυδρομείου");
//Password
define("SOFTBIZ_LC00017_SITEHOME","Σύνθημα");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","Επιβεβαίωση κωδικού");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","Υποτάσσομαι");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Παρακαλείστε να προσδιορίσετε τη διεύθυνση ηλεκτρονικού ταχυδρομείου σας.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Παρακαλείστε να προσδιορίσετε τον κωδικό πρόσβασης.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Υφιστάμενες Διαφημιστές: Είσοδος μέλους");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Συνδεθείτε");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","Ο κωδικός πρόσβασης πρέπει να είναι τουλάχιστον% s χαρακτήρες.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","Διαφημιστής Μενού");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Σπίτι");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Επεξεργασία προφίλ");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Αποσυνδέομαι");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","Οι αγγελίες μου");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Προσθήκη νέας διαφήμισης");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Διαχείριση διαφημίσεων");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Όλες οι διαφημίσεις κειμένου");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","Όλα τα Banners");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Ο λογαριασμός μου");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Γεια <class font = \"κόκκινο\"> \"% 1 $ s '</ font>, το υπόλοιπο του λογαριασμού σας είναι% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Συνδυασμός χρωμάτων");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Παρακαλώ εισάγετε μια έγκυρη αριθμητική τιμή για Banner #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Αναζήτηση Banners / Ad Κείμενο");
//Keyword
define("SOFTBIZ_LC00002_ADS","Λέξη-κλειδί");
//Search in
define("SOFTBIZ_LC00003_ADS","Αναζήτηση σε");
//Banner #
define("SOFTBIZ_LC00004_ADS","Πανό #");
//All
define("SOFTBIZ_LC00005_ADS","Όλοι");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","Αναμονή για έγκριση");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Όλα τα μεγέθη");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Τύπος διαφήμισης");
//All Packages
define("SOFTBIZ_LC00009_ADS","Όλα τα Πακέτα");
//Sort by
define("SOFTBIZ_LC00010_ADS","Ταξινόμηση κατά");
//Date Added
define("SOFTBIZ_LC00011_ADS","Ημερομηνία Προστέθηκε");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","εντυπώσεις Αγορά");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Ημερομηνία λήξης");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","εντυπώσεις Ελήφθη");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","κλικ Ελήφθη");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","εντυπώσεις αριστερά");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","κλικ αριστερά");
//Days Left
define("SOFTBIZ_LC00018_ADS","Μέρες που απομένουν");
//Order
define("SOFTBIZ_LC00019_ADS","Παραγγελία");
//Ascending
define("SOFTBIZ_LC00020_ADS","Αύξουσα");
//Descending
define("SOFTBIZ_LC00021_ADS","Φθίνων");
//Search
define("SOFTBIZ_LC00022_ADS","Έρευνα");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Κάντε κλικ μέσω του ποσοστού");
//Status
define("SOFTBIZ_LC00024_ADS","Κατάσταση");
//Note
define("SOFTBIZ_LC00025_ADS","Σημείωση");
//Buy More
define("SOFTBIZ_LC00026_ADS","Αγόρασε περισσότερα");
//Edit
define("SOFTBIZ_LC00027_ADS","Επεξεργασία");
//Stats
define("SOFTBIZ_LC00028_ADS","Στατιστικά");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","Δεν διαφήμισης πληρούν τα κριτήρια που ορίσατε.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Αποτελέσματα αναζήτησης διαφήμιση για% s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","Αποτελέσματα αναζήτησης διαφήμιση για τη διαφήμισή #% s");
//Banner
define("SOFTBIZ_LC00032_ADS","Πανό");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Κείμενο Τύπος διαφήμισης");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","κλικ Αγορά");
//Expired
define("SOFTBIZ_LC00035_ADS","έληξε");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","Σελίδα% s από% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Επεξεργασία Διαφήμιση Πληροφορίες");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","Διεύθυνση URL προορισμού δεν απαιτείται για τον τύπο flash banner. Διεύθυνση προορισμού θα πρέπει να περιλαμβάνει το http: // www. πχ. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","Στατιστική");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Τύπος");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","Δημοσιεύτηκε στις");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Παρακαλώ παρέχετε id email σας για να ανακτήσετε τον κωδικό πρόσβασής σας!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Ο κωδικός πρόσβασής σας έχει με e-mail");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","Email έχει απενεργοποιηθεί από το διαχειριστή, μπορείτε να στείλετε τον κωδικό πρόσβασής σας.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","Κανένα κράτος βρέθηκε με τέτοια ταυτότητα ηλεκτρονικού ταχυδρομείου!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Το προφίλ σου ενημερώθηκε");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Προσθέστε Διαδικασία Χρήματα");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","Έχετε ακυρώσει Ανάθεση χρήματα σας στο paypal.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Νέα διαφήμιση με κείμενο δημοσιεύτηκε: Κλικ");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Νέα διαφήμιση με κείμενο δημοσιεύτηκε: Εντυπώσεις");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Νέα διαφήμιση με κείμενο δημοσιεύτηκε: Μήνες");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","Επέκταση του διαφημιστικού κειμένου: Κλικ");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","Επέκταση του διαφημιστικού κειμένου: Εντυπώσεις");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","Επέκταση του διαφημιστικού κειμένου: Μήνες");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Νέα Banner διαφήμιση δημοσιεύτηκε: Κλικ");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Νέα Banner διαφήμιση δημοσιεύτηκε: Εντυπώσεις");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Νέα Banner διαφήμιση δημοσιεύτηκε: Μήνες");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","Εκτεταμένη διαφημιστικό banner: Κλικ");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","Εκτεταμένη διαφημιστικό banner: Εντυπώσεις");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","Εκτεταμένη διαφημιστικό banner: Μήνες");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","Χρήματα προστίθενται μέσω 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","Χρήματα προστεθεί μέσω paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","να πάει την αγγελία στο σπίτι.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","για να προσθέσετε νέα διαφήμιση.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","για να διαχειριστείτε τις διαφημίσεις σας.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","για να προσθέσετε χρήματα στο λογαριασμό.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","για να δείτε τις κινήσεις του λογαριασμού.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","να αποσυνδεθείτε");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Θα πρέπει να γνωρίζετε εάν το κείμενο της διαφήμισής σας δεν συμμορφώνεται με τις οδηγίες σύνταξης τότε η διαφήμισή σας θα μπορούσε να τεθεί σε αναστολή");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Ο τίτλος δεν πρέπει να είναι πάνω από 25 χαρακτήρες.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Παρακαλείστε να προσδιορίσετε μια description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 δεν πρέπει να είναι πάνω από 35 χαρακτήρες.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Περιγραφή2 δεν πρέπει να είναι πάνω από 35 χαρακτήρες.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","πακέτο πληροφοριών");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Προσθέστε Περιεχόμενα");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Προορισμός διεύθυνση της ιστοσελίδας θα πρέπει να περιλαμβάνει http: // www <br> π.χ... http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Πληρωμής έχουν προστεθεί στο λογαριασμό σας");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Μη έγκυρη πρόσβαση, αρνήθηκε");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Ανάθεση τα χρήματά σας έχει γίνει αποδεκτή. Ταμεία θα εμφανιστεί πολύ σύντομα στον λογαριασμό σας.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Κατάσταση μεταφόρτωσης αρχείου εικόνας");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","Image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","ΦΙΝΊΡΙΣΜΑ");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Μόνο .jpg / .png / .gif / .bmp / ​​.jpeg / .swf επιτρέπονται μορφές αρχείων. <br> Παρακαλώ κλείστε αυτό το παράθυρο και προσπαθήστε ξανά");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Uploaded αρχεία πρέπει να είναι μικρότερη% SKB. Κλείστε αυτό το παράθυρο και προσπαθήστε ξανά");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Επιτυχία: Αρχείο έχει φορτωθεί");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Σφάλμα: Μέγεθος αρχείου πάνω από 512.000 bytes");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Error: File μερικώς ανεβάσει");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Σφάλμα: Δεν Αρχείο Ανέβηκε");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","Το αρχείο δεν θα μπορούσε να ανεβάσει πιθανόν να οφείλεται σε περιορισμούς άδεια σε κατάλογο προορισμού");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Error: File Δεν Uploaded. Ελέγξτε το μέγεθος και προσπαθήστε ξανά.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Πάω πίσω");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Όλα τα δικαιώματα διατηρούνται.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Μήνυμα");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","για");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Δημοσίευση νέας διαφήμισης");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","Αγγελίες Εντύπωση μου");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Κάντε κλικ Based Διαφημίσεις");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","δεσμεύεται χρόνου διαφημίσεων");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Πατήστε το κουμπί [Αναζήτηση] για να βρείτε το αρχείο στον υπολογιστή σας και στη συνέχεια κάντε κλικ στο κουμπί [Εισαγωγή] για να το φορτώσετε.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Εικόνα");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Μεταφόρτωση");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Παρακαλούμε να έχετε υπομονή, δεν θα λάβετε καμία ειδοποίηση μέχρι το αρχείο είναι εντελώς μεταφερθεί.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Αυτή η δυνατότητα έχει απενεργοποιηθεί στο demo.");

?>