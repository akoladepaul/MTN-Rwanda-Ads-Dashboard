<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Geef een titel!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Titel boven 25 tekens is niet toegestaan!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Geef een description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 boven de 35 karakter is niet toegestaan!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Geef een description2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Description2 boven de 35 karakter is niet toegestaan!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Geef aub vertoning url!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Gelieve Bestemming specificeren URL!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Upload afbeelding een banner.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Bewerk Text Ad Informatie");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Titel");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","redactionele richtlijnen");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Titel mag niet meer dan 25 tekens.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","beschrijving 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","Beschrijving mag niet meer dan 35 tekens.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","beschrijving 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","zichtbare URL");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Zichtbare URL mag niet meer dan 35 tekens.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","bestemmings-URL");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","Bestemmingsadres moet omvatten http: // www. bijv. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Bijwerken");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Uw banner wordt niet getoond totdat Admin stemt in met de wijzigingen.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","Ongeldige Id, niet in staat om verder te gaan");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","Ongeautoriseerde toegang, niet in staat om verder te gaan");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Gelieve te specificeren geldig e-mailadres");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","E-mailadres lijkt onjuist (check @ en.'s)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","De gebruikersnaam lijkt niet geldig te zijn.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","Destination IP-adres is ongeldig!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","De domeinnaam lijkt niet geldig te zijn.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","Het adres moet eindigen in een geldige domein, of twee letters land.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","Dit adres is het missen van een hostname!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Upload Image File");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Kies een bestand om te uploaden");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Upload .gif / .jpg / .jpeg / .bmp / ​​.png-bestanden alleen");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Upload .swf-bestanden");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Afbeelding uploaden");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Om een ​​afbeelding toe te voegen, klikt u op de knop 'Bladeren' en selecteer het bestand, of typ het pad naar het bestand in de Text-vak hieronder.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Klik vervolgens op de knop Uploaden om het proces te voltooien.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","NOTITIE");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","De bestandsoverdracht kan nemen van enkele seconden tot enkele minuten, afhankelijk van de grootte van het bestand. Gelieve te hebben geduld terwijl het bestand wordt geüpload.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","Het bestand zal worden omgedoopt als het bestand met dezelfde naam is al aanwezig");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Raak de knop [Browse] om het bestand op uw computer te vinden.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Beeld");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Uploaden");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Kies Data");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","Van");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","Dag");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Maand");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Jaar");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","naar");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Records per pagina");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","Tonen");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Money");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Bedrag");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Datum");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Beschrijving");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","transacties");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","Geen transactie gevonden die voldoen aan uw criteria.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Uw huidige saldo is% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Pagina% 1 $ s van% 2 $ s <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Purchase Package");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Type pakket: Impressions Based");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Verpakkingsnaam");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","impressies");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Prijs");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Prijs / Impression");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Grootte");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Type pakket: Klik Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","klikken");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Prijs / Click");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Type pakket: Time Based");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Duur");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Prijs / Maand");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","voortzetten");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","Er zijn geen aankoop pakketten die door de admin.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","Maanden");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Ongeldige toegang, niet in staat om verder te gaan");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","Banner advertentie");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","tekstadvertentie");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Uw% 1 $ s is bijgeschreven de gevraagde% 2 $ s.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Er is een fout opgetreden, probeer het opnieuw");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","Ongeautoriseerde toegang, ontkende");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","Tekstadvertentie is met succes toegevoegd. Uw tekstadvertentie wordt zo spoedig zal worden goedgekeurd verschijnen in onze banner rotator.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","Tekstadvertentie is met succes toegevoegd.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Uw tekst toevoegen advertentie aanvraag werd niet verwerkt wegens gebrek aan fondsen. Voeg wat geld op uw account en probeer het opnieuw");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Er is een fout opgetreden, probeer het opnieuw");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Uw wijzigingen zijn verzonden voor admin goedkeuring");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","Inavlid toegang, niet in staat om verder te gaan");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","Kan geen banner gegevens bij te werken, probeer het opnieuw");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Kies de juiste soort banner");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Add New Banner");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","Pakkettype");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","banner Size");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","banner Type");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Afbeelding (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","bestemmings-URL");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","Bestemmings-URL niet vereist voor flash banner type. Bestemming adres van de website zouden omvat http: // www. bijv. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","banner Afbeelding");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Verwijderen");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Indruk");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Klik");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","U moet ingelogd zijn om deze pagina!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Hulp voor tekstadvertentie posting");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Redactionele richtlijnen");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Vul login informatie!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Welkom% s, hebt u met succes ingelogd-in.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Voer de juiste inloggegevens!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Koop Meer Impressions");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Koop nu");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Dit proces is onomkeerbaar, geld eenmalig te betalen kan niet worden terugbetaald.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","Er is geen pakket beschikbaar voor deze banner grootte.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","Er is geen pakket beschikbaar voor deze tekstadvertentie.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","Impressions Op basis");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Klik Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","Time Based");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Banner niet gevonden. Klik");
//here
define("SOFTBIZ_LC00009_BUY_MORE","hier");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","doorgaan");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Inhoud ad");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Toevoegen");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Annuleer");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","NOTITIE:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Terug");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Sorry, adverteerders met de e-mail% s bestaat al.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","U bent succesvol Ingeschreven met ons");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Sommige fout opgetreden. Probeer het opnieuw!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","Betalen");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Bedrag dat moet worden toegevoegd");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Huidige balans");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Balans na toevoeging");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Money toevoegen om rekening te houden");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Toegevoegd geld om je account");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Doorgaan met Paypal Payment");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Doorgaan naar 2Checkout Payment");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Voorwaarden");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","offline");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","via Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","Via 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","Wachtwoord is veranderd!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","Wachtwoord kan niet worden bijgewerkt, omdat je oude wachtwoord onjuist was");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Geef een niet-nul positieve numerieke waarde!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Voeg toe aan mijn rekening");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Betalingsmiddel");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","pay Offline");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","add tekstadvertentie");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","add banner");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","kopen meer duur");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","kopen meer clicks");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","kopen meer indrukken");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","Uw aanvraag% s is niet verwerkt wegens gebrek aan fondsen. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Je hebt minimaal% s voor gekozen arrangement. <br> Wat geld op uw rekening of kies een ander pakket");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Vul Huidig ​​wachtwoord");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Verander wachtwoord");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","huidig ​​wachtwoord");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","nieuw paswoord");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Geef nogmaals het wachtwoord");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Wachtwoord bijwerken");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Nieuw wachtwoord moet minimaal% s karakters lang zijn");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Vul Nieuw wachtwoord");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","Overgetypt wachtwoord gebeurt onafhankelijk overeenkomen met het nieuwe wachtwoord");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","moet minimaal zijn% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","karakter");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","karakters");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Uw banner is bijgewerkt");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Aggregate Banner Statistieken Voor al uw Banners");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Totaal aantal Banners Geplaatst");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","aangenomen");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","afgekeurd");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Total Impressions Ontvangen");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Totaal ontvangen klikken");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Gemiddeld Click Through Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Laatste Impression");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Laatste Klik");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","Meer lezen Banner / Text Ad");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","Meest geklikte Banner / Text Ad");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Stats: klikken / vertoningen");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Vandaag");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Gisteren");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Afgelopen 7 dagen");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Laatste 14 Dagen");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","Afgelopen jaar");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","Dit Jaar: klikken / vertoningen");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","Deze maand: klikken / vertoningen");
//January
define("SOFTBIZ_LC00019_AD_HOME","januari-");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Febuary");
//March
define("SOFTBIZ_LC00021_AD_HOME","maart");
//April
define("SOFTBIZ_LC00022_AD_HOME","april");
//May
define("SOFTBIZ_LC00023_AD_HOME","mei");
//June
define("SOFTBIZ_LC00024_AD_HOME","juni-");
//July
define("SOFTBIZ_LC00025_AD_HOME","juli-");
//August
define("SOFTBIZ_LC00026_AD_HOME","augustus");
//September
define("SOFTBIZ_LC00027_AD_HOME","september");
//October
define("SOFTBIZ_LC00028_AD_HOME","oktober");
//November
define("SOFTBIZ_LC00029_AD_HOME","november");
//December
define("SOFTBIZ_LC00030_AD_HOME","december");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Banner is met succes toegevoegd. Uw banner zal zo spoedig zal worden goedgekeurd verschijnen in onze banner rotator.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Banner is met succes toegevoegd.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","Uw add banner aanvraag werd niet verwerkt wegens gebrek aan fondsen. Voeg wat geld op uw account en probeer het opnieuw");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","ad Types");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Kies Ad Type");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Ongeldig email adres.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Gelieve te specificeren validatie code");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Wachtwoord vergeten");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Geef uw e-id. Wij zullen uw wachtwoord in e-mail.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","E-mail identiteit");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Validatie code");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Verzend verzoek");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","De gebruikersnaam in het e-mailadres lijkt ongeldig");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","Destination IP in het e-mailadres is ongeldig");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","De domeinnaam in het e-mailadres lijkt ongeldig");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","Het e-mailadres moet eindigen in een geldige domein of twee letters bestaande landencode");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","E-mailadres ontbreekt een hostname");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Geef de tekst weergegeven beeld bovenstaande validatie code in. Deze tekst is het geval in kleine letters.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","Gespecificeerde validatie code was onjuist");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","Voer uw naam in!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Vul uw adres!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Vul uw City!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Vul uw staat!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Kies aub een land!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Vul uw URL van de website!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Voer wachtwoord in alstublieft.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Wachtwoorden komen niet overeen.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Nieuw Adverteerder: Inschrijven door het invullen van onderstaand formulier");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Uw naam");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Jouw adres");
//City
define("SOFTBIZ_LC00011_SITEHOME","stad");
//State
define("SOFTBIZ_LC00012_SITEHOME","Staat");
//Country
define("SOFTBIZ_LC00013_SITEHOME","land");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Selecteer een land");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","Website URL");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Jouw email");
//Password
define("SOFTBIZ_LC00017_SITEHOME","Wachtwoord");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","bevestig wachtwoord");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","voorleggen");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Gelieve uw e-mailadres.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Gelieve te specificeren wachtwoord.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Bestaande adverteerders: Log in hier");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Aanmelden");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","Wachtwoord moet minimaal% s karakters lang zijn.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","Adverteerders Menu");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Huis");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Bewerk profiel");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Uitloggen");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","mijn advertenties");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Voeg Nieuwe advertentie");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Advertenties beheren");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Alle tekstadvertenties");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","alle Banners");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Mijn rekening");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Hi <font class = 'red'> '% 1 $ s' </ font>, uw rekeningsaldo is% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Kleurenschema");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Geef een geldige numerieke waarde voor Banner #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Zoeken Banners / tekstadvertentie");
//Keyword
define("SOFTBIZ_LC00002_ADS","keyword");
//Search in
define("SOFTBIZ_LC00003_ADS","Zoek in");
//Banner #
define("SOFTBIZ_LC00004_ADS","banner #");
//All
define("SOFTBIZ_LC00005_ADS","Alle");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","Wachten op goedkeuring");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Alle maten");
//Ad Type
define("SOFTBIZ_LC00008_ADS","ad Type");
//All Packages
define("SOFTBIZ_LC00009_ADS","alle pakketten");
//Sort by
define("SOFTBIZ_LC00010_ADS","Sorteer op");
//Date Added
define("SOFTBIZ_LC00011_ADS","Datum toegevoegd");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","impressies Gekocht");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Vervaldatum");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","impressies Ontvangen");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","klikken Ontvangen");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","Impressions Left");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","klikken Left");
//Days Left
define("SOFTBIZ_LC00018_ADS","Dagen over");
//Order
define("SOFTBIZ_LC00019_ADS","Bestellen");
//Ascending
define("SOFTBIZ_LC00020_ADS","oplopend");
//Descending
define("SOFTBIZ_LC00021_ADS","Aflopend");
//Search
define("SOFTBIZ_LC00022_ADS","Zoeken");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Click through rate");
//Status
define("SOFTBIZ_LC00024_ADS","toestand");
//Note
define("SOFTBIZ_LC00025_ADS","Notitie");
//Buy More
define("SOFTBIZ_LC00026_ADS","Koop meer");
//Edit
define("SOFTBIZ_LC00027_ADS","Bewerk");
//Stats
define("SOFTBIZ_LC00028_ADS","Stats");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","Geen Ad voldoen aan de criteria die u hebt opgegeven.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Ad zoekresultaten voor% s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","Ad zoekresultaten voor Ad #% s");
//Banner
define("SOFTBIZ_LC00032_ADS","banier");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Tekstadvertentie Type");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","klikken Gekocht");
//Expired
define("SOFTBIZ_LC00035_ADS","Verlopen");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","Pagina% s van% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Wijzig banner Informatie");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","Bestemmings-URL niet vereist voor flash banner type. Bestemmingsadres moet omvatten http: // www. bijv. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","Statistieken");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Type");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","geplaatst op");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Geef uw e-id om uw wachtwoord op te halen!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Uw wachtwoord is per e-mail");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","E-mail is uitgeschakeld door admin, niet in staat om uw wachtwoord te sturen.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","Geen leden gevonden met een dergelijke e-id!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Uw profiel is bijgewerkt");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Voeg Money Process");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","U hebt uw add geld aanvragen bij PayPal geannuleerd.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Nieuwe Tekstadvertentie geplaatst: Clicks");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Nieuwe Tekstadvertentie geplaatst: Impressions");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Nieuwe Tekstadvertentie geplaatst: Maanden");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","Uitgebreide tekstadvertentie: Clicks");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","Uitgebreide tekstadvertentie: Impressions");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","Uitgebreide tekstadvertentie: Maanden");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Nieuwe advertentie van de banner geplaatst: Clicks");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Nieuwe advertentie van de banner geplaatst: Impressions");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Nieuwe advertentie van de banner geplaatst: Maanden");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","Uitgebreide banner ad: Clicks");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","Uitgebreide banner ad: Impressions");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","Uitgebreide banner ad: Maanden");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","Geld toegevoegd via 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","Geld toegevoegd via paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","naar huis adverteerder.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","nieuwe aankondiging toevoegen.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","om uw advertenties te beheren.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","om geld toe te voegen aan de rekening.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","om rekening te houden transacties bekijken.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","om uit te loggen");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Houd er rekening mee als uw advertentie tekst niet voldoet aan de redactionele richtlijnen dan is uw advertentie kan worden opgeschort");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Titel mag niet meer dan 25 tekens.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Geef een description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 mag niet meer dan 35 tekens.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Description2 mag niet meer dan 35 tekens.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","pakket informatie");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Inhoud toevoegen");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Bestemming adres van de website zouden omvat http: // www <br> bijv.. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Betaling zijn toegevoegd aan je account");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Ongeldige toegang, ontkende");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Uw add geld Request is geaccepteerd. Fondsen zal zeer binnenkort verschijnen in uw account.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Upload Image File Status");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","Image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","AFWERKING");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Alleen .jpg / .png / .gif / .bmp / ​​.jpeg / SWF-bestand formaten zijn toegestaan. Please dit venster sluiten en probeer het opnieuw");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Geüploade bestanden moeten kleiner zijn dan% SKB zijn. Sluit dit venster en probeer het opnieuw");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Succes: Bestand is geüpload");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Fout: Bestandsgrootte meer dan 512,000 bytes");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Fout: Bestand gedeeltelijk geupload");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Fout: Geen bestand geupload");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","Bestand kon niet waarschijnlijk worden geüpload vanwege toestemming beperkingen op de doelmap");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Fout: Bestand niet geüpload. Controleer Size & Try Again.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Ga terug");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Alle rechten voorbehouden.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Bericht");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","voor");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Maak een nieuw Ad");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","Mijn indruk advertenties");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Klik Based Ads");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","Tijdgebonden Advertenties");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Raak de knop [Browse] om het bestand op uw computer te vinden en klik vervolgens op [Invoegen] knop om het te uploaden.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Beeld");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Uploaden");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Gelieve geduld hebben, zult u geen melding totdat het dossier volledig is overgedragen.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Deze functie is uitgeschakeld in de demo.");


?>