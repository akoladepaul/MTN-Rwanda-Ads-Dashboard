<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Bitte geben Sie einen Titel!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Titel über 25 Zeichen ist nicht erlaubt!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Bitte geben Sie eine description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 über 35 Zeichen ist nicht erlaubt!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Bitte geben Sie eine description2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Description2 über 35 Zeichen ist nicht erlaubt!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Bitte geben Sie die angezeigte URL!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Bitte Geben Sie die Ziel-URL!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Bitte laden Sie ein Banner Bild.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Text bearbeiten Ad Informationen");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Titel");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","Editorial-Richtlinien");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Titel sollte nicht mehr als 25 Zeichen lang sein.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","Beschreibung 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","Beschreibung sollte nicht mehr als 35 Zeichen lang sein.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","Beschreibung 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","Anzeige-URL");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Anzeige-URL sollte nicht mehr als 35 Zeichen lang sein.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","Ziel-URL");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","Zieladresse sollte http: // www. z.B. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Aktualisieren");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Ihr Banner wird nicht angezeigt, bis Admin die Änderungen genehmigt.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","Ungültige ID, nicht fortgesetzt werden");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","Unberechtigter Zugang, nicht fortgesetzt werden");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Bitte geben Sie gültige E-Mail-Adresse");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","E-Mail-Adresse scheint nicht korrekt (Check @ und. 'S)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","Der Benutzername scheint nicht gültig zu sein.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","Ziel-IP-Adresse ist ungültig!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","Der Domain-Name scheint nicht gültig zu sein.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","Die Adresse muss in einem gültigen Domäne oder zwei Buchstaben bestehenden Länder beenden.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","Diese Adresse fehlt einen Hostnamen!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Laden Sie Image File");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Bitte wählen Sie eine Datei hochladen");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Bitte laden Sie GIF / JPG / JPEG / BMP / PNG-Dateien nur");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Bitte laden Sie SWF-Dateien nur");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Bild hochladen");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Um ein Bild hinzuzufügen, klicken Sie auf die Schaltfläche \"Durchsuchen\" und wählen Sie die Datei, oder geben Sie den Pfad zur Datei im Text-Box unten.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Klicken Sie dann auf Upload-Button, um den Vorgang abzuschließen.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","HINWEIS");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","Die Dateiübertragung kann von wenigen Sekunden bis zu einigen Minuten dauern, von der Größe der Datei abhängig. Bitte haben Sie Geduld, während die Dateien hochgeladen werden.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","Die Datei wird umbenannt werden, wenn die Datei mit dem gleichen Namen bereits vorhanden ist,");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Drücken Sie die Schaltfläche [Durchsuchen] die Datei auf Ihrem Computer zu finden.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Image");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Hochladen");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Daten auswählen");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","Von");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","Tag");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Monat");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Jahr");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","Nach");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Datensätze pro Seite");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","Show");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Geld hinzufügen");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Menge");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Datum");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Beschreibung");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","Transaktionen");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","Keine Transaktion gefunden erfüllen Ihre Kriterien.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Ihr Guthaben ist% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Seite% 1 $ s von% 2 $ s <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Kauf-Paket");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Verpackung: Impressionen Based");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Paketnamen");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","Impressionen");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Preis");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Preis / Impression");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Größe");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Pakettyp: Klicken Sie auf Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","Klicks");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Preis / Click");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Pakettyp: Zeitbasierte");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Dauer");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Preis / Monat");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","Fortsetzen");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","Es sind keine Kauf-Pakete durch den Admin definiert.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","Monate");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Ungültige Zugang, nicht fortgesetzt werden");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","Werbebanner");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","Textanzeige");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Ihre% 1 $ s wurde die angeforderten% 2 $ s gutgeschrieben.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Es ist ein Fehler aufgetreten, bitte versuchen Sie es erneut");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","Unberechtigter Zugang verweigert");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","Textanzeige wurde erfolgreich hinzugefügt. Ihre Textanzeige wird in unserem Banner Rotator erscheinen, sobald sie genehmigt werden.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","Textanzeige wurde erfolgreich hinzugefügt.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Ihre Textanzeige hinzufügen Anfrage wurde nicht aufgrund von Mitteln an Mangel verarbeitet worden ist. Fügen Sie etwas Geld auf Ihr Konto und versuchen Sie es erneut");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Es ist ein Fehler aufgetreten, bitte versuchen Sie es erneut");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Ihre Änderungen wurden für die Admin-Zustimmung gesendet");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","Inavlid Zugang, nicht fortgesetzt werden");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","wieder kann nicht Banner Details zu aktualisieren, versuchen Sie bitte");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Bitte wählen Sie richtig Fahnenart");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","New Banner");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","Verpackung");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","Banner Größe");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Banner Typ");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Bild (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","Ziel-URL");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","Ziel-URL nicht für Flash-Banner-Typ erforderlich. Destination Website-Adresse sollte beinhaltet http: // www. z.B. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","Banner Image");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Entfernen");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Eindruck");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Klicken");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","Sie müssen Zugriff auf diese Seite angemeldet sein!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Hilfe für Textanzeigen-Posting");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","redaktionelle Richtlinien");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Bitte geben Sie Login-Informationen!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Willkommen% s, haben Sie erfolgreich angemeldet.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Bitte geben Sie die richtigen Login-Daten!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Kaufen Impressionen");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Kaufe jetzt");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Dieser Prozess ist nicht umkehrbar, Geld einmal bezahlt wird nicht zurückerstattet.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","Es gibt kein Paket für dieses Bannergröße.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","Es gibt kein Paket für dieses Textanzeige.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","Impressionen Basierend");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Klicken Sie Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","Zeitbasierte basierte~~POS=HEADCOMP");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Banner nicht gefunden. Klicken");
//here
define("SOFTBIZ_LC00009_BUY_MORE","Hier");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","weitermachen");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","ad Inhalt");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Hinzufügen");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Stornieren");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","HINWEIS:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Zurück");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Sorry, Werbetreibende bei der E-Mail-% s ist bereits vorhanden.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","Sie sind erfolgreich bei uns angemeldet");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Einige Fehler aufgetreten. Bitte versuche es erneut!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","Bezahlen");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Zugabemenge");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Aktueller Kontostand");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Bilanz nach Zugabe");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","In Geld zu berücksichtigen");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Hinzugefügt Geld auf Ihr Konto");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Weiter zur Paypal-Zahlung");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Weiter zu 2Checkout Zahlungs");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Geschäftsbedingungen");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","Offline");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","durch Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","durch 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","Das Passwort wurde geändert!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","Kennwort konnte nicht aktualisiert werden, da Ihr altes Passwort falsch war");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Bitte geben Sie eine von Null verschiedene positive Zahlenwert!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Zu meinem Account hinzufügen");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Bezahlverfahren");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Pay offline");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","Text hinzufügen Anzeige");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","hinzufügen banner");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","kaufen mehr Dauer");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","kaufen mehr Klicks");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","kaufen mehr Eindrücke");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","Ihre% s Anfrage wurde aufgrund fehlender Mittel nicht bearbeitet. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Sie müssen mindestens% s für ausgewählte Paket. <br> Etwas Geld auf Ihr Konto hinzufügen oder ein anderes Paket wählen");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Bitte geben Sie das aktuelle Passwort");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Passwort ändern");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","Aktuelles Passwort");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","Neues Kennwort");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Passwort erneut eingeben");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Passwort aktualisieren");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Neues Passwort muss ATLEAST% s Zeichen lang sein");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Bitte geben Sie Neues Passwort");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","Abgetippt Passwort doesnot dem neuen Kennwort überein");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","müssen atleast% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","Charakter");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","Figuren");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Ihr Banner wurde aktualisiert");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Aggregate Banner Statistiken für alle Ihre Banner");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Gesamtzahl der Banner Posted");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","Genehmigt");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","Abgelehnt");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Insgesamt Impressionen");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Insgesamt Klicks erhalten");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Durchschnittliche Click Through Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Neueste Impression");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Neueste Click");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","Die meisten Angezeigte Banner / Textanzeige");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","Die meisten angeklickt Banner / Textanzeige");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Statistik: Klicks / Impressionen");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Heute");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Gestern");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Letzten 7 Tage");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Die letzten 14 Tage");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","Letztes Jahr");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","In diesem Jahr: Klicks / Impressionen");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","In diesem Monat: Klicks / Impressionen");
//January
define("SOFTBIZ_LC00019_AD_HOME","Januar");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Febuary");
//March
define("SOFTBIZ_LC00021_AD_HOME","März");
//April
define("SOFTBIZ_LC00022_AD_HOME","April");
//May
define("SOFTBIZ_LC00023_AD_HOME","Kann");
//June
define("SOFTBIZ_LC00024_AD_HOME","Juni");
//July
define("SOFTBIZ_LC00025_AD_HOME","Juli");
//August
define("SOFTBIZ_LC00026_AD_HOME","August");
//September
define("SOFTBIZ_LC00027_AD_HOME","September");
//October
define("SOFTBIZ_LC00028_AD_HOME","Oktober");
//November
define("SOFTBIZ_LC00029_AD_HOME","November");
//December
define("SOFTBIZ_LC00030_AD_HOME","Dezember");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Banner wurde erfolgreich hinzugefügt. Ihr Banner wird in unserem Banner Rotator erscheinen, sobald sie genehmigt werden.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Banner wurde erfolgreich hinzugefügt.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","Ihr Add Banner Anfrage wurde aufgrund fehlender Mittel nicht verarbeitet. Fügen Sie etwas Geld auf Ihr Konto und versuchen Sie es erneut");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Anzeigentypen");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Wählen Sie Anzeigentyp");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Ungültige E-Mail-Adresse.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Bitte geben Sie Bestätigungscode");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Passwort vergessen");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Bitte geben Sie Ihre E-Mail-ID. Wir werden Ihr Passwort per E-Mail senden.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","E-Mail-ID");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Validierungscode");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Anfrage senden");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","Der Benutzername in der E-Mail-Adresse scheint ungültig");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","Ziel-IP in der E-Mail-Adresse ist ungültig");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","Der Domain-Name in der E-Mail-Adresse scheint ungültig");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","Die E-Mail-Adresse muss in einem gültigen Domäne oder zwei Buchstaben bestehenden Länder beenden");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","E-Mail-Adresse fehlt einen Hostnamen");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Geben Sie den Text in der obigen Validierungscode Bild angezeigt. Dieser Text ist in Fall empfindlich.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","Spezifizierte Validierungscode ist falsch");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","Bitte geben Sie Ihren Namen ein!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Bitte geben Sie Ihre Adresse!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Bitte geben Sie Ihre Stadt!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Geben Sie den Staat!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Bitte wählen Sie ein Land!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Bitte geben Sie Ihre Website-URL!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Bitte Passwort eingeben.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Passwörter stimmen nicht überein.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Neu Inserent: Anmelden durch folgende Formular ausfüllen:");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Dein Name");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Deine Adresse");
//City
define("SOFTBIZ_LC00011_SITEHOME","Stadt");
//State
define("SOFTBIZ_LC00012_SITEHOME","Bundesland");
//Country
define("SOFTBIZ_LC00013_SITEHOME","Land");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Wähle ein Land");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","Webadresse");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Deine E-Mail");
//Password
define("SOFTBIZ_LC00017_SITEHOME","Passwort");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","Bestätige das Passwort");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","einreichen");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Bitte geben Sie Ihre E-Mail-Adresse ein.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Bitte geben Sie Ihr Passwort ein.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Bestehende Inserenten: Login Hier");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Anmelden");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","Das Passwort muss ATLEAST% s Zeichen lang sein.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","Inserenten-Menü");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Zuhause");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Profil bearbeiten");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Ausloggen");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","Meine Anzeigen");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Fügen Sie neue Anzeige");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Anzeigen verwalten");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Alle Textanzeigen");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","Alle Banner");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Mein Konto");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Hallo <font class = 'red'> '% 1 $ s </ font>, Ihr Kontostand ist% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Farbschema");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Bitte geben Sie eine gültige Zahlenwert für Banner #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Suche Banner / Textanzeige");
//Keyword
define("SOFTBIZ_LC00002_ADS","Stichwort");
//Search in
define("SOFTBIZ_LC00003_ADS","Suchen in");
//Banner #
define("SOFTBIZ_LC00004_ADS","Banner #");
//All
define("SOFTBIZ_LC00005_ADS","Alle");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","Warten auf die Bestätigung");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Alle Größen");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Anzeigentyp");
//All Packages
define("SOFTBIZ_LC00009_ADS","Alle Pakete");
//Sort by
define("SOFTBIZ_LC00010_ADS","Sortiere nach");
//Date Added
define("SOFTBIZ_LC00011_ADS","Datum hinzugefügt");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","Impressionen Gekaufte");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Verfallsdatum");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","Impressionen");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","Klicks erhalten");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","Impressionen links");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","Klicks links");
//Days Left
define("SOFTBIZ_LC00018_ADS","Tage übrig");
//Order
define("SOFTBIZ_LC00019_ADS","Auftrag");
//Ascending
define("SOFTBIZ_LC00020_ADS","Aufsteigend");
//Descending
define("SOFTBIZ_LC00021_ADS","Absteigend");
//Search
define("SOFTBIZ_LC00022_ADS","Suche");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Klickrate");
//Status
define("SOFTBIZ_LC00024_ADS","Status");
//Note
define("SOFTBIZ_LC00025_ADS","Hinweis");
//Buy More
define("SOFTBIZ_LC00026_ADS","Kauf mehr");
//Edit
define("SOFTBIZ_LC00027_ADS","Bearbeiten");
//Stats
define("SOFTBIZ_LC00028_ADS","Statistik");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","Keine Ad erfüllen die Kriterien, die Sie angegeben haben.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Anzeige Suchergebnisse für% s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","Anzeige Suchergebnisse für Ad #% s");
//Banner
define("SOFTBIZ_LC00032_ADS","Banner");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Text Anzeigentyp");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","Klicks gekauft");
//Expired
define("SOFTBIZ_LC00035_ADS","Abgelaufen");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","Seite% s% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Bearbeiten Banner Informationen");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","Ziel-URL nicht für Flash-Banner-Typ erforderlich. Zieladresse sollte http: // www. z.B. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","Statistiken");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Art");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","Veröffentlicht am");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Bitte geben Sie Ihre E-Mail Ihr Passwort zu erhalten!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Ihr Passwort wurde per E-Mail");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","E-Mail wurde von admin deaktiviert, nicht in der Lage, Ihr Passwort zu senden.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","Nein Mitglied mit einer solchen E-Mail-ID gefunden!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Ihr Profil wurde aktualisiert");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","In Geldprozess");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","Sie haben Ihre Add Geld anfordern bei paypal abgebrochen.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Neue Textanzeige geschrieben: Klicks");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Neue Textanzeige geschrieben: Impressionen");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Neue Textanzeige geschrieben: Monate");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","Erweiterte Textanzeige: Klicks");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","Erweiterte Textanzeige: Impressionen");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","Erweiterte Textanzeige: Monate");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Neue Banner Anzeige geschrieben: Klicks");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Neue Banner Anzeige geschrieben: Impressionen");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Neue Banner Anzeige geschrieben: Monate");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","Erweiterte Banner-Anzeige: Klicks");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","Erweiterte Werbebanner: Impressionen");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","Erweiterte Werbebanner: Monate");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","Geld hinzugefügt durch 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","Geld hinzugefügt durch paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","nach Hause gehen an Inserent.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","neue Anzeige hinzuzufügen.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","zu verwalten Sie Ihre Anzeigen.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","Geld auf das Konto hinzuzufügen.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","Kontotransaktionen zu sehen.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","abzumelden");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Bitte beachten Sie, wenn Sie Ihren Anzeigentext zu den redaktionellen Richtlinien entspricht nicht dann Ihre Anzeige könnte gesperrt werden");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Titel sollte nicht mehr als 25 Zeichen lang sein.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Bitte geben Sie eine description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 sollte nicht mehr als 35 Zeichen lang sein.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Description2 sollte nicht mehr als 35 Zeichen lang sein.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","Paketinformationen");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Inhalt hinzufügen");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Destination Website-Adresse sollte umfasst http: // www <br> z. B.. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Die Zahlung wurde zu Ihrem Konto hinzugefügt");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Unzulässiger Zugriff verweigert");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Ihr Add Geld Antrag wurde angenommen. Die Mittel werden sehr bald in Ihrem Konto angezeigt.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Bild hochladen Dateistatus");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","FERTIG");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Nur .jpg / .png / .gif / .bmp / ​​jpeg / .swf Dateiformate erlaubt sind. <br> Bitte dieses Fenster schließen und versuchen Sie es erneut");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Hochgeladene Dateien müssen weniger als% SKB sein. Bitte schließen Sie dieses Fenster und versuchen Sie es erneut");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Erfolg: Die Datei wurde hochgeladen");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Fehler: Dateigröße mehr als 512.000 Bytes");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Fehler: Die Datei teilweise hochgeladen");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Fehler: Keine Datei hochgeladen");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","Datei konnte nicht wahrscheinlich hochgeladen werden aufgrund von Zugriffsbeschränkungen auf Zielverzeichnis");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Fehler: Datei hochgeladen. Überprüfen Sie Größe und versuchen Sie es erneut.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Geh zurück");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Alle Rechte vorbehalten.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Nachricht");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","für");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Post New Ad");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","Mein Eindruck Ads");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Klicken Sie auf Based Ads");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","Zeit gebunden Anzeigen");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Drücken Sie die Schaltfläche [Durchsuchen] die Datei auf Ihrem Computer zu finden, und klicken Sie dann auf [Einfügen] -Taste es hochzuladen.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Image");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Hochladen");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Bitte haben Sie Geduld, werden Sie keine Benachrichtigung erhalten, bis die Datei vollständig übertragen wird.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Diese Funktion wurde in der Demo deaktiviert.");

?>