<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Пожалуйста, укажите название!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Название выше 25 символа не допускается!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Введи description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 выше 35 символа не допускается!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Пожалуйста, укажите description2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Description2 выше 35 символа не допускается!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Пожалуйста, укажите отображаемый URL!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Пожалуйста, укажите URL назначения!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Пожалуйста, загрузите изображение баннера.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Изменение информации Текст объявления");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","заглавие");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","Редакционные принципы");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Название не должно быть более 25 символов.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","Описание 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","Описание не должно быть более 35 символов.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","Описание 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","Отображаемый URL");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Отображаемый URL не должно быть более 35 символов.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","URL назначения");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","Адрес назначения должен включать HTTP: // WWW. например. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Обновить");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Ваш баннер не будет отображаться, пока Admin не одобрит изменения.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","Неправильный идентификатор, не смог продолжить игру");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","Несанкционированный доступ, не смог продолжить игру");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Пожалуйста, укажите действительный адрес электронной почты");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","Адрес электронной почты, кажется, неправильный (чек @ и. В)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","Имя пользователя, кажется, не действительны.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","Destination IP адрес недействителен!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","Доменное имя, кажется, не действительны.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","Адрес должен заканчиваться действительным доменом или две буквы страны.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","Этот адрес отсутствует имя хоста!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Загрузить файл изображения");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Пожалуйста, выберите файл для загрузки");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Пожалуйста, загрузите .gif / .jpg / .jpeg / .bmp / ​​.png файлы только");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Пожалуйста, загрузите файлы только .swf");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Загрузить изображение");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Для добавления изображения, нажмите кнопку \"Обзор\" и выберите файл, или введите путь к файлу в текстовом поле ниже.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","После этого нажмите кнопку Загрузить, чтобы завершить процесс.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","ЗАМЕТКА");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","Передача файла может занять от нескольких секунд до нескольких минут, в зависимости от размера файла. Пожалуйста, имейте терпение, пока файл загружается.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","Файл будет переименован, если файл с таким же именем уже присутствует");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Нажмите кнопку [Обзор], чтобы найти файл на вашем компьютере.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Образ");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Загрузить");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Выберите Даты");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","Из");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","День");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Месяц");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Год");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","к");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Записей на странице");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","Показать");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Добавить деньги");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Количество");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Дата");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Описание");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","операции");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","Ни одна сделка не найдено, удовлетворяющих вашим критериям.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Ваш текущий баланс% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Страница% 1 $ s% 2 $ S <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Покупка пакета");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Тип упаковки: Впечатления основе");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Имя пакета");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","Впечатления");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Цена");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Цена / Впечатление");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Размер");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","ПВ");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Тип упаковки: Нажмите Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","щелчки");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Цена / нажмите");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Тип упаковки: Время на основе");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","продолжительность");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Цена / месяц");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","Продолжать");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","Там нет на покупку пакетов, определенных администратором.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","Месяцы");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Неверный доступ, не смог продолжить игру");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","Баннер");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","Текст объявления");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Ваш% 1 $ s приписали запрошенные% 2 $ S.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Некоторые произошла ошибка, пожалуйста, попробуйте еще раз");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","Несанкционированный доступ, отказано");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","Текст объявления был успешно добавлен. Ваше текстовое объявление будет появляться в нашем знамени ротатора, как только он будет утвержден.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","Текст объявления был успешно добавлен.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Ваш запрос Текст объявления добавить не был обработан из-за отсутствия средств. Добавьте деньги на свой счет и повторите попытку");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Некоторые ошибка, пожалуйста попробуйте еще раз");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Изменения были направлены на утверждение администратора");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","Inavlid доступа, не смог продолжить игру");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","Невозможно обновить детали баннер, пожалуйста, попробуйте еще раз");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Пожалуйста, выберите правильный тип баннера");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Добавить новый баннер");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","Тип упаковки");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","Размер баннера");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Баннер Тип");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Изображение (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","URL назначения");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","URL назначения не требуется для типа флэш-баннеров. Пункт назначения адрес веб-сайта должен включает в себя HTTP: // WWW. например. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","изображение баннера");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Удалить");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Впечатление");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Нажмите");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","Вы должны быть зарегистрированы, чтобы открыть эту страницу!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Помощь для текста публикации объявлений");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Редакционные правила");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Пожалуйста, введите регистрационную информацию!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Добро пожаловать% s, вы успешно вошли в систему.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Пожалуйста, введите правильную информацию для входа!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Купите больше Впечатления");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","купить сейчас");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Этот процесс является необратимым, деньги когда-то заплатили, не может быть возвращен.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","Там нет пакет, доступный для этого размера баннера.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","Там нет пакет, доступный для этого текстового объявления.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","Впечатления На основании");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Нажмите Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","Время на основе");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Баннер не найден. Нажмите");
//here
define("SOFTBIZ_LC00009_BUY_MORE","Вот");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","продолжать");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Содержание объявления");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Добавить");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Отмена");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","ЗАМЕТКА:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","назад");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","К сожалению, рекламодатель с электронной% S уже существует.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","Вы успешно зарегистрированный с нами");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Некоторые ошибки Ocurred. Пожалуйста, попробуйте снова!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","платить");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Количество добавляемого");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Текущий баланс");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Остаток после добавления");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Добавить деньги на счет");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Добавлены деньги на свой счет");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Продолжать Paypal Оплата");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Продолжайте 2Checkout Оплата");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Условия и положения");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","Не в сети");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","Через Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","Через 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","Пароль был изменен!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","Пароль не может быть обновлен, потому что ваш старый пароль был неправильным");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Пожалуйста, укажите ненулевое положительное числовое значение!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Добавить в мой аккаунт");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Способ оплаты");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Оплатить на форуме");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","добавить текстовое объявление");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","добавить баннер");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","купить больше продолжительность");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","купить больше кликов");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","купить больше впечатлений");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","Ваш запрос% S не был обработан из-за нехватки средств. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Вам нужно по крайней мере,% S для выбранного пакета. <br> Добавьте деньги на свой счет или выбрать какой-либо другой пакет");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Пожалуйста, введите текущий пароль");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Изменить пароль");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","текущий пароль");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","новый пароль");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Повторите ввод пароля");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Обновление пароля");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Новый пароль должен быть длиной по крайней мере% S символов");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Пожалуйста, введите новый пароль");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","Перепечатать пароль оленья кожа соответствовать новый пароль");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","должно быть зарегистрировано не менее% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","персонаж");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","персонажи");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Ваш баннер был обновлен");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Совокупные Баннер Статистика для всех ваших баннеров");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Общее количество баннеров Добавлено");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","утвержденный");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","Отклонено");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Всего показов Поступило");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Всего кликов");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Средняя Нажмите Through Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Последнее Впечатление");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Последние нажмите");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","Самые читаемые Баннер / Текст объявления");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","Большинство Кликов Баннер / Текст объявления");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Статистика: клики / показы");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Cегодня");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Вчера");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","За последние 7 дней");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Последние 14 дней");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","В прошлом году");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","В этом году: клики / показы");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","В этом месяце: клики / показы");
//January
define("SOFTBIZ_LC00019_AD_HOME","январь");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Febuary");
//March
define("SOFTBIZ_LC00021_AD_HOME","Март");
//April
define("SOFTBIZ_LC00022_AD_HOME","апрель");
//May
define("SOFTBIZ_LC00023_AD_HOME","май");
//June
define("SOFTBIZ_LC00024_AD_HOME","июнь");
//July
define("SOFTBIZ_LC00025_AD_HOME","июль");
//August
define("SOFTBIZ_LC00026_AD_HOME","август");
//September
define("SOFTBIZ_LC00027_AD_HOME","сентябрь");
//October
define("SOFTBIZ_LC00028_AD_HOME","октября");
//November
define("SOFTBIZ_LC00029_AD_HOME","ноябрь");
//December
define("SOFTBIZ_LC00030_AD_HOME","Декабрь");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Баннер был успешно добавлен. Ваш баннер будет появляться в нашем знамени ротатора, как только он будет утвержден.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Баннер был успешно добавлен.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","Ваш запрос добавить баннер не был обработан из-за отсутствия средств. Добавьте деньги на свой счет и повторите попытку");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Типы объявлений");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Выберите тип объявления");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Неверный адрес электронной почты.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Пожалуйста, сформулируйте код подтверждения");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Забыли пароль");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Пожалуйста, укажите ваш электронный идентификатор. Мы вышлем вам пароль по электронной почте.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","Email ID");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Код проверки");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Послать запрос");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","Имя пользователя в адресе электронной почты кажется недействительным");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","Destination IP в адрес электронной почты является недействительным");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","Доменное имя в адресе электронной почты кажется недействительным");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","Адрес электронной почты должен заканчиваться действительным доменом или две буквы страны");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","Адрес электронной почты отсутствует имя хоста");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Укажите текст, отображаемый в приведенном выше коде проверки изображения. Этот текст в регистр.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","Указанный код проверки был неправильным");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","Пожалуйста, введите Ваше имя!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Пожалуйста, введите свой адрес!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Пожалуйста, введите Ваш город!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Пожалуйста, введите ваше государство!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Выберите страну!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Пожалуйста, введите Ваш адрес веб-сайта!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Пожалуйста введите пароль.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Пароли не совпадают.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Новый Рекламодатель: Регистрация, заполнив следующую форму");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Ваше имя");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Ваш адресс");
//City
define("SOFTBIZ_LC00011_SITEHOME","город");
//State
define("SOFTBIZ_LC00012_SITEHOME","состояние");
//Country
define("SOFTBIZ_LC00013_SITEHOME","Страна");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Выберите страну");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","ссылка на сайт");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Ваш адрес электронной почты");
//Password
define("SOFTBIZ_LC00017_SITEHOME","пароль");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","Подтвердите Пароль");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","Отправить");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Пожалуйста, укажите свой адрес электронной почты.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Пожалуйста, укажите пароль.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Существующие Рекламодатели: Вход здесь");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Войти в систему");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","Пароль должен быть зарегистрировано не менее% S символов.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","Рекламодатель Меню");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Главная");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Редактировать профиль");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Выйти");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","Мои объявления");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Добавить новое объявление");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Управление объявлениями");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Все текстовые объявления");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","Все баннеры");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Мой аккаунт");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Привет <класс шрифта = 'красный'> '% 1 $ S' </ FONT>, баланс Вашего счета% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Цветовая схема");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Пожалуйста, введите допустимое числовое значение для баннера #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Поиск Баннеры / Текст объявления");
//Keyword
define("SOFTBIZ_LC00002_ADS","Ключевое слово");
//Search in
define("SOFTBIZ_LC00003_ADS","Поиск в");
//Banner #
define("SOFTBIZ_LC00004_ADS","Баннер #");
//All
define("SOFTBIZ_LC00005_ADS","Все");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","Ожидание подтверждения");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Все размеры");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Тип объявления");
//All Packages
define("SOFTBIZ_LC00009_ADS","Все пакеты");
//Sort by
define("SOFTBIZ_LC00010_ADS","Сортировать по");
//Date Added
define("SOFTBIZ_LC00011_ADS","Дата Добавлена");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","Впечатления Приобретенные");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Срок годности");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","Впечатления Поступило");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","Щелчки Поступила");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","Впечатления слева");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","Щелчки левой");
//Days Left
define("SOFTBIZ_LC00018_ADS","Дни слева");
//Order
define("SOFTBIZ_LC00019_ADS","порядок");
//Ascending
define("SOFTBIZ_LC00020_ADS","Восходящий");
//Descending
define("SOFTBIZ_LC00021_ADS","нисходящий");
//Search
define("SOFTBIZ_LC00022_ADS","Поиск");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Соотношение кликов к показам");
//Status
define("SOFTBIZ_LC00024_ADS","Положение дел");
//Note
define("SOFTBIZ_LC00025_ADS","Заметка");
//Buy More
define("SOFTBIZ_LC00026_ADS","Купить больше");
//Edit
define("SOFTBIZ_LC00027_ADS","редактировать");
//Stats
define("SOFTBIZ_LC00028_ADS","Статистика");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","Ни одного объявления не удовлетворяют указанным критериям.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Результаты поиска объявлений для% S");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","Результаты поиска объявлений для объявления #% S");
//Banner
define("SOFTBIZ_LC00032_ADS","баннер");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Текст Тип объявления");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","Приобретенные Clicks");
//Expired
define("SOFTBIZ_LC00035_ADS","Истекший");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","Страница% s из% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Редактировать Banner Информация");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","URL назначения не требуется для типа флэш-баннеров. Адрес назначения должен включать HTTP: // WWW. например. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","Статистика");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Тип");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","опубликовано");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Пожалуйста, укажите ваш электронный идентификатор, чтобы восстановить свой пароль!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Ваш пароль по электронной почте");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","Электронная почта была отключена администратором, не удалось отправить пароль.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","Ни один член не найден такой электронный идентификатор!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Ваш профиль был обновлен");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Пополни процесс");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","Вы отменили добавить деньги на запрос PayPal.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Новый текст объявления размещены: щелчки");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Новый текст объявления размещены: Впечатления");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Новый текст объявления размещены: Месяцы");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","Расширенный текст объявления: Clicks");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","Расширенный текст объявления: Впечатления");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","Расширенный текст объявления: Месяцы");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Новый рекламный баннер размещен: щелчки");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Новый рекламный баннер размещен: Впечатления");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Новый рекламный баннер размещен: Месяцы");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","Расширенная рекламный баннер: Clicks");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","Расширенная баннер: Впечатления");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","Расширенная баннер: Месяцы");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","Деньги добавлены через 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","Деньги добавлены через PayPal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","чтобы перейти к рекламодателю домой.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","добавить новое объявление.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","для управления рекламы.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","чтобы добавить деньги на счет.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","для просмотра операций по счету.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","выйти из системы");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Обратите внимание, если ваш текст объявления не соответствует к редакционным правилам, ваше объявление может быть заблокирован");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Название не должно быть более 25 символов.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Пожалуйста, укажите description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 не должно быть более 35 символов.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Description2 не должно быть более 35 символов.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","информация о пакете");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Добавить содержание");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Пункт назначения адрес веб-сайта должен включает в себя HTTP: // WWW <br> например.. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Оплата были добавлены к вашей учетной записи");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Неверный доступ, отказано");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Ваш Пополни запрос принят. Средства будут очень скоро появятся в вашем аккаунте.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Статус загрузки файла изображения");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","Image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","КОНЕЦ");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Только .jpg / .png / .gif / .bmp / ​​.jpeg / .swf форматы файлов разрешены. <br> Пожалуйста, закройте это окно и попробуйте еще раз");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Загруженные файлы должны быть меньше, чем% SKB. Пожалуйста, закройте это окно и попробуйте еще раз");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Успех: Файл был загружен");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Ошибка: Размер файла больше чем 512000 байт");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Ошибка: Файл частично загружен");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Ошибка: Нет файла Загружено");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","Файл не может быть загружен, вероятно, из-за ограничений разрешения на каталог назначения");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Ошибка: Файл не загружен. Проверьте размер и повторите попытку.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Возвращаться");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Все права защищены.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Сообщение");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","для");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Новое объявление");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","У меня сложилось впечатление Объявления");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Нажмите объявлений на основе");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","Время связаны объявления");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Нажмите кнопку [Обзор], чтобы найти файл на вашем компьютере, а затем нажмите кнопку [Insert], чтобы загрузить его.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Образ");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Загрузить");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Пожалуйста, имейте терпение, вы не будете получать уведомления, пока файл не будет полностью передан.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Эта функция была отключена в демо-версии.");


?>