<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Please specify a title!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","Title above 25 character is not allowed!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Please specify a description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 above 35 character is not allowed!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Please specify a description2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Description2 above 35 character is not allowed!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Please specify display url!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Please Specify Destination URL!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Please upload a banner image.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Edit Text Ad Information");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Title");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","Editorial guidelines");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Title should not be more than 25 characters.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","Description 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","Description should not be more than 35 characters.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","Description 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","Display Url");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Display url should not be more than 35 characters.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","Destination Url");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","Destination address should include http://www. eg. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Update");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Your Banner will not be displayed until Admin approves the changes.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","Invalid Id, unable to continue");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","Unauthorised access, unable to continue");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Please specify valid email address");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","Email address seems incorrect (check @ and .'s)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","The username doesn't seem to be valid.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","Destination IP address is invalid!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","The domain name doesn't seem to be valid.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","The address must end in a valid domain, or two letter country.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","This address is missing a hostname!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Upload Image File");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Please choose a file to upload");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Please upload .gif/.jpg/.jpeg/.bmp/.png files only");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Please upload .swf files only");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Upload Image");
//To add an image, click the 'Browse' button &amp; select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","To add an image, click the 'Browse' button &amp; select the file, or type the path to the file in the Text-box below.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Then click Upload button to complete the process.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","NOTE");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","The file will be renamed if the file with the same name is already present");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Hit the [Browse] button to find the file on your computer.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Image");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Upload");

//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Choose Dates");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","From");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","Day");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Month");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Year");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","To");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Records Per Page");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","Show");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Add Money");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Amount");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Date");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Description");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","Transactions");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","No transaction found satisfying your criteria.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Your current balance is %s");
//Page %1\$s of %2\$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Page %1\$s of %2\$s<br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Purchase Package");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Package Type: Impressions Based");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Package Name");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","Impressions");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Price");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Price/Impression");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Size");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Package Type: Click Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","Clicks");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Price/Click");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Package Type: Time Based");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Duration");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Price/Month");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","Continue");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","There are no purchase packages defined by the admin.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","Months");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Invalid access, unable to continue");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","Banner Ad");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","Text Ad");
//Your %1\$s has been credited the requested %2\$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Your %1\$s has been credited the requested %2\$s.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Some error occured, please try again");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","Unauthorised access, denied");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","Text ad has been added successfully.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Some error occurred, please try again");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Your changes have been sent for admin approval");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","Inavlid access, unable to continue");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","Unable to update banner details, please try again");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Please choose correct banner type");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Add New Banner");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","Package Type");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","Banner Size");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Banner Type");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Image(.jpg/.gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash(.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","Destination URL");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","Banner Image");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Remove");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Impression");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Click");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","You must be logged to access this page!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Help for Text Ad posting");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Editorial Guidelines");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Please enter login information!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Welcome %s, you have successfully logged-in.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Please enter correct login information!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Buy More Impressions");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Buy Now");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","This process is irreversible, money once paid can't be refunded.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","There is no package available for this banner size.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","There is no package available for this text ad.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","Impressions Based");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Click Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","Time Based");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Banner Not Found. Click");
//here
define("SOFTBIZ_LC00009_BUY_MORE","here");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","to continue");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Ad Contents");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Add");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Cancel");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","NOTE:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Back");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Sorry, advertiser with the email %s already exists.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","You are successfully registerd with us");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Some Error Ocurred. Please Try Again!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","Pay");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Amount to be Added");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Current Balance");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Balance After Addition");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Add Money to account");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Added Money To Your Account");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Continue to Paypal Payment");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Continue to 2Checkout Payment");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Terms and Conditions");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","Offline");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","Through Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","Through 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","Password has been changed!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","Password could not be updated because your old password was incorrect");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Please specify a non-zero positive numeric value!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Add to my account");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Payment Method");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Pay Offline");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","add text ad");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","add banner");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","buy more duration");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","buy more clicks");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","buy more impressions");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","Your %s request has not been processed due to lack of funds.<br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","You need at least %s for chosen package.<br> Add some money to your account or choose some other package");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Please enter Current Password");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Change Password");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","Current Password");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","New Password");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Retype Password");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","Update Password");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","New Password must be atleast %s characters long");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Please enter New Password");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","Retyped password doesnot match the new Password");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","must be atleast %s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","character");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","characters");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Your banner has been updated");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Aggregate Banner Statistics For All Your Banners");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Total Number of Banners Posted");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","Approved");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","Disapproved");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Total Impressions Received");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Total Clicks Received");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Average Click Through Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Latest Impression");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Latest Click");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","Most Displayed Banner/Text Ad");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","Most Clicked Banner/Text Ad");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Stats: Clicks / Impressions");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Today");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Yesterday");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Last 7 Days");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Last 14 Days");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","Last Year");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","This Year: Clicks / Impressions");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","This Month: Clicks / Impressions");
//January
define("SOFTBIZ_LC00019_AD_HOME","January");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Febuary");
//March
define("SOFTBIZ_LC00021_AD_HOME","March");
//April
define("SOFTBIZ_LC00022_AD_HOME","April");
//May
define("SOFTBIZ_LC00023_AD_HOME","May");
//June
define("SOFTBIZ_LC00024_AD_HOME","June");
//July
define("SOFTBIZ_LC00025_AD_HOME","July");
//August
define("SOFTBIZ_LC00026_AD_HOME","August");
//September
define("SOFTBIZ_LC00027_AD_HOME","September");
//October
define("SOFTBIZ_LC00028_AD_HOME","October");
//November
define("SOFTBIZ_LC00029_AD_HOME","November");
//December
define("SOFTBIZ_LC00030_AD_HOME","December");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Banner has been added successfully.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","Your add banner request has not been processed due to lack of funds. Add some money to your account and try again");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Ad Types");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Choose Ad Type");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Invalid e-mail address.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Please specify validation code");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Forgot Password");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Please provide your email id. We will send your password in email .");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","Email ID");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Validation Code");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Send Request");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","The username in the email address seems invalid");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","Destination IP in the email address is invalid");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","The domain name in the email address seems invalid");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","The email address must end in a valid domain or two letter country");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","Email address is missing a hostname");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Specify the text displayed in the above validation code image. This text is case in-sensitive.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","Specified validation code was incorrect");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","Please Enter Your Name!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Please Enter Your Address!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Please Enter Your City!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Please Enter Your State!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Please Choose a Country!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Please Enter Your Website URL!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Please Enter Password.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","Passwords do not match.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","New Advertiser: Signup by filling following form");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Your Name");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Your Address");
//City
define("SOFTBIZ_LC00011_SITEHOME","City");
//State
define("SOFTBIZ_LC00012_SITEHOME","State");
//Country
define("SOFTBIZ_LC00013_SITEHOME","Country");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Select a Country");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","Website URL");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Your Email");
//Password
define("SOFTBIZ_LC00017_SITEHOME","Password");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","Confirm Password");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","Submit");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Please specify your email address.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Please specify password.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Existing Advertisers: Login here");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Sign In");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","Password must be atleast %s characters long.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","Advertiser Menu");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Home");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Edit Profile");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Logout");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","My Ads");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Add New Ad");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Manage Ads");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","All Text Ads");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","All Banners");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","My Account");
//Hi <font class='red'>'%1\$s'</font>, Your account balance is %2\$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Hi <font class='red'>'%1\$s'</font>, Your account balance is %2\$s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Color Scheme");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Please Enter a valid numeric value for Banner #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Search Banners/Text Ad");
//Keyword
define("SOFTBIZ_LC00002_ADS","Keyword");
//Search in
define("SOFTBIZ_LC00003_ADS","Search in");
//Banner #
define("SOFTBIZ_LC00004_ADS","Banner #");
//All
define("SOFTBIZ_LC00005_ADS","All");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","Waiting for Approval");
//All Sizes
define("SOFTBIZ_LC00007_ADS","All Sizes");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Ad Type");
//All Packages
define("SOFTBIZ_LC00009_ADS","All Packages");
//Sort by
define("SOFTBIZ_LC00010_ADS","Sort by");
//Date Added
define("SOFTBIZ_LC00011_ADS","Date Added");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","Impressions Purchased");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Expiry Date");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","Impressions Received");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","Clicks Received");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","Impressions Left");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","Clicks Left");
//Days Left
define("SOFTBIZ_LC00018_ADS","Days Left");
//Order
define("SOFTBIZ_LC00019_ADS","Order");
//Ascending
define("SOFTBIZ_LC00020_ADS","Ascending");
//Descending
define("SOFTBIZ_LC00021_ADS","Descending");
//Search
define("SOFTBIZ_LC00022_ADS","Search");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Click through Rate");
//Status
define("SOFTBIZ_LC00024_ADS","Status");
//Note
define("SOFTBIZ_LC00025_ADS","Note");
//Buy More
define("SOFTBIZ_LC00026_ADS","Buy More");
//Edit
define("SOFTBIZ_LC00027_ADS","Edit");
//Stats
define("SOFTBIZ_LC00028_ADS","Stats");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","No Ad satisfy the criteria you specified.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","Ad search results for %s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","Ad search results for Ad # %s");
//Banner
define("SOFTBIZ_LC00032_ADS","Banner");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Text Ad Type");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","Clicks Purchased");
//Expired
define("SOFTBIZ_LC00035_ADS","Expired");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","Page %s of %s<br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Edit Banner Information");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","Statistics");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Type");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","Posted on");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Please provide your email id to retrieve your password!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Your password has been e-mailed");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","Email has been disabled by admin, unable to send your password.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","No Member found with such email id!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Your profile has been updated");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Add Money Process");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","You have cancelled your Add Money Request at paypal.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","New Text ad posted : Clicks");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","New Text ad posted : Impressions");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","New Text ad posted : Months");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","Extended text ad : Clicks");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","Extended text ad : Impressions");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","Extended text ad : Months");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","New Banner ad posted : Clicks");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","New Banner ad posted : Impressions");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","New Banner ad posted : Months");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","Extended banner ad : Clicks");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","Extended banner ad : Impressions");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","Extended banner ad : Months");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","Money added through 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","Money added through paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","to go to advertiser home.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","to add new advertisement.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","to manage your advertisements.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","to add money to the account.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","to view account transactions.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","to logout");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Title should not be more than 25 characters.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Please specify a description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Description1 should not be more than 35 characters.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Description2 should not be more than 35 characters.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","Package Information");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Add Contents");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Payment have been added to your account");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Invalid access, denied");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Your Add Money Request has been accepted. Funds will very soon appear in your account.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Upload Image File Status");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","Image Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","FINISH");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Uploaded files must be less than %skB. Please close this window and try again");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Success : File has been uploaded");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Error : File size more than 512000 bytes");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Error : File partially uploaded");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Error : No File Uploaded");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","File could not be uploaded probably due to permission restrictions on destination directory");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Error : File Not Uploaded. Check Size & Try Again.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Go Back");


define("SOFTBIZ_LCUPDT2015111000000_10","Copyright &copy; 2003 -" . date("Y") . ". All Rights Reserved.");

define("SOFTBIZ_LCUPDT2015111000000_11","Message" );
define("SOFTBIZ_LCUPDT2015111000000_12","for" );

define("SOFTBIZ_LCUPDT2015111000000_13","Post New Ad" );
define("SOFTBIZ_LCUPDT2015111000000_14","My Impression Ads" );
define("SOFTBIZ_LCUPDT2015111000000_15","Click Based Ads" );
define("SOFTBIZ_LCUPDT2015111000000_16","Time bound Ads" );

//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00013_FILEUPLOAD","Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Image");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Upload");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Please have patience, you will not receive any notification until the file is completely transferred.");
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI", "This feature has been disabled in the demo.");
?>