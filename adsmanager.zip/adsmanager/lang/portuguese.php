<?php
/*

======================================
LANGUAGE FILE TRANSLATION HELP
======================================



The phrases have been defined using following syntax

define("UNIQUE_CONSTANT_NAME","PHRASE IN RESPECTIVE LANGUAGE");

This entry should be there in each language file with UNIQUE_CONSTANT_NAME same in all files but unique within the file and "PHRASE IN RESPECTIVE LANGUAGE" will be the translation in appropriate language.

To write a new phrase the above entry should be used as such only UNIQUE_CONSTANT_NAME and PHRASE IN RESPECTIVE LANGUAGE strings are changable, rest whole sentence cannot be altered.
===================
===================
The following conversion specifiers are recognized in the Date/time format string: 

%a - abbreviated weekday name
%A - full weekday name 
%b - abbreviated month name 
%B - full month name 
%c - preferred date and time representation 
%C - century number (range 00 to 99) 
%d - day of the month as a decimal number (range 01 to 31) 
%D - same as %m/%d/%y 
%e - day of the month as a decimal number (range 1 to 31) 
%g - like %G, but without the century.
%h - same as %b 
%H - hour as a decimal number using a 24-hour clock (range 00 to 23) 
%I - hour as a decimal number using a 12-hour clock (range 01 to 12) 
%j - day of the year as a decimal number (range 001 to 366) 
%m - month as a decimal number (range 01 to 12) 
%M - minute as a decimal number 
%n - newline character 
%p - either `am` or `pm` according to the given time value 
%r - time in a.m. and p.m. notation 
%R - time in 24 hour notation 
%S - second as a decimal number 
%t - tab character 
%T - current time, equal to %H:%M:%S 
%U - week number of the current year as a decimal number, starting with the first Sunday as the first day of the first week 
%W - week number of the current year as a decimal number, starting with the first Monday as the first day of the first week 
%w - day of the week as a decimal, Sunday being 0 
%x - preferred date representation without the time 
%X - preferred time representation without the date 
%y - year as a decimal number without a century (range 00 to 99) 
%Y - year as a decimal number including the century 
%Z - time zone or name or abbreviation 
%% - a literal `%` character 

NOTE: 
Not all conversion specifiers may be supported by your C library. This means that e.g. %e, %T, %D etc. might not work on Windows Servers. 
===================
===================
NOTE:
Some strings below contain special words preceeding with % (percentage character e.g.  %s, %1\$s, %2\$s, %d, %f etc.). These are placeholders and will be replaced at run time with appropriate values. So, these must not be removed from the strings.  
%1\$s, %2\$s, %3\$s and so on are special forms of %s and will help in parameter swpping if needed by some language to reformat the sentance, without changing the meaning. 
e.g. Suppose you want to change the following sentance 
		"Welcome %s, your account balance is %s"
to
 		"You have %s in your account %s"

At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		"You have Alex in your account $15.34" 
which is wrong.

Now reconsider these with slight modification to the placeholders to original and your purposed sentances
		"Welcome %1\$s, your account balance is %2\$s" 
to
		"You have %2\$s in your account %1\$s"
		
At run time when placeholders have "Alex" and "$15.34" values respectively the old output would be
		"Welcome Alex, your account balance is $15.34"
and new output will be
		 "You have $15.34 in your account Alex"
=============================================
LANGUAGE FILE TRANSLATION HELP SECTION ENDS 
=============================================
*/
define("SBCHAR_ENCODING","utf-8");
define("SBLANG_LANG","en");
define("SBLOCALE_SETTING","en_US");
define("SBDATE_FORMAT","%x");
define("SBTIME_FORMAT","%X");
define("SBLANG_DIR","ltr");

//Please specify a title!
define("SOFTBIZ_LC00000_EDIT_TEXTAD","Por favor especificar um título!");
//Title above 25 character is not allowed!
define("SOFTBIZ_LC00001_EDIT_TEXTAD","O título acima de 25 caracteres não é permitido!");
//Please specify a description1
define("SOFTBIZ_LC00002_EDIT_TEXTAD","Por favor especificar um description1");
//Description1 above 35 character is not allowed!
define("SOFTBIZ_LC00003_EDIT_TEXTAD","Description1 acima de 35 caracteres não é permitido!");
//Please specify a description2!
define("SOFTBIZ_LC00004_EDIT_TEXTAD","Por favor especificar um description2!");
//Description2 above 35 character is not allowed!
define("SOFTBIZ_LC00005_EDIT_TEXTAD","Description2 acima de 35 caracteres não é permitido!");
//Please specify display url!
define("SOFTBIZ_LC00006_EDIT_TEXTAD","Por favor, especifique exibição url!");
//Please Specify Destination URL!
define("SOFTBIZ_LC00007_EDIT_TEXTAD","Por favor, especifique o URL de destino!");
//Please upload a banner image.
define("SOFTBIZ_LC00008_EDIT_TEXTAD","Faça o upload de uma imagem de banner.");
//Edit Text Ad Information
define("SOFTBIZ_LC00009_EDIT_TEXTAD","Editar informações de texto do anúncio");
//Title
define("SOFTBIZ_LC00010_EDIT_TEXTAD","Título");
//Editorial guidelines
define("SOFTBIZ_LC00011_EDIT_TEXTAD","diretrizes editoriais");
//Title should not be more than 25 characters.
define("SOFTBIZ_LC00012_EDIT_TEXTAD","Título não deve ser superior a 25 caracteres.");
//Description 1
define("SOFTBIZ_LC00013_EDIT_TEXTAD","Descrição 1");
//Description should not be more than 35 characters.
define("SOFTBIZ_LC00014_EDIT_TEXTAD","A descrição não deve ser superior a 35 caracteres.");
//Description 2
define("SOFTBIZ_LC00015_EDIT_TEXTAD","Descrição 2");
//Display Url
define("SOFTBIZ_LC00016_EDIT_TEXTAD","Mostrar o URL");
//Display url should not be more than 35 characters.
define("SOFTBIZ_LC00017_EDIT_TEXTAD","Mostrar o URL, não deve ter mais que 35 caracteres.");
//Destination Url
define("SOFTBIZ_LC00018_EDIT_TEXTAD","URL de destino");
//Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00019_EDIT_TEXTAD","endereço de destino deve incluir http: // www. por exemplo. http://www.softbizscripts.com");
//Update
define("SOFTBIZ_LC00020_EDIT_TEXTAD","Atualizar");
//Your Banner will not be displayed until Admin approves the changes.
define("SOFTBIZ_LC00021_EDIT_TEXTAD","Sua bandeira não será exibida até administração aprova as alterações.");
//Invalid Id, unable to continue
define("SOFTBIZ_LC00022_EDIT_TEXTAD","ID inválida, incapaz de continuar");
//Unauthorised access, unable to continue
define("SOFTBIZ_LC00023_EDIT_TEXTAD","O acesso não autorizado, incapaz de continuar");
//Please specify valid email address
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS_JS","Por favor, especifique o endereço de e-mail válido");
//Email address seems incorrect (check @ and .'s)
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS_JS","endereço de e-mail parece incorreta (cheque @ e da.)");
//The username doesn't seem to be valid.
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS_JS","O nome de usuário não parece ser válido.");
//Destination IP address is invalid!
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS_JS","endereço IP de destino é inválido!");
//The domain name doesn't seem to be valid.
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS_JS","O nome de domínio não parece ser válido.");
//The address must end in a valid domain, or two letter country.
define("SOFTBIZ_LC00005_SOFTBIZ_FUNCTIONS_JS","O endereço deve terminar em um domínio válido, ou duas letras do país.");
//This address is missing a hostname!
define("SOFTBIZ_LC00006_SOFTBIZ_FUNCTIONS_JS","Este endereço está faltando um hostname!");
//Upload Image File
define("SOFTBIZ_LC00000_FILEUPLOAD","Faça o upload do arquivo de imagem");
//Please choose a file to upload
define("SOFTBIZ_LC00001_FILEUPLOAD","Por favor, escolha um arquivo para carregar");
//Please upload .gif/.jpg/.jpeg/.bmp/.png files only
define("SOFTBIZ_LC00002_FILEUPLOAD","Faça o upload de .gif / .jpg / .jpeg / .bmp / ​​.png apenas arquivos");
//Please upload .swf files only
define("SOFTBIZ_LC00003_FILEUPLOAD","Faça o upload de arquivos .swf única");
//Upload Image
define("SOFTBIZ_LC00004_FILEUPLOAD","Carregar imagem");
//To add an image, click the 'Browse' button & select the file, or type the path to the file in the Text-box below.
define("SOFTBIZ_LC00005_FILEUPLOAD","Para adicionar uma imagem, clique no botão \"Procurar\" e selecione o arquivo ou digite o caminho para o arquivo na caixa de texto a seguir.");
//Then click Upload button to complete the process.
define("SOFTBIZ_LC00006_FILEUPLOAD","Em seguida, clique no botão Enviar para concluir o processo.");
//NOTE
define("SOFTBIZ_LC00007_FILEUPLOAD","NOTA");
//The file transfer can take from a few seconds to a few minutes depending on the size of the file. Please have patience while the file is being uploaded.
define("SOFTBIZ_LC00008_FILEUPLOAD","A transferência do ficheiro pode levar de alguns segundos a alguns minutos, dependendo do tamanho do ficheiro. Por favor, tenham paciência enquanto o arquivo está sendo carregado.");
//The file will be renamed if the file with the same name is already present
define("SOFTBIZ_LC00009_FILEUPLOAD","O arquivo será renomeado se o arquivo com o mesmo nome já está presente");
//Hit the [Browse] button to find the file on your computer.
define("SOFTBIZ_LC00010_FILEUPLOAD","Aperte o botão [Procurar] para localizar o arquivo no seu computador.");
//Image
define("SOFTBIZ_LC00011_FILEUPLOAD","Imagem");
//Upload
define("SOFTBIZ_LC00012_FILEUPLOAD","Envio");
//Choose Dates
define("SOFTBIZ_LC00000_MYACCOUNT","Escolha as datas");
//From
define("SOFTBIZ_LC00001_MYACCOUNT","A partir de");
//Day
define("SOFTBIZ_LC00002_MYACCOUNT","Dia");
//Month
define("SOFTBIZ_LC00003_MYACCOUNT","Mês");
//Year
define("SOFTBIZ_LC00004_MYACCOUNT","Ano");
//To
define("SOFTBIZ_LC00005_MYACCOUNT","Para");
//Records Per Page
define("SOFTBIZ_LC00006_MYACCOUNT","Registros por página");
//Show
define("SOFTBIZ_LC00007_MYACCOUNT","exposição");
//Add Money
define("SOFTBIZ_LC00008_MYACCOUNT","Adicionar dinheiro");
//Amount
define("SOFTBIZ_LC00009_MYACCOUNT","Quantidade");
//Date
define("SOFTBIZ_LC00010_MYACCOUNT","Encontro");
//Description
define("SOFTBIZ_LC00011_MYACCOUNT","Descrição");
//Transactions
define("SOFTBIZ_LC00012_MYACCOUNT","transações");
//No transaction found satisfying your criteria.
define("SOFTBIZ_LC00013_MYACCOUNT","Nenhuma transação encontrado satisfaçam os seus critérios.");
//Your current balance is %s
define("SOFTBIZ_LC00014_MYACCOUNT","Seu saldo atual é% s");
//Page %1$s of %2$s<br>
define("SOFTBIZ_LC00015_MYACCOUNT","Página% 1 $ s de% 2 $ s <br>");
//Purchase Package
define("SOFTBIZ_LC00000_CHOOSE_TYPE","Pacote compra");
//Package Type: Impressions Based
define("SOFTBIZ_LC00001_CHOOSE_TYPE","Tipo de embalagem: Impressions Based");
//Package Name
define("SOFTBIZ_LC00002_CHOOSE_TYPE","Nome do pacote");
//Impressions
define("SOFTBIZ_LC00003_CHOOSE_TYPE","impressões");
//Price
define("SOFTBIZ_LC00004_CHOOSE_TYPE","Preço");
//Price/Impression
define("SOFTBIZ_LC00005_CHOOSE_TYPE","Preço / Impression");
//Size
define("SOFTBIZ_LC00006_CHOOSE_TYPE","Tamanho");
//px
define("SOFTBIZ_LC00007_CHOOSE_TYPE","px");
//Package Type: Click Based
define("SOFTBIZ_LC00008_CHOOSE_TYPE","Tipo de embalagem: Clique Based");
//Clicks
define("SOFTBIZ_LC00009_CHOOSE_TYPE","cliques");
//Price/Click
define("SOFTBIZ_LC00010_CHOOSE_TYPE","Preço / Click");
//Package Type: Time Based
define("SOFTBIZ_LC00011_CHOOSE_TYPE","Tipo de embalagem: Tempo Based");
//Duration
define("SOFTBIZ_LC00012_CHOOSE_TYPE","Duração");
//Price/Month
define("SOFTBIZ_LC00013_CHOOSE_TYPE","Preço / mês");
//Continue
define("SOFTBIZ_LC00014_CHOOSE_TYPE","Continuar");
//There are no purchase packages defined by the admin.
define("SOFTBIZ_LC00015_CHOOSE_TYPE","Não há pacotes de compra definidos pelo administrador.");
//Months
define("SOFTBIZ_LC00016_CHOOSE_TYPE","meses");
//Invalid access, unable to continue
define("SOFTBIZ_LC00000_UPDATE_IMPRESSIONS","Acesso inválido, incapaz de continuar");
//Banner Ad
define("SOFTBIZ_LC00001_UPDATE_IMPRESSIONS","banner Ad");
//Text Ad
define("SOFTBIZ_LC00002_UPDATE_IMPRESSIONS","anúncio de texto");
//Your %1$s has been credited the requested %2$s.
define("SOFTBIZ_LC00003_UPDATE_IMPRESSIONS","Seu% 1 $ s foi creditado os solicitados% 2 $ s.");
//Some error occured, please try again
define("SOFTBIZ_LC00004_UPDATE_IMPRESSIONS","Ocorreu algum erro, por favor, tente novamente");
//Unauthorised access, denied
define("SOFTBIZ_LC00000_INSERT_TEXTAD","O acesso não autorizado, negado");
//Text ad has been added successfully. Your Text ad will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00001_INSERT_TEXTAD","Anúncio de texto foi adicionada com sucesso. Seu anúncio de texto aparecerá em nosso banner rotator, logo que ele será aprovado.");
//Text ad has been added successfully.
define("SOFTBIZ_LC00002_INSERT_TEXTAD","Anúncio de texto foi adicionada com sucesso.");
//Your add text ad request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00003_INSERT_TEXTAD","O suplemento solicitação de anúncio de texto não foi processado devido à falta de fundos. Adicione um pouco de dinheiro para sua conta e tente novamente");
//Some error occurred, please try again
define("SOFTBIZ_LC00004_INSERT_TEXTAD","Algum erro ocorreu, por favor, tente novamente");
//Your changes have been sent for admin approval
define("SOFTBIZ_LC00000_UPDATE_TEXTAD","Suas alterações foram enviadas para aprovação do administrador");
//Inavlid access, unable to continue
define("SOFTBIZ_LC00001_UPDATE_TEXTAD","Acesso Inavlid, incapaz de continuar");
//Unable to update banner details, please try again
define("SOFTBIZ_LC00002_UPDATE_TEXTAD","Não é possível atualizar detalhes de banner, por favor, tente novamente");
//Please choose correct banner type
define("SOFTBIZ_LC00000_ADVERTISE","Escolha por favor tipo bandeira correta");
//Add New Banner
define("SOFTBIZ_LC00001_ADVERTISE","Adicionar Novo Banner");
//Package Type
define("SOFTBIZ_LC00002_ADVERTISE","Tipo de embalagem");
//Banner Size
define("SOFTBIZ_LC00003_ADVERTISE","bandeira Tamanho");
//Banner Type
define("SOFTBIZ_LC00004_ADVERTISE","Tipo bandeira");
//Image(.jpg/.gif)
define("SOFTBIZ_LC00005_ADVERTISE","Imagem (.jpg / .gif)");
//Flash(.swf)
define("SOFTBIZ_LC00006_ADVERTISE","Flash (.swf)");
//Destination URL
define("SOFTBIZ_LC00007_ADVERTISE","URL de destino");
//Destination Url not required for flash banner type. Destination website address should includes http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00008_ADVERTISE","URL de destino não é necessário para o tipo de flash banner. Destino endereço do site deveriam inclui http: // www. por exemplo. http://www.softbizscripts.com");
//Banner Image
define("SOFTBIZ_LC00009_ADVERTISE","banner Image");
//Remove
define("SOFTBIZ_LC00010_ADVERTISE","Remover");
//Impression
define("SOFTBIZ_LC00011_ADVERTISE","Impressão");
//Click
define("SOFTBIZ_LC00012_ADVERTISE","Clique");
//You must be logged to access this page!
define("SOFTBIZ_LC00000_LOGINCHECK","Você precisa estar logado para acessar esta página!");
//Help for Text Ad posting
define("SOFTBIZ_LC00000_TEXTADHELP","Ajuda para Texto postagem de anúncios");
//Editorial Guidelines
define("SOFTBIZ_LC00001_TEXTADHELP","Diretrizes editoriais");
//Please enter login information!
define("SOFTBIZ_LC00000_LOGIN","Por favor insira as informações de login!");
//Welcome %s, you have successfully logged-in.
define("SOFTBIZ_LC00001_LOGIN","Bem-vindo% s, que fizer o login com sucesso.");
//Please enter correct login information!
define("SOFTBIZ_LC00002_LOGIN","Por favor insira as informações de login corretas!");
//Buy More Impressions
define("SOFTBIZ_LC00000_BUY_MORE","Comprar mais Impressions");
//Buy Now
define("SOFTBIZ_LC00001_BUY_MORE","Compre agora");
//This process is irreversible, money once paid can't be refunded.
define("SOFTBIZ_LC00002_BUY_MORE","Este processo é irreversível, dinheiro, uma vez pago não pode ser reembolsado.");
//There is no package available for this banner size.
define("SOFTBIZ_LC00003_BUY_MORE","Não há nenhum pacote disponível para esse tamanho de banner.");
//There is no package available for this text ad.
define("SOFTBIZ_LC00004_BUY_MORE","Não há nenhum pacote disponível para este anúncio de texto.");
//Impressions Based
define("SOFTBIZ_LC00005_BUY_MORE","Baseado impressões");
//Click Based
define("SOFTBIZ_LC00006_BUY_MORE","Clique Based");
//Time Based
define("SOFTBIZ_LC00007_BUY_MORE","tempo Based");
//Banner Not Found. Click
define("SOFTBIZ_LC00008_BUY_MORE","Bandeira não encontrado. Clique");
//here
define("SOFTBIZ_LC00009_BUY_MORE","Aqui");
//to continue
define("SOFTBIZ_LC00010_BUY_MORE","continuar");
//Ad Contents
define("SOFTBIZ_LC00000_CONFIRM_TEXTAD","Índice de anúncios");
//Add
define("SOFTBIZ_LC00001_CONFIRM_TEXTAD","Adicionar");
//Cancel
define("SOFTBIZ_LC00002_CONFIRM_TEXTAD","Cancelar");
//NOTE:
define("SOFTBIZ_LC00003_CONFIRM_TEXTAD","NOTA:");
//Back
define("SOFTBIZ_LC00000_INSERTMEMBER","Costas");
//Sorry, advertiser with the email %s already exists.
define("SOFTBIZ_LC00001_INSERTMEMBER","Desculpe, anunciante com o e-mail% s já existe.");
//You are successfully registerd with us
define("SOFTBIZ_LC00002_INSERTMEMBER","Você está registerd com sucesso com a gente");
//Some Error Ocurred. Please Try Again!
define("SOFTBIZ_LC00003_INSERTMEMBER","Alguns erro ocorreu. Por favor, tente novamente!");
//Pay
define("SOFTBIZ_LC00000_INSERT_MONEY","Pagamento");
//Amount to be Added
define("SOFTBIZ_LC00001_INSERT_MONEY","Quantidade a ser adicionada");
//Current Balance
define("SOFTBIZ_LC00002_INSERT_MONEY","Saldo atual");
//Balance After Addition
define("SOFTBIZ_LC00003_INSERT_MONEY","Balanço após a adição");
//Add Money to account
define("SOFTBIZ_LC00004_INSERT_MONEY","Adicionar dinheiro para a conta");
//Added Money To Your Account
define("SOFTBIZ_LC00005_INSERT_MONEY","Adicionado dinheiro para sua conta");
//Continue to Paypal Payment
define("SOFTBIZ_LC00006_INSERT_MONEY","Continue a pagamento de Paypal");
//Continue to 2Checkout Payment
define("SOFTBIZ_LC00007_INSERT_MONEY","Continue a 2Checkout pagamento");
//Terms and Conditions
define("SOFTBIZ_LC00008_INSERT_MONEY","Termos e Condições");
//Offline
define("SOFTBIZ_LC00009_INSERT_MONEY","off-line");
//Through Paypal
define("SOFTBIZ_LC00010_INSERT_MONEY","através do Paypal");
//Through 2Checkout
define("SOFTBIZ_LC00011_INSERT_MONEY","através 2Checkout");
//Password has been changed!
define("SOFTBIZ_LC00000_UPDATEPASSWORD","A senha foi alterada!");
//Password could not be updated because your old password was incorrect
define("SOFTBIZ_LC00001_UPDATEPASSWORD","A senha não pôde ser atualizado porque a senha antiga estava incorreta");
//Please specify a non-zero positive numeric value!
define("SOFTBIZ_LC00000_ADDMONEY","Por favor especificar um valor numérico positivo diferente de zero!");
//Add to my account
define("SOFTBIZ_LC00001_ADDMONEY","Adicionar à minha conta");
//Payment Method
define("SOFTBIZ_LC00002_ADDMONEY","Método de pagamento");
//PayPal
define("SOFTBIZ_LC00003_ADDMONEY","PayPal");
//2Checkout
define("SOFTBIZ_LC00004_ADDMONEY","2Checkout");
//Pay Offline
define("SOFTBIZ_LC00005_ADDMONEY","Pay off-line");
//add text ad
define("SOFTBIZ_LC00006_ADDMONEY","Adicionar anúncio de texto");
//add banner
define("SOFTBIZ_LC00007_ADDMONEY","a bandeira adiciona");
//buy more duration
define("SOFTBIZ_LC00008_ADDMONEY","comprar mais de duração");
//buy more clicks
define("SOFTBIZ_LC00009_ADDMONEY","comprar mais cliques");
//buy more impressions
define("SOFTBIZ_LC00010_ADDMONEY","comprar mais impressões");
//Your %s request has not been processed due to lack of funds.<br>
define("SOFTBIZ_LC00011_ADDMONEY","pedido a sua% s não foi processado devido à falta de fundos. <br>");
//You need at least %s for chosen package.<br> Add some money to your account or choose some other package
define("SOFTBIZ_LC00012_ADDMONEY","Você precisa de pelo menos% s para o pacote escolhido. <br> Adicione um pouco de dinheiro para a sua conta ou escolher algum outro pacote");
//Please enter Current Password
define("SOFTBIZ_LC00000_CHANGEPASSWORD","Digite a senha atual");
//Change Password
define("SOFTBIZ_LC00001_CHANGEPASSWORD","Mudar senha");
//Current Password
define("SOFTBIZ_LC00002_CHANGEPASSWORD","senha atual");
//New Password
define("SOFTBIZ_LC00003_CHANGEPASSWORD","Nova senha");
//Retype Password
define("SOFTBIZ_LC00004_CHANGEPASSWORD","Redigite a senha");
//Update Password
define("SOFTBIZ_LC00005_CHANGEPASSWORD","atualização de senha");
//New Password must be atleast %s characters long
define("SOFTBIZ_LC00006_CHANGEPASSWORD","Nova senha deve ser pelo menos% s caracteres");
//Please enter New Password
define("SOFTBIZ_LC00007_CHANGEPASSWORD","Por favor, indique nova senha");
//Retyped password doesnot match the new Password
define("SOFTBIZ_LC00008_CHANGEPASSWORD","password retyped doesnot coincide com a nova senha");
//must be atleast %s
define("SOFTBIZ_LC00009_CHANGEPASSWORD","deve ser pelo menos% s");
//character
define("SOFTBIZ_LC00010_CHANGEPASSWORD","personagem");
//characters
define("SOFTBIZ_LC00011_CHANGEPASSWORD","personagens");
//Your banner has been updated
define("SOFTBIZ_LC00000_UPDATE_BANNER","Sua bandeira foi atualizado");
//Aggregate Banner Statistics For All Your Banners
define("SOFTBIZ_LC00000_AD_HOME","Estatísticas da bandeira agregados para todos os seus Banners");
//Total Number of Banners Posted
define("SOFTBIZ_LC00001_AD_HOME","Número Total de Banners Publicado");
//Approved
define("SOFTBIZ_LC00002_AD_HOME","aprovado");
//Disapproved
define("SOFTBIZ_LC00003_AD_HOME","reprovado");
//Total Impressions Received
define("SOFTBIZ_LC00004_AD_HOME","Total de impressões recebidas");
//Total Clicks Received
define("SOFTBIZ_LC00005_AD_HOME","Total de cliques recebidos");
//Average Click Through Rate
define("SOFTBIZ_LC00006_AD_HOME","Média Click Through Rate");
//Latest Impression
define("SOFTBIZ_LC00007_AD_HOME","Últimas Impression");
//Latest Click
define("SOFTBIZ_LC00008_AD_HOME","Últimas Click");
//Most Displayed Banner/Text Ad
define("SOFTBIZ_LC00009_AD_HOME","A maioria Exibido Bandeira / anúncio de texto");
//Most Clicked Banner/Text Ad
define("SOFTBIZ_LC00010_AD_HOME","Mais clicado Banner Ad / Texto");
//Stats: Clicks / Impressions
define("SOFTBIZ_LC00011_AD_HOME","Estatísticas: Cliques / Impressões");
//Today
define("SOFTBIZ_LC00012_AD_HOME","Hoje");
//Yesterday
define("SOFTBIZ_LC00013_AD_HOME","Ontem");
//Last 7 Days
define("SOFTBIZ_LC00014_AD_HOME","Nos últimos 7 dias");
//Last 14 Days
define("SOFTBIZ_LC00015_AD_HOME","Nos últimos 14 dias");
//Last Year
define("SOFTBIZ_LC00016_AD_HOME","Ano passado");
//This Year: Clicks / Impressions
define("SOFTBIZ_LC00017_AD_HOME","Este Ano: Cliques / Impressões");
//This Month: Clicks / Impressions
define("SOFTBIZ_LC00018_AD_HOME","Este mês: Cliques / Impressões");
//January
define("SOFTBIZ_LC00019_AD_HOME","janeiro");
//Febuary
define("SOFTBIZ_LC00020_AD_HOME","Febuary");
//March
define("SOFTBIZ_LC00021_AD_HOME","marcha");
//April
define("SOFTBIZ_LC00022_AD_HOME","abril");
//May
define("SOFTBIZ_LC00023_AD_HOME","Pode");
//June
define("SOFTBIZ_LC00024_AD_HOME","Junho");
//July
define("SOFTBIZ_LC00025_AD_HOME","julho");
//August
define("SOFTBIZ_LC00026_AD_HOME","agosto");
//September
define("SOFTBIZ_LC00027_AD_HOME","setembro");
//October
define("SOFTBIZ_LC00028_AD_HOME","Outubro");
//November
define("SOFTBIZ_LC00029_AD_HOME","novembro");
//December
define("SOFTBIZ_LC00030_AD_HOME","dezembro");
//Banner has been added successfully. Your Banner will appear in our banner rotator as soon as it will be approved.
define("SOFTBIZ_LC00000_INSERT_BANNER","Bandeira foi adicionado com sucesso. Seu banner aparecerá no nosso banner rotator, logo que ele será aprovado.");
//Banner has been added successfully.
define("SOFTBIZ_LC00001_INSERT_BANNER","Bandeira foi adicionado com sucesso.");
//Your add banner request has not been processed due to lack of funds. Add some money to your account and try again
define("SOFTBIZ_LC00002_INSERT_BANNER","Seu pedido adicionam a bandeira não foi processado devido à falta de fundos. Adicione um pouco de dinheiro para sua conta e tente novamente");
//Ad Types
define("SOFTBIZ_LC00000_CHOOSE_BANNER","Tipos de anúncios");
//Choose Ad Type
define("SOFTBIZ_LC00001_CHOOSE_BANNER","Escolha Tipo de anúncio");
//Invalid e-mail address.
define("SOFTBIZ_LC00000_LOSTPASSWORD","Endereço de email invalido.");
//Please specify validation code
define("SOFTBIZ_LC00001_LOSTPASSWORD","Por favor, especifique o código de validação");
//Forgot Password
define("SOFTBIZ_LC00002_LOSTPASSWORD","Esqueceu a senha");
//Please provide your email id. We will send your password in email .
define("SOFTBIZ_LC00003_LOSTPASSWORD","Por favor, forneça o seu ID e-mail. Vamos enviar sua senha no e-mail.");
//Email ID
define("SOFTBIZ_LC00004_LOSTPASSWORD","Identificação do email");
//Validation Code
define("SOFTBIZ_LC00005_LOSTPASSWORD","Código de validação");
//Send Request
define("SOFTBIZ_LC00006_LOSTPASSWORD","Enviar pedido");
//The username in the email address seems invalid
define("SOFTBIZ_LC00000_SOFTBIZ_FUNCTIONS","O nome de usuário no endereço de e-mail parece inválido");
//Destination IP in the email address is invalid
define("SOFTBIZ_LC00001_SOFTBIZ_FUNCTIONS","IP de destino no endereço de e-mail é inválido");
//The domain name in the email address seems invalid
define("SOFTBIZ_LC00002_SOFTBIZ_FUNCTIONS","O nome de domínio no endereço de e-mail parece inválido");
//The email address must end in a valid domain or two letter country
define("SOFTBIZ_LC00003_SOFTBIZ_FUNCTIONS","O endereço de e-mail deve terminar em um domínio válido ou duas letras do país");
//Email address is missing a hostname
define("SOFTBIZ_LC00004_SOFTBIZ_FUNCTIONS","endereço de e-mail está faltando um hostname");
//Specify the text displayed in the above validation code image. This text is case in-sensitive.
define("SOFTBIZ_LC00000_CHECK_IMAGE","Especifique o texto exibido na imagem do código de validação acima. Este texto é caso-sensível.");
//Specified validation code was incorrect
define("SOFTBIZ_LC00001_CHECK_IMAGE","código de validação especificado estava incorreto");
//Please Enter Your Name!
define("SOFTBIZ_LC00000_SITEHOME","Por favor, insira seu nome!");
//Please Enter Your Address!
define("SOFTBIZ_LC00001_SITEHOME","Digite o seu endereço!");
//Please Enter Your City!
define("SOFTBIZ_LC00002_SITEHOME","Por favor Insira sua cidade!");
//Please Enter Your State!
define("SOFTBIZ_LC00003_SITEHOME","Por favor, insira seu estado!");
//Please Choose a Country!
define("SOFTBIZ_LC00004_SITEHOME","Escolha um país!");
//Please Enter Your Website URL!
define("SOFTBIZ_LC00005_SITEHOME","Por favor, insira o URL do site!");
//Please Enter Password.
define("SOFTBIZ_LC00006_SITEHOME","Digite a senha.");
//Passwords do not match.
define("SOFTBIZ_LC00007_SITEHOME","As senhas não coincidem.");
//New Advertiser: Signup by filling following form
define("SOFTBIZ_LC00008_SITEHOME","Novo Publicitário: cadastro, preenchendo formulário abaixo");
//Your Name
define("SOFTBIZ_LC00009_SITEHOME","Seu nome");
//Your Address
define("SOFTBIZ_LC00010_SITEHOME","Seu endereço");
//City
define("SOFTBIZ_LC00011_SITEHOME","Cidade");
//State
define("SOFTBIZ_LC00012_SITEHOME","Estado");
//Country
define("SOFTBIZ_LC00013_SITEHOME","País");
//Select a Country
define("SOFTBIZ_LC00014_SITEHOME","Selecione um pais");
//Website URL
define("SOFTBIZ_LC00015_SITEHOME","URL do site");
//Your Email
define("SOFTBIZ_LC00016_SITEHOME","Seu email");
//Password
define("SOFTBIZ_LC00017_SITEHOME","Senha");
//Confirm Password
define("SOFTBIZ_LC00018_SITEHOME","Confirme a Senha");
//Submit
define("SOFTBIZ_LC00019_SITEHOME","Enviar");
//Please specify your email address.
define("SOFTBIZ_LC00020_SITEHOME","Por favor, especifique o seu endereço de e-mail.");
//Please specify password.
define("SOFTBIZ_LC00021_SITEHOME","Por favor, especifique a senha.");
//Existing Advertisers: Login here
define("SOFTBIZ_LC00022_SITEHOME","Existente anunciantes: Acesso aqui");
//Sign In
define("SOFTBIZ_LC00023_SITEHOME","Assinar em");
//Password must be atleast %s characters long.
define("SOFTBIZ_LC00024_SITEHOME","A senha deve ter pelo menos% s caracteres.");
//Advertiser Menu
define("SOFTBIZ_LC00000_LEFT_PANEL","menu de anunciante");
//Home
define("SOFTBIZ_LC00001_LEFT_PANEL","Casa");
//Edit Profile
define("SOFTBIZ_LC00002_LEFT_PANEL","Editar Perfil");
//Logout
define("SOFTBIZ_LC00003_LEFT_PANEL","Sair");
//My Ads
define("SOFTBIZ_LC00004_LEFT_PANEL","meus anúncios");
//Add New Ad
define("SOFTBIZ_LC00005_LEFT_PANEL","Adicionar novo anúncio");
//Manage Ads
define("SOFTBIZ_LC00006_LEFT_PANEL","Gerenciar anúncios");
//All Text Ads
define("SOFTBIZ_LC00007_LEFT_PANEL","Todos os anúncios de texto");
//All Banners
define("SOFTBIZ_LC00008_LEFT_PANEL","Todos os Banners");
//My Account
define("SOFTBIZ_LC00009_LEFT_PANEL","Minha conta");
//Hi <font class='red'>'%1$s'</font>, Your account balance is %2$s
define("SOFTBIZ_LC00010_LEFT_PANEL","Oi <font class = 'red'> '% 1 $ S \"</ font>, O saldo da conta é% 2 $ s");
//Color Scheme
define("SOFTBIZ_LC00000_TEMPLATE","Esquema de cores");
//Please Enter a valid numeric value for Banner #
define("SOFTBIZ_LC00000_ADS","Por favor, indique um valor numérico válido para a bandeira #");
//Search Banners/Text Ad
define("SOFTBIZ_LC00001_ADS","Pesquisa Banners / anúncio de texto");
//Keyword
define("SOFTBIZ_LC00002_ADS","palavra chave");
//Search in
define("SOFTBIZ_LC00003_ADS","Procurar em");
//Banner #
define("SOFTBIZ_LC00004_ADS","a bandeira #");
//All
define("SOFTBIZ_LC00005_ADS","Todos");
//Waiting for Approval
define("SOFTBIZ_LC00006_ADS","Esperando aprovação");
//All Sizes
define("SOFTBIZ_LC00007_ADS","Todos os tamanhos");
//Ad Type
define("SOFTBIZ_LC00008_ADS","Tipo de anúncio");
//All Packages
define("SOFTBIZ_LC00009_ADS","Todos os pacotes");
//Sort by
define("SOFTBIZ_LC00010_ADS","Ordenar por");
//Date Added
define("SOFTBIZ_LC00011_ADS","data adicionada");
//Impressions Purchased
define("SOFTBIZ_LC00012_ADS","Impressions Comprado");
//Expiry Date
define("SOFTBIZ_LC00013_ADS","Data de validade");
//Impressions Received
define("SOFTBIZ_LC00014_ADS","impressões recebidas");
//Clicks Received
define("SOFTBIZ_LC00015_ADS","cliques recebidos");
//Impressions Left
define("SOFTBIZ_LC00016_ADS","impressões Esquerda");
//Clicks Left
define("SOFTBIZ_LC00017_ADS","cliques Esquerda");
//Days Left
define("SOFTBIZ_LC00018_ADS","Dias restantes");
//Order
define("SOFTBIZ_LC00019_ADS","Ordem");
//Ascending
define("SOFTBIZ_LC00020_ADS","ascendente");
//Descending
define("SOFTBIZ_LC00021_ADS","descendente");
//Search
define("SOFTBIZ_LC00022_ADS","Pesquisa");
//Click through Rate
define("SOFTBIZ_LC00023_ADS","Clique através da taxa");
//Status
define("SOFTBIZ_LC00024_ADS","estado");
//Note
define("SOFTBIZ_LC00025_ADS","Nota");
//Buy More
define("SOFTBIZ_LC00026_ADS","Compre mais");
//Edit
define("SOFTBIZ_LC00027_ADS","Editar");
//Stats
define("SOFTBIZ_LC00028_ADS","Estatísticas");
//No Ad satisfy the criteria you specified.
define("SOFTBIZ_LC00029_ADS","No Ad satisfazer aos critérios especificados.");
//Ad search results for %s
define("SOFTBIZ_LC00030_ADS","resultados da pesquisa de anúncios para% s");
//Ad search results for Ad # %s
define("SOFTBIZ_LC00031_ADS","resultados da pesquisa de anúncios para anúncios #% s");
//Banner
define("SOFTBIZ_LC00032_ADS","Bandeira");
//Text Ad Type
define("SOFTBIZ_LC00033_ADS","Texto Tipo de anúncio");
//Clicks Purchased
define("SOFTBIZ_LC00034_ADS","cliques Comprado");
//Expired
define("SOFTBIZ_LC00035_ADS","Expirado");
//Page %s of %s<br>
define("SOFTBIZ_LC00036_ADS","A página% s de% s <br>");
//Edit Banner Information
define("SOFTBIZ_LC00000_EDIT_BANNER","Editar informações da bandeira");
//Destination Url not required for flash banner type. Destination address should include http://www. eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00001_EDIT_BANNER","URL de destino não é necessário para o tipo de flash banner. endereço de destino deve incluir http: // www. por exemplo. http://www.softbizscripts.com");
//Statistics
define("SOFTBIZ_LC00000_BANNER_STATS","estatística");
//Type
define("SOFTBIZ_LC00001_BANNER_STATS","Digitar");
//Posted on
define("SOFTBIZ_LC00002_BANNER_STATS","postado em");
//Please provide your email id to retrieve your password!
define("SOFTBIZ_LC00000_SENDPASSWORD","Por favor, forneça o seu ID e-mail para recuperar sua senha!");
//Your password has been e-mailed
define("SOFTBIZ_LC00001_SENDPASSWORD","Sua senha foi enviada por correio electrónico");
//Email has been disabled by admin, unable to send your password.
define("SOFTBIZ_LC00002_SENDPASSWORD","E-mail foi desabilitado pelo administrador, incapaz de enviar sua senha.");
//No Member found with such email id!
define("SOFTBIZ_LC00003_SENDPASSWORD","Nenhum membro encontrado com tal ID de e-mail!");
//Your profile has been updated
define("SOFTBIZ_LC00000_UPDATEMEMBER","Seu perfil foi atualizado");
//Add Money Process
define("SOFTBIZ_LC00000_CANCELPURCHASE","Adicionar Processo de dinheiro");
//You have cancelled your Add Money Request at paypal.
define("SOFTBIZ_LC00001_CANCELPURCHASE","Você cancelou sua Pedir dinheiro em paypal.");
//New Text ad posted : Clicks
define("SOFTBIZ_LC00000_TRANSACTIONS_MESSAGE","Novo anúncio de texto publicado: Cliques");
//New Text ad posted : Impressions
define("SOFTBIZ_LC00001_TRANSACTIONS_MESSAGE","Novo anúncio de texto publicado: Impressions");
//New Text ad posted : Months
define("SOFTBIZ_LC00002_TRANSACTIONS_MESSAGE","Novo anúncio de texto publicado: Meses");
//Extended text ad : Clicks
define("SOFTBIZ_LC00003_TRANSACTIONS_MESSAGE","anúncio de texto Extensão: Cliques");
//Extended text ad : Impressions
define("SOFTBIZ_LC00004_TRANSACTIONS_MESSAGE","anúncio de texto Extensão: Impressions");
//Extended text ad : Months
define("SOFTBIZ_LC00005_TRANSACTIONS_MESSAGE","anúncio de texto Extensão: Meses");
//New Banner ad posted : Clicks
define("SOFTBIZ_LC00006_TRANSACTIONS_MESSAGE","Novo Banner anúncio afixado: Cliques");
//New Banner ad posted : Impressions
define("SOFTBIZ_LC00007_TRANSACTIONS_MESSAGE","Novo Banner anúncio afixado: Impressions");
//New Banner ad posted : Months
define("SOFTBIZ_LC00008_TRANSACTIONS_MESSAGE","Novo Banner anúncio afixado: Meses");
//Extended banner ad : Clicks
define("SOFTBIZ_LC00009_TRANSACTIONS_MESSAGE","anúncio da bandeira estendida: Cliques");
//Extended banner ad : Impressions
define("SOFTBIZ_LC00010_TRANSACTIONS_MESSAGE","anúncio da bandeira estendida: Impressions");
//Extended banner ad : Months
define("SOFTBIZ_LC00011_TRANSACTIONS_MESSAGE","anúncio da bandeira estendida: Meses");
//Money added through 2Checkout
define("SOFTBIZ_LC00012_TRANSACTIONS_MESSAGE","Dinheiro acrescentado através de 2Checkout");
//Money added through paypal
define("SOFTBIZ_LC00013_TRANSACTIONS_MESSAGE","Dinheiro acrescentado através de paypal");
//to go to advertiser home.
define("SOFTBIZ_LC00000_GEN_CONFIRM_MEM","para ir ao anunciante casa.");
//to add new advertisement.
define("SOFTBIZ_LC00001_GEN_CONFIRM_MEM","para adicionar novo anúncio.");
//to manage your advertisements.
define("SOFTBIZ_LC00002_GEN_CONFIRM_MEM","para gerenciar seus anúncios.");
//to add money to the account.
define("SOFTBIZ_LC00003_GEN_CONFIRM_MEM","para adicionar dinheiro para a conta.");
//to view account transactions.
define("SOFTBIZ_LC00004_GEN_CONFIRM_MEM","para ver transações de conta.");
//to logout
define("SOFTBIZ_LC00005_GEN_CONFIRM_MEM","para sair");
//Please be aware if your Ad text does not comply to the editorial guidelines then your Ad might get suspended
define("SOFTBIZ_LC00000_ADVERTISE_TEXT","Favor notar que se o texto do anúncio não está em conformidade com as diretrizes editoriais, em seguida, o seu anúncio pode ser suspenso");
//Title should not be more than 25 characters.!
define("SOFTBIZ_LC00001_ADVERTISE_TEXT","Título não deve ser superior a 25 caracteres.!");
//Please specify a description1!
define("SOFTBIZ_LC00002_ADVERTISE_TEXT","Por favor especificar um description1!");
//Description1 should not be more than 35 characters.!
define("SOFTBIZ_LC00003_ADVERTISE_TEXT","Descrição1 não deve ser superior a 35 caracteres.!");
//Description2 should not be more than 35 characters.!
define("SOFTBIZ_LC00004_ADVERTISE_TEXT","Descrição2 não deve ser superior a 35 caracteres.!");
//Package Information
define("SOFTBIZ_LC00005_ADVERTISE_TEXT","Informações do pacote");
//Add Contents
define("SOFTBIZ_LC00006_ADVERTISE_TEXT","Adicionar Conteúdo");
//Destination website address should includes http://www.<br> eg. http://www.softbizscripts.com
define("SOFTBIZ_LC00007_ADVERTISE_TEXT","Destino endereço do site deveriam inclui http: // www <br> por exemplo.. http://www.softbizscripts.com");
//Payment have been added to your account
define("SOFTBIZ_LC00000_ADDED","Pagamento foram adicionados à sua conta");
//Invalid access, denied
define("SOFTBIZ_LC00001_ADDED","Acesso inválido, negado");
//Your Add Money Request has been accepted. Funds will very soon appear in your account.
define("SOFTBIZ_LC00000_THANKS","Seu Pedir dinheiro foi aceite. Os fundos irão muito em breve aparecer na sua conta.");
//Upload Image File Status
define("SOFTBIZ_LC00000_DOUPLOAD","Estado de upload de arquivo da imagem");
//Image Uploader
define("SOFTBIZ_LC00001_DOUPLOAD","imagem Uploader");
//FINISH
define("SOFTBIZ_LC00002_DOUPLOAD","TERMINAR");
//Only .jpg/.png/.gif/.bmp/.jpeg/.swf file formats are allowed.<br>Please close this window and try again
define("SOFTBIZ_LC00003_DOUPLOAD","Apenas .jpg / .png / .gif / .bmp / ​​.jpeg / .swf formatos de arquivo são permitidos. <br> Por favor, feche esta janela e tente novamente");
//Uploaded files must be less than %skB. Please close this window and try again
define("SOFTBIZ_LC00004_DOUPLOAD","Arquivos enviados deve ser inferior a% SKB. Por favor, feche esta janela e tente novamente");
//Success : File has been uploaded
define("SOFTBIZ_LC00005_DOUPLOAD","Sucesso: O arquivo foi carregado");
//Error : File size more than 512000 bytes
define("SOFTBIZ_LC00006_DOUPLOAD","Erro: O tamanho do arquivo mais de 512000 bytes");
//Error : File partially uploaded
define("SOFTBIZ_LC00007_DOUPLOAD","Erro: arquivo parcialmente carregado");
//Error : No File Uploaded
define("SOFTBIZ_LC00008_DOUPLOAD","Erro: Nenhum arquivo Carregado");
//File could not be uploaded probably due to permission restrictions on destination directory
define("SOFTBIZ_LC00009_DOUPLOAD","Arquivo não pôde ser carregado provavelmente devido a restrições de permissão em diretório de destino");
//Error : File Not Uploaded. Check Size & Try Again.
define("SOFTBIZ_LC00010_DOUPLOAD","Erro: Arquivo não carregado. Verifique Tamanho e tente novamente.");
//Go Back
define("SOFTBIZ_LC00011_DOUPLOAD","Volte");
//Copyright © 2003 -2016. All Rights Reserved.
define("SOFTBIZ_LCUPDT2015111000000_10","Copyright © 2003 -2016. Todos os direitos reservados.");
//Message
define("SOFTBIZ_LCUPDT2015111000000_11","Mensagem");
//for
define("SOFTBIZ_LCUPDT2015111000000_12","para");
//Post New Ad
define("SOFTBIZ_LCUPDT2015111000000_13","Post New Ad");
//My Impression Ads
define("SOFTBIZ_LCUPDT2015111000000_14","Meus anúncios Impression");
//Click Based Ads
define("SOFTBIZ_LCUPDT2015111000000_15","Clique anúncios baseados");
//Time bound Ads
define("SOFTBIZ_LCUPDT2015111000000_16","calendarizados anúncios");
//Hit the [Browse] button to find the file on your computer and then click [Insert] button to upload it.
define("SOFTBIZ_LC00013_FILEUPLOAD","Aperte o botão [Procurar] para localizar o arquivo no seu computador e, em seguida, clique no botão [Insert] para carregá-lo.");
//Image
define("SOFTBIZ_LC00014_FILEUPLOAD","Imagem");
//Upload
define("SOFTBIZ_LC00015_FILEUPLOAD","Envio");
//Please have patience, you will not receive any notification until the file is completely transferred.
define("SOFTBIZ_LC00016_FILEUPLOAD","Por favor, tenham paciência, você não receberá qualquer notificação até que o arquivo é completamente transferida.");
//This feature has been disabled in the demo.
define("SOFTBIZ_LCUPDT2011122400000_DOUPLOAD_ITEM_MULTI","Este recurso foi desativado na demo.");

?>