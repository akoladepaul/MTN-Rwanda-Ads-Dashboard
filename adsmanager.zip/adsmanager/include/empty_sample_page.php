<?php 
function main()
{
?>
<!-- YOUR CONTENTS MUST BEGIN BELOW THIS LINE-->
<pre><div align="left">
Steps to add additional pages to site within same design/layout:-

1. Copy this file into script root folder.

2. Open the copied file and add your contents, overwriting this text.

3. Save the file with a valid .php filename.

4. Place the link to this file into "include/general_template.php" file. Just give the name of the newly created file in the link target without any path information.
</div></pre>
<!-- YOUR CONTENTS MUST END ABOVE THIS LINE-->
<?php
}
include_once 'template.php';
?>