<?php
function left()
{
	
	global $config,$blade,$provided;
		           
$config=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_config "));
              

$sb_fee_currency=$config['sb_fee_symbol'];
$advertiser=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_advertisers where id=".$_SESSION["softbiz_bannerad_userid"]));
$sbrow_tra=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select sum(amount) as total from sbbanners_adv_transactions where adv_id=".$_SESSION["softbiz_bannerad_userid"]." group by adv_id"));
$balance=($sbrow_tra && is_numeric($sbrow_tra["total"]))?$sbrow_tra["total"]:0;
		           

$vars=get_defined_vars ();
$data=array(
"vars"=>$vars,
);

echo $blade->view()->make('includes.left')->with($data)->render();



}// end left
?>
