<?php

// CONFIGURATION SECTION ENDS ////
$prepend="";
if(isset($one_deep))
{
	$prepend="../";
}
require $prepend . 'vendor/autoload.php';

// BLADE STACK
use Philo\Blade\Blade;
$views = __DIR__ . '/../views';
$cache = __DIR__ . '/../cache';
//echo $views;
$blade = new Blade($views, $cache);
//echo $blade->view()->make('hello')->render();




// FORMBUILDER STACK
error_reporting(E_ALL);
$formBuilder = new AdamWathan\Form\FormBuilder;
//$myOldInputProvider = new AdamWathan\Form\OldInput\OldInputInterface;


//$formBuilder->setOldInputProvider($myOldInputProvider);
//$formBuilder->setErrorStore($myErrorStore);
//$formBuilder->setToken($myCsrfToken);

$basicBootFormsBuilder = new AdamWathan\BootForms\BasicFormBuilder($formBuilder);
$horizontalBootFormsBuilder = new AdamWathan\BootForms\HorizontalFormBuilder($formBuilder);

$bootForm = new AdamWathan\BootForms\BootForm($basicBootFormsBuilder, $horizontalBootFormsBuilder);


//{!! BootForm::open() !!}
//{!! BootForm::text('Field Label', 'field_name') !!}
//{!! BootForm::close() !!}

//echo $bootForm->open(); 
//echo $bootForm->text('Field Label', 'field_name');
//echo $bootForm->close();
//die();

?>