<?php 

// YOU NEED TO CHANGE THE CONTENTS OF THE values of variables given in single quotes
$servername='localhost' ;  // Replace this 'localhost' with your server name 
$database_username='root'; // Replace this  with your username 
$database_password='';  // Replace this  with your password
$database_name='AdManagement_2016r';// Replace this 'db' with your database name
// CONFIGURATION SECTION ENDS ////



include_once('classes.php');

?>