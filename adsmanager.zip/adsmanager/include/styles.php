<?php
		           
// LOAD style number from the config file
$config=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_config "));
if (!isset($_SESSION["softbiz_bannerad_provided"]) && !isset($_REQUEST["provided"]) )
{
$provided=$config["style_list"];
}

// RELOAD if its in the SESSION 
if (  (isset($_SESSION["softbiz_bannerad_provided"])) )
{
$provided=$_SESSION["softbiz_bannerad_provided"];
//echo "Loaded from Session " . $_SESSION["softbiz_bannerad_provided"];
}

// RELOAD if its in the REQUEST AND SET SESSION
if (  (isset($_REQUEST["provided"])) )
{
$provided=$_REQUEST["provided"];
$_SESSION["softbiz_bannerad_provided"]=$_REQUEST["provided"];
//echo "Loaded from Request " .$_REQUEST["provided"];

}
//$style=mysql_fetch_array(mysql_query("select * from sbbanners_styles where id=$style_num "));
/// is style provided //////

/////////

$style=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_styles where id=$provided "));

////////////  SET ALL DEFAULT COLORS////////////
//Default
		           
$softbiz_faq_page_bg="#ffffff";    		//Overal page background
$softbiz_faq_section_bg="#f5f5f5"; 		//FAQ section background colot
$softbiz_seperator_color="#665577";	 	//Seperator color
$softbiz_faq_clr_yes="#00cc00";   		//Statistical Bar Colors YES
$softbiz_faq_clr1_no="#FF0000";  		//Statistical Bar Colors NO

//////////////////////////////////
// THE SITE FONTS////////////////
/////////////////////////////////

//Used as major site font, main table style , title bar style 
$softbiz_fontstyle1="Arial, Helvetica, sans-serif";
$softbizfontcolor1="#003399";
$softbizfontsize1="12px";
$softbiz_table_bg_color1="#ffffff"; //Main table bg
$softbizfontcolor2="#ffffff";//Used as Title Bar Color
$softbiz_table_bg_color2="#C33100"; //Title bar bg

$softbiz_highlight_bg="#f5f5f5"; //Title bar bg

// Link style#C33100
$softbizlinkstyle="Arial, Helvetica, sans-serif";
$softbizlinkcolor="#990000";
$softbizlinksize="12px";

/////////// DEFAULT COLORS HAVE BEEN SET ////////////
		           
if ($style)

{

//Load values
$softbiz_faq_page_bg="#" . $style["page_bg"];    		//Overal page background
$softbiz_faq_section_bg="#" . $style["table_bg"]; 		//FAQ section background colot
$softbiz_seperator_color="#" . $style["seperator"];	 	//Seperator color
$softbiz_faq_clr_yes="#" . $style["stat_yes_color"];   		//Statistical Bar Colors YES
$softbiz_faq_clr1_no="#" . $style["stat_no_color"];  		//Statistical Bar Colors NO

//////////////////////////////////
// THE SITE FONTS////////////////
/////////////////////////////////

//Used as major site font, main table style , title bar style 
$softbiz_fontstyle1=$style["normal_font"];
$softbizfontcolor1="#" . $style["normal_font_color"];
$softbizfontsize1=$style["normal_font_size"] . "px";
$softbiz_table_bg_color1="#" . $style["normal_table_bg"]; //Main table bg
$softbizfontcolor2="#" . $style["title_font_color"];//Used as Title Bar Color
$softbiz_table_bg_color2="#" . $style["title_bg"]; //Title bar bg

$softbiz_highlight_bg="#" . $style["highlight_bg_color"]; //Title bar bg

// Link style#C33100
$softbizlinkstyle=$style["link_font"];
$softbizlinkcolor="#" . $style["link_font_color"];
$softbizlinksize=$style["link_font_size"] . "px";
}
		           
?>
<style type="text/css">
<!--
.mainbgcolor {
	background-color: <?php echo $softbiz_faq_page_bg; ?>;
}
.yescolor {
	background-color: <?php echo $softbiz_faq_clr_yes; ?>;
}
.nocolor {
	background-color: <?php echo $softbiz_faq_clr1_no; ?>;
}

.faqbgcolor {
	background-color: <?php echo $softbiz_faq_section_bg; ?>;
}

.seperatorstyle {
	background-color: <?php echo $softbiz_seperator_color; ?>;
}
.highlightbgcolor {
	background-color: <?php echo $softbiz_highlight_bg; ?>;
}

a {
	font-family: <?php echo $softbizlinkstyle; ?>;
	font-size: <?php echo $softbizlinksize; ?>;
	font-weight: normal;
	color: <?php echo $softbizlinkcolor; ?>;
	text-decoration: underline;
}
.titlestyle {
	font-family: <?php echo $softbiz_fontstyle1; ?>;
	font-weight: bold;
	font-size: <?php echo $softbizfontsize1; ?>;
	color: <?php echo $softbizfontcolor2; ?>;
	background-color: <?php echo $softbiz_table_bg_color2; ?>;
}
a.pagelink {
	font-family: <?php echo $softbiz_fontstyle1; ?>;
	font-weight: bold;
	font-size: <?php echo $softbizfontsize1; ?>;
	color: <?php echo $softbizfontcolor2; ?>;
	text-decoration: underline;
}
.onepxtable{
	border: 1px solid  <?php  echo $softbiz_seperator_color; ?>;
}

.maintablestyle {
	font-family: <?php echo $softbiz_fontstyle1; ?>;
	font-weight: normal;
	font-size: <?php echo $softbizfontsize1; ?>;
	color: <?php echo $softbizfontcolor1; ?>;
	background-color: <?php echo $softbiz_table_bg_color1; ?>;
}
font {
	font-family:  <?php echo $softbiz_fontstyle1; ?>;
	color: <?php echo $softbizfontcolor1; ?>;
	font-size: <?php echo $softbizfontsize1; ?>;
}
font.red{
	font-family:  <?php echo $softbiz_fontstyle1; ?>;
	color: #FF0000;
	font-size: <?php echo $softbizfontsize1; ?>;
}

font.mini {
	font-family:  <?php echo $softbiz_fontstyle1; ?>;
	color: <?php echo $softbizfontcolor1; ?>;
	font-size: 10px;
}
.nonefont {
	text-transform: none;
}
-->
</style>