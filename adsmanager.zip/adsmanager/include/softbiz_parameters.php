<?php define("CONFIDENTIAL_STR","Manage your banners here");	//for enhanced security this string is appended to the random number generated to form a random string for image 


define('SHOW_THEMES' ,"1");
define('DEFAULT_THEME' ,"2");
//WhenSHOW_THEMES=0 then 
//if FLAGS_SIDE=1 laguage flags come besides contact us
//if FLAGS_SIDE=1 laguage flags stay on top
define('FLAGS_SIDE' ,"0");
$softbiz_themes=array(

array("1","Purple + Orange","main-purple-orange.css"),
array("2","Teal + Light Red","main-cyan-lightred.css"),
array("3","Green + Gold","main-green-gold.css"),
array("4","Wood Brown","main-wood-brown.css"),
array("5","Daisy Blue + Misty Wheat","main-daisy-blue-misty-wheat.css"),
array("6","All Green","main-all-green.css"),
array("7","Blue + Goldfish Orange","main-blue-goldfish-orange.css"),
array("9","Forest green + Black","main-forest-green-black.css"),
array("11","Red + Blue","main-red-blue.css"),
array("12","Yellow + Red","main-yellow-red.css"),
array("14","Blue + Orange + Gold","main-blue-orange-gold.css"),
array("15","All Blue","main-all-blue.css"),
array("16","Red + Violet + Yellow","main-red-violet-yellow.css"),
array("17","Pink + Black","main-pink-black.css"),
array("19","Blue + Orange + Green","main-blue-orange-green.css"),
array("20","Orange + Yellow","main-orange-yellow.css"),
array("21","Red + Green + Blue","main-red-green-blue.css"),
array("13","Yellow + Black","main-yellow-black.css"),
array("8","Teal + Cherry Pink","main-teal-cherry-pink.css"),
array("10","Blue + Black","main-blue-black.css"),
array("18","Green Root + Pink","main-green-root-pink.css"),
//array("22","Four","main.css"),


);



define("SBBGCOLOR","#FAF0EA");
define("SBLINECOLOR","#6B4418");//6b4418");
define("SBFONTCOLOR","#990000");//990000");

define("SBTIME_ZONE","");//sets the time zone accordding to country

define("SBLANG_FILENAME","english.php");	//name of the language file to use; the named file must exist in the "lang" folder 

define("SBAUTO_REFRESH_DURATION","20");	//set the time in seconds for auto refereshing the banners, a value less than 1 will disable auto refresh



define('EDGE_IMAGE_FIX',1);//Edge doesnot support "background-size: cover" FF Chrome do.

define('FULL_IMAGE_ALL',1);//Show full image and NOT portfolio style in all browsers.


define("SBIMG_PATH_TYPE","1");		//Sets whether images will be displayed using relative path or direct path. Specify 1 for relative, 2 for direct. NOTE: Specifying 2 (i.e. direct path) will use following `SBIMG_SITE_ROOT_PATH` parameter so valid value for `SBIMG_SITE_ROOT_PATH` parameter must be provided otherwise images will not be visible. 
define("SBIMG_SITE_ROOT_PATH","http://localhost/AdManagement_2016r");		//Full website address through which script can be accessed in the browser e.g. http://www.your-domain.com


?>