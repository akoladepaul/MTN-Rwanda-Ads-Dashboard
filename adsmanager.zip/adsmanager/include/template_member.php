<?php
///////////////////////////////////////////////////////////////////////////////
///      THE CODE OF THIS SCRIPT HAS BEEN DEVELOPED BY SOFTBIZ SOLUTIONS  /////
///      AND IS MEANT TO BE USED ON THIS SITE ONLY AND IS NOT FOR REUSE,  /////
///      RESALE OR REDISTRIBUTION.                                        ///// 
///      IF YOU NOTICE ANY VIOLATION OF ABOVE PLEASE REPORT AT:           /////
///      admin@softbizscripts.com                                         /////
///      http://www.softbizscripts.com                                    /////
///      http://www.softbizsolutions.com                                  /////  
///////////////////////////////////////////////////////////////////////////////
function sbhead()
{
	global $config,$title_str,$site_keywords,$site_desc,$blade,$softbiz_themes,$provided;


// LOAD style number from the config file

if (!isset($_SESSION["softbiz_auction_theme_provided"]) && !isset($_REQUEST["provided"]) )
{
$provided=DEFAULT_THEME;
}

// RELOAD if its in the SESSION 
if (  (isset($_SESSION["softbiz_auction_theme_provided"])) )
{
$provided=$_SESSION["softbiz_auction_theme_provided"];
//echo "Loaded from Session " . $_SESSION["provided"];
}

// RELOAD if its in the REQUEST AND SET SESSION
if (  (isset($_REQUEST["provided"])) )
{
$provided=$_REQUEST["provided"];
$_SESSION["softbiz_auction_theme_provided"]=$_REQUEST["provided"];
//echo "Loaded from Request " .$_REQUEST["provided"];

}

$theme_to_use="";
$default_theme="";
foreach ($softbiz_themes as $theme)
{
	
		if($theme[0]==DEFAULT_THEME){$default_theme=$theme[2];}
	if($theme[0]==$provided){$theme_to_use=$theme[2];}

}


if($theme_to_use=="")
{
	$theme_to_use=$default_theme;
}
$title_str=$config["site_name"];
  $site_keywords=$config["site_keywords"];
  $site_desc=$config["site_desc"];
  $vars=get_defined_vars ();
$data=array(
'title_str'=>$title_str,
'site_keywords'=>$site_keywords,
'provided'=>$provided,
'site_desc'=>$site_desc,
'config'=>$config,
'theme_to_use'=>$theme_to_use,
'vars'=>$vars,

);



echo $blade->view()->make('includes.head')->with($data)->render();

if(FULL_IMAGE_ALL)
{ ?>
<style>	
.pimg-product-detail-auction {
     object-fit: contain;
	align-content:center;
}
.pimg-search-gallery {
  width: 100% ;
  object-fit:contain ; 
  }
.pimg-gallery
 {
  width: 100% ;
  object-fit:contain ; 
  }
  .pimg-home-featured,.pimg-search-result
   {
  width: 100% ;
  object-fit:contain ; 
  } 
    .datarow-data:nth-of-type(4n)  {
    background-color: #fbfbfb;
}
   .datarow-title:nth-of-type(4n-1)  {
    background-color: #fbfbfb;
}

.search-result-item div
{
	padding:4px 0 4px 0 ;
	
}
img {
   max-width: 100%;
   height: auto;
}
</style>

<?php
}
if(EDGE_IMAGE_FIX)
{
?>


<style>
@supports (-ms-accelerator:true) {

.pimg-product-detail-auction {
    height: 400;
    width:auto;
    object-fit: none;
	align-content:center;
}
.pimg-search-gallery,.pimg-home-featured,.pimg-search-result,.pimg-gallery {
    height: auto;
    width:100%;
    object-fit: none;
}
}
</style>


<?php }
?>
<style>
.darkgray
{
	background-color:#DCDCDC;
	
}
</style>
<?php
}
function body()
{ global $strpass,$provided,$config,$blade,$constants,$softbiz_themes;



$constants=get_defined_constants(true);
	$strpass="";
	foreach($_REQUEST as $key=>$value)
	{
		if($key<>"PHPSESSID" && $key<>"provided" )
			$strpass.="&$key=".urlencode(stripslashes(str_replace("&lt;","<",$value)));
	}
	$sbq_lang="select * from reciprocal_languages where sbactive=1 order by sbdefault desc, sblanguage";
	$sbrs_lang=mysqli_query($GLOBALS["___mysqli_ston"], $sbq_lang);
	$lang_enable=0;		
	if($config["sbis_lang_bar_visible"] and mysqli_num_rows($sbrs_lang) > 1)	//notice '> 1' as language change will be needed if more than one languages are there
		$lang_enable=1;
		

$member_options=array();


$vars=get_defined_vars ();
//echo "====== $lang_enable --====";
$data=array(
'lang_enable'=>$lang_enable,
'config'=>$config,
'sbrs_lang'=>$sbrs_lang,
'strpass'=>$strpass,
'member_options'=>$member_options,
"vars"=>$vars,
);



echo $blade->view()->make('includes.header')->with($data)->render();





?>


<div class="row-fluid">
 <div  class="col-sm-12 col-md-4 col-lg-2 ">
 <?php  

 left(); ?>
 </div>
 

  <div  class="col-sm-12 col-md-8 col-lg-10 ">
 <?php  

 main(); ?>
 </div>
 
 
 </div>

 <?php
$vars=get_defined_vars ();
$data=array(
"vars"=>$vars,
);

 echo $blade->view()->make('includes.bottom')->with($data)->render();

 ?>
 <?php
 $vars=get_defined_vars ();
$data=array(
"vars"=>$vars,
);


echo $blade->view()->make('includes.footer')->with($data)->render();

 ?>
<script language="javascript">
//alert(window.innerWidth);

function ajdust()
{
if(window.innerWidth>1700)
{
	document.getElementById("main-panel-column").className = "col-sm-8 col-md-8 col-lg-10 ";
	document.getElementById("side-panel-column").className = "col-sm-4 col-md-4 col-lg-2  .hidden-sm-down";


$( ".product-card" ).removeClass( "col-xl-3" ).addClass( "col-xl-2" );

$( ".search-result-item" ).removeClass( "col-xl-3" ).addClass( "col-xl-2" );
	
	
}
else
{
	document.getElementById("main-panel-column").className = "col-xs-12 col-sm-6 col-md-8 col-lg-9 ";
	document.getElementById("side-panel-column").className = "col-xs-12 col-sm-6 col-md-4 col-lg-3  .hidden-sm-down";

$( ".product-card" ).removeClass( "col-xl-2" ).addClass( "col-xl-3" );
$( ".search-result-item" ).removeClass( "col-xl-2" ).addClass( "col-xl-3" );
	
}
}
ajdust();

$( window ).resize(function() {
 ajdust();
});
</script>
 
 
 


   

    

   <!--script src="js/jquery.js"></script -->
    <!--script src="js/bootstrap.min.js"></script-->
    <script src="js/bootstrap4.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
 
 
 <!-- SELECT 2 -->

<link href="css/select2.min.css" rel="stylesheet" />
<script src="js/select2.min.js"></script>

<!-- Select 2 initialize  -->

	<link href="css/summernote.css" rel="stylesheet">
<script src="js/summernote.min.js"></script>


    <script type="text/javascript">
$(".select-two").select2({
  placeholder: "Select",
  allowClear: true
});
</script>

<script type="text/javascript">
$('.stackable').stacktable();
$('.stackable-columns').stackcolumns();


$(document).delegate('*[data-toggle="lightbox"]', 'click', function(event) {
    event.preventDefault();
    $(this).ekkoLightbox();
}); 


</script>
<?php 

}


?>



