<?php
include_once "myconnect.php";
//session_start();
//session_register("softbiz_bannerad_provided");
///////////////////////////////////////////////////////////////////////////////
///      THE CODE OF THIS SCRIPT HAS BEEN DEVELOPED BY SOFTBIZ SOLUTIONS  /////
///      AND IS MEANT TO BE USED ON THIS SITE ONLY AND IS NOT FOR REUSE,  /////
///      RESALE OR REDISTRIBUTION.                                        ///// 
///      IF YOU NOTICE ANY VIOLATION OF ABOVE PLEASE REPORT AT:           /////
///      admin@softbizscripts.com                                         /////
///      http://www.softbizscripts.com                                    /////
///      http://www.softbizsolutions.com                                  /////  
///////////////////////////////////////////////////////////////////////////////

		           
// LOAD style number from the config file
$config=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_config "));

$prov=$config["textad_style_list"];


// RELOAD if its in the SESSION 
//if (  (isset($_SESSION["softbiz_bannerad_provided"])) )
//{
//$provided=$_SESSION["softbiz_bannerad_provided"];
//echo "Loaded from Session " . $_SESSION["softbiz_bannerad_provided"];
//}

// RELOAD if its in the REQUEST AND SET SESSION
//if (  (isset($_REQUEST["provided"])) )
//{
//$provided=$_REQUEST["provided"];
//$_SESSION["softbiz_bannerad_provided"]=$_REQUEST["provided"];
//echo "Loaded from Request " .$_REQUEST["provided"];

//}
//$style=mysql_fetch_array(mysql_query("select * from sbbanners_styles where id=$style_num "));
/// is style provided //////

/////////

$style=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_textad_styles where id=$prov"));
		           
////////////  SET ALL DEFAULT COLORS////////////
//Default

//$softbiz_faq_page_bg="#ffffff";    		//Overal page background
$softbiz_faq_section_bg="#f5f5f5"; 		//FAQ section background colot
$softbiz_seperator_color="#665577";	 	//Seperator color
//$softbiz_faq_clr_yes="#00cc00";   		//Statistical Bar Colors YES
//$softbiz_faq_clr1_no="#FF0000";  		//Statistical Bar Colors NO

//////////////////////////////////
// THE SITE FONTS////////////////
/////////////////////////////////

$softbiz_title="Arial, Helvetica, sans-serif";
$softbiz_titlecolor="#003399";
$softbiz_titlesize="12px";
//$softbiz_table_bg_color1="#ffffff"; //Main table bg
$softbiz_des="Arial, Helvetica, sans-serif";
$softbiz_descolor="#ffffff";
$softbiz_dessize="12px";
$softbizlinkstyle="Arial, Helvetica, sans-serif";
$softbizlinkcolor="#990000";
$softbizlinksize="12px";
$softbiz_underline='none';
$softbiz_bold='normal';

/////////// DEFAULT COLORS HAVE BEEN SET ////////////
		           
if ($style)
{

//Load values
//softbiz_faq_page_bg="#" . $style["page_bg"];    		//Overal page background
//$softbiz_faq_clr_yes="#" . $style["stat_yes_color"];   		//Statistical Bar Colors YES
//$softbiz_faq_clr1_no="#" . $style["stat_no_color"];  		//Statistical Bar Colors NO

//////////////////////////////////
// THE SITE FONTS////////////////
/////////////////////////////////

//Used as major site font, main table style , title bar style 
$softbiz_faq_section_bg="#" . $style["table_bg"]; 		//FAQ section background colot
$softbiz_seperator_color="#" . $style["seperator"];	 	//Seperator color
$softbiz_des=$style["normal_font"];
$softbiz_descolor="#" . $style["normal_font_color"];
$softbiz_dessize=$style["normal_font_size"] . "px";
$softbiz_titlecolor="#" . $style["title_font_color"];//Used as Title Bar Color
$softbiz_title= $style["title_font"];//Used as Title Bar Color
$softbiz_titlesize=$style["title_font_size"]. "px";;//Used as Title Bar Color
$softbizlinkstyle=$style["link_font"];
$softbizlinkcolor="#" . $style["link_font_color"];
$softbizlinksize=$style["link_font_size"] . "px";
if($style['underline_links']=='yes')
$softbiz_underline='underline';
else
$softbiz_underline='none';
if($style['title_bold']=='yes')
$softbiz_bold='bold';
else
$softbiz_bold='normal';
}
//echo $softbiz_underline;
$strpass="";
foreach($_REQUEST as $key=>$value)
{
if(($key<>"provided"))
{
$strpass.="&".$key."=$value";
}
}
		           
?><html>
<head>
<title><?php echo $config["site_name"];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!--link href="styles_gallery.css" rel="stylesheet" type="text/css"-->
<style type="text/css">

.borderstyle{
	/*border: 1px solid  <?php  echo $softbiz_seperator_color; ?>;*/
	background-color: <?php echo $softbiz_seperator_color; ?>;
}
.tablebgcolor{
	background-color: <?php echo $softbiz_faq_section_bg; ?>;

}
a.textadlink{
	font-family: <?php echo $softbizlinkstyle; ?>;
	font-size: <?php echo $softbizlinksize; ?>;
	font-weight: normal;
	color: <?php echo $softbizlinkcolor; ?>;
	text-decoration: none;
}
a.textadlink:hover{
	font-family: <?php echo $softbizlinkstyle; ?>;
	font-size: <?php echo $softbizlinksize; ?>;
	font-weight: normal;
	color: <?php echo $softbizlinkcolor; ?>;
	text-decoration: <?php echo $softbiz_underline; ?>;
}
a.titletextadlinkstyle{
	font-family: <?php echo $softbiz_title; ?>;
	font-weight: <?php echo $softbiz_bold; ?>;
	font-size: <?php echo $softbiz_titlesize; ?>;
	color: <?php echo $softbiz_titlecolor; ?>;
	text-decoration: none;

}
a.titletextadlinkstyle:hover{
	font-family: <?php echo $softbiz_title; ?>;
	font-weight: <?php echo $softbiz_bold; ?>;
	font-size: <?php echo $softbiz_titlesize; ?>;
	color: <?php echo $softbiz_titlecolor; ?>;
	text-decoration: <?php echo $softbiz_underline; ?>;

}
font.textdescription {
	font-family: <?php echo $softbiz_des; ?>;
	font-weight: normal;
	font-size: <?php echo $softbiz_dessize; ?>;
	color: <?php echo $softbiz_descolor; ?>;
	background-color: <?php echo $softbiz_faq_section_bg; ?>;
}

</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function sb_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>