<?php 

// YOU NEED TO CHANGE THE CONTENTS OF THE values of variables given in single quotes
$servername='localhost' ;  // Replace this 'localhost' with your server name 
$database_username='greenbe3_ads'; // Replace this  with your username 
$database_password='T}sM$yh%Z3dH';  // Replace this  with your password
$database_name='greenbe3_ads';// Replace this 'db' with your database name
// CONFIGURATION SECTION ENDS ////



include_once('classes.php');

?>