<?php
include_once "myconnect.php";
include_once "core/check_image.php";

function main()
{ 

	global $config,$provided,$blade,$auto_user,$auto_userpwd;


            
/////////////getting length of user name and password
$len=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from sbbanners_config"));
$sb_captcha_signup=$len["sb_signup_captcha"];
$sb_captcha_login=$len["sb_login_captcha"];
          
$pwd_len=$len["pwd_len"];
$uname="";
$email="";
$city="";
$state="";
$country=0;
$url="";
$add="";
              
if(count($_POST)>0)
{
$uname=$_POST["uname"];
$email=$_POST["email"];
$add=$_POST["add"];
$city=$_POST["city"];
$state=$_POST["state"];
$country=$_POST["country"];
$url=$_POST["url"];}
            
?>

<SCRIPT language=javascript> 
//<!--

  function formValidate(form) 
  {
	if (sbis_empty(form.uname.value)) {
       	   alert('<?php /*1s*/ echo "".SOFTBIZ_LC00000_SITEHOME.""; /*-~- Please Enter Your Name! -~-*/ /*1e*/ ?>');
		   form.uname.focus();
	   return false;
	   }

	if (sbis_empty(form.add.value)) {
       	   alert('<?php /*1s*/ echo "".SOFTBIZ_LC00001_SITEHOME.""; /*-~- Please Enter Your Address! -~-*/ /*1e*/ ?>');
		   form.add.focus();
	   return false;
	   }
	if (sbis_empty(form.city.value)) {
       	   alert('<?php /*1s*/ echo "".SOFTBIZ_LC00002_SITEHOME.""; /*-~- Please Enter Your City! -~-*/ /*1e*/ ?>');
		   form.city.focus();
	   return false;
	   }
	if (sbis_empty(form.state.value)) {
       	   alert('<?php /*1s*/ echo "".SOFTBIZ_LC00003_SITEHOME.""; /*-~- Please Enter Your State! -~-*/ /*1e*/ ?>');
		   form.state.focus();
	   return false;
	   }
	if ( form.country.selectedIndex == 0 ) {
       	   alert('<?php /*1s*/ echo "".SOFTBIZ_LC00004_SITEHOME.""; /*-~- Please Choose a Country! -~-*/ /*1e*/ ?>');
		   form.country.focus();
	   return false;
	   }
	if (sbis_empty(form.url.value)) {
       	   alert('<?php /*1s*/ echo "".SOFTBIZ_LC00005_SITEHOME.""; /*-~- Please Enter Your Website URL! -~-*/ /*1e*/ ?>');
		   form.url.focus();
	   return false;
	   }
		
		if (!emailCheck (form.email.value) )
		{
			form.email.focus();

			return (false);
		}
        if(sbis_empty(form.pwd.value))
		{
	   	   alert('<?php /*1s*/ echo "".SOFTBIZ_LC00006_SITEHOME.""; /*-~- Please Enter Password. -~-*/ /*1e*/ ?>');
           form.pwd.focus();
		   return false; 
        }
		if (form.pwd.value.length<<?php echo $pwd_len;?> ) 
		{
		   alert('<?php printf(/*2s*/ "".SOFTBIZ_LC00024_SITEHOME."" /*-~-* / "Password must be atleast %s characters long." / *-~-*/ /*2e*/ ,$pwd_len); ?>');
		   form.pwd.focus();
		   return false;
		}		
		if (form.pwd.value != form.pwd2.value)
		{
			alert('<?php /*1s*/ echo "".SOFTBIZ_LC00007_SITEHOME.""; /*-~- Passwords do not match. -~-*/ /*1e*/ ?>');
			form.pwd2.value="";
			form.pwd.focus();
			form.pwd.select();
			return false;
		}
		
	<?php if($sb_captcha_signup==1)
	{?>
		if(form.image_code.value=="")
		{
			alert("<?php /*1s*/ echo "".SOFTBIZ_LC00001_LOSTPASSWORD.""; /*-~- Please specify validation code -~-*/ /*1e*/ ?>");
			form.image_code.focus();
			return(false);
		}
	<?php }?>
	return true;
  }
// -->
</SCRIPT>
                  		
<script language="JavaScript">
	function validate_login(frm)
	{
		if(frm.email.value=="")
		{
			alert("<?php /*1s*/ echo "".SOFTBIZ_LC00020_SITEHOME.""; /*-~- Please specify your email address. -~-*/ /*1e*/ ?>");
			frm.email.focus();
			return false;
		}else if (!emailCheck (frm.email.value) )
		{
			frm.email.focus();
			return (false);
		}
		if(frm.pwd.value=="")
		{
			alert("<?php /*1s*/ echo "".SOFTBIZ_LC00021_SITEHOME.""; /*-~- Please specify password. -~-*/ /*1e*/ ?>");
			frm.pwd.focus();
			return false;
		}
	<?php if($sb_captcha_login==1) {?>

		if(frm.image_code.value=="")
		{
			alert("<?php /*1s*/ echo "".SOFTBIZ_LC00001_LOSTPASSWORD.""; /*-~- Please specify validation code -~-*/ /*1e*/ ?>");
			frm.image_code.focus();
			return(false);
		}
		<?php }?>
		return true;
	}
	
	</script>
<?php

$form_title=SOFTBIZ_LC00008_SITEHOME; //New Advertiser: Signup by filling following form

$form_title2=SOFTBIZ_LC00022_SITEHOME ; //Existing Advertisers: Login here
$vars=get_defined_vars ();

$data=array(
"vars"=>$vars,
);

echo $blade->view()->make('index')->with($data)->render();



}// end main
include "template.php";
?>
