// Add contact using ajax : id is the username
function addcontact(id){
	  var xhttp;


  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("result").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "addcontact_popup.php?username="+id, true);
  xhttp.send();   
  
  setTimeout(function() {
    $('#result').fadeOut('slow');
}, 3000); 
document.getElementById("result").innerHTML ="";
 $('#result').fadeIn('fast');
return false;

}


// Block contact using ajax : id is the username
function blockcontact(id){
	  var xhttp;


  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("result").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "addblock_popup.php?username="+id, true);
  xhttp.send();   
  
setTimeout(function() {
    $('#result').fadeOut('slow');
}, 3000); 
document.getElementById("result").innerHTML ="";
 $('#result').fadeIn('fast');
return false;

}


function addcontact_form(){
	
	alert("aaa");
$(document).ready(function() {
    $(form)
        .formValidation({
            
        })
        .on('success.form.fv', function(e) {
			
			alert("bbb");
            // Prevent form submission
            e.preventDefault();

            var $form = $(e.target),
                fv    = $form.data('formValidation');

            // Use Ajax to submit form data
            $.ajax({
                url: $form.attr('action'),
                type: 'POST',
                data: $form.serialize(),
                success: function(result) {
                    document.getElementById("result").innerHTML = result;
                }
            });
        });
});

}


// Add contact using form submit on My contacts page show_contacts.php
// Just a test. Not implemented. Display of contacts may confuse end users
$("#add_contact_form_REMOVED").submit(function(e)
{
alert("ssss");	
    var postData = $(this).serializeArray();
    var formURL = $(this).attr("action");
    $.ajax(
    {
        url : formURL,
        type: "POST",
        data : postData,
        success:function(data, textStatus, jqXHR) 
        {
            document.getElementById("result").innerHTML = data;
			setTimeout(function() {
 				   $('#result').fadeOut('slow');
			}, 3000); 
			
			$('#result').fadeIn('fast');


        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
            //if fails      
        }
    });
    e.preventDefault(); //STOP default action
    e.unbind(); //unbind. to stop multiple form submit.
});
 
$("#ajaxform").submit(); //Submit  the FORM
