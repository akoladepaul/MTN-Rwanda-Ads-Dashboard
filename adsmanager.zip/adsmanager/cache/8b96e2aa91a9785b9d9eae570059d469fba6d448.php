         
<?php
$style="";
$style='style="padding-top:14px;padding-bottom:14px"';
?>            
            
<div class="row bg-top" <?=$style?> >
<div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 text-xs-center center-block"><center>
<a  href="index.php"><img class="img-responsive logo" src="images/logo.png" /></a></center>
</div>
<div class="col-xs-12 col-sm-12 col-md-10 col-lg-10 col-xl-10 m-t-200">

<nav class="navbar navbar-dark  ">
<!-- Brand -->

<center>
<!-- Toggle Button -->
<button class="navbar-toggler hidden-sm-up" type="button" data-toggle="collapse" data-target="#nav-content">
☰
</button>

<!-- Nav Content -->
<div class="collapse navbar-toggleable-xs" id="nav-content">


<!-- Links -->
<ul class="nav navbar-nav">

<li class="nav-item">
<a href="ad_home.php" class="nav-link" ><?php /*1s*/ echo "".SOFTBIZ_LC00001_LEFT_PANEL.""; /*-~- Home -~-*/ /*1e*/ ?></a>
</li>
<li class="nav-item">
<a href="myaccount.php" class="nav-link"><?php /*1s*/ echo "".SOFTBIZ_LC00009_LEFT_PANEL.""; /*-~- My Account -~-*/ /*1e*/ ?></a></li>

<li class="nav-item">
<a href="choose_banner.php" class="nav-link"><?php /*1s*/ echo SOFTBIZ_LCUPDT2015111000000_13.""; /*-~- Post New Ad -~-*/ ?></a></li>
<li class="nav-item">
<a href="ads.php?package=1" class="nav-link"><?php /*1s*/ echo "".SOFTBIZ_LCUPDT2015111000000_14." "; /*-~- Impressions Based -~-*/ /*1e*/ ?></a></li>
<li class="nav-item">
<a href="ads.php?package=3" class="nav-link"><?php /*1s*/ echo "".SOFTBIZ_LCUPDT2015111000000_16." "; /*-~- Time Based -~-*/ /*1e*/ ?></a></li>
<li class="nav-item">
<a href="ads.php?package=2" class="nav-link"><?php /*1s*/ echo "".SOFTBIZ_LCUPDT2015111000000_15." "; /*-~- Click Based -~-*/ /*1e*/ ?></a></li>





</ul>
</div>

</center>

      <div class="col-sm-6 col-xs-4 col-md-offset-2 col-lg-offset-2 col-xl-offset-2  col-md-4  col-lg-4  col-xl-4">
         <?php if(SHOW_THEMES): ?>
          <div class="top-number"><p>Theme 
          
          <select id="theme_id"  name="theme_id" class="select-two"  onChange="sbiz_jumpMenu('parent',this,0)">
                <?php foreach($softbiz_themes as $theme): ?>
                <option value="<?php echo $_SERVER['PHP_SELF'];?>?provided=<?php echo $theme[0]; ?><?php echo $strpass;?>" 
                <?php if($theme[0]==$provided): ?> 
                <?php echo e('selected'); ?>

                <?php endif; ?>
					  ><?php echo $theme[1]; ?></option>
				<?php endforeach; ?>
    </select>
          
          </p></div>
          <?php endif; ?>
      </div>

</nav>
 
                            

 
</div>
</div>
 

 
 
 
 


 



