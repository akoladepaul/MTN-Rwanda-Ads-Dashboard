


<div class="card ">
  <div class="card-header card-style-one-header-color-two">
    <?php echo $title; ?> 
  </div>
  <div class="card-block style-one-block-color-two">
    <p class="card-text"><?php echo $__env->yieldContent($data); ?></p>
  </div>
</div>