
<div class="card ">
  <div class="card-header card-style-one-header-color-one">
    <?php echo $title; ?> 
  </div>
  <div class="card-block style-one-block-color-one">
    <p class="card-text"><?php echo $__env->yieldContent($data); ?></p>
  </div>
</div>