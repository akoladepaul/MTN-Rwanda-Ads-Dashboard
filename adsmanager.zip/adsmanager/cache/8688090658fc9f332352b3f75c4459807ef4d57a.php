<header id="header">
<?php
foreach($vars as $k=>$v)  { $$k=$v;}
?>
<?php
$data=array(
'lang_enable'=>$lang_enable,
'vars'=>$vars,
);


?>
<?php echo $__env->make('includes.top-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
<?php echo $__env->make('includes.nav-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
</header>

                 <div class="row">
                <div class="col-sm-12 text-center">
      
            <? echo $config["html_header"];?>
            </div>
            </div>
        </div>

            <div class="row">
                <div class="col-sm-12 text-center">

 <?php
if ( isset($_REQUEST["msg"])&&$_REQUEST['msg']<>"")
{
print(sbhtmlentities(stripslashes($_REQUEST['msg']),ENT_QUOTES)); 
}
else
{
echo " ";
}
//end if
?><br><Br>
</div>
</div>